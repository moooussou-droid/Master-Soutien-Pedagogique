/**
 * ABONNEMENTS — Master Soutien Pédagogique (v31)
 *
 * Deux formules annuelles :
 *  - « Essentiel » (999 FCFA/an) : UNIQUEMENT l'enrôlement des élèves et
 *    l'importation des notes (fichier Excel officiel).
 *  - « Complet » (1500 FCFA/an) : TOUTES les fonctionnalités de l'application.
 *
 * Le plan est porté PAR LE CODE : les codes Essentiel commencent par 9,
 * les codes Complet commencent par 1 (toujours 6 chiffres + Luhn, validés
 * hors-ligne). L'application lit donc la formule directement dans le code,
 * sans serveur, et verrouille les fonctions qui ne sont pas incluses.
 */

export type SubscriptionPlan = 'essentiel' | 'complet';

export interface PlanInfo {
  id: SubscriptionPlan;
  /** Prix annuel en FCFA. */
  price: number;
  label: string;
  short: string;
  includes: string[];
}

export const PLANS: Record<SubscriptionPlan, PlanInfo> = {
  essentiel: {
    id: 'essentiel',
    price: 999,
    label: 'Essentiel — 999 FCFA / an',
    short: '999 FCFA / an',
    includes: [
      "Enrôlement des élèves (fiches d'enrôlement + liste Excel)",
      "Importation des notes (fichier Excel officiel, élèves + notes)",
    ],
  },
  complet: {
    id: 'complet',
    price: 1500,
    label: 'Complet — 1500 FCFA / an',
    short: '1500 FCFA / an',
    includes: [
      'Tout le plan Essentiel',
      'Saisie des notes, bulletins & classement',
      'Présences, statistiques, tableaux & exports',
      'Fiches APC, calendrier, encyclopédie & ressources',
      'Toutes les autres fonctionnalités de l’application',
    ],
  },
};

/** Liste des fonctions offertes par le plan Essentiel (pour l'affichage). */
export const ESSENTIEL_FEATURES = [
  { path: '/enrolement-eleves', label: "Enrôlement des élèves" },
  { path: '/class', label: 'Importation des notes (Excel officiel)' },
];

/**
 * Vaut true si la route demandée fait partie du plan Essentiel.
 * - « Enrôlement des élèves » : écran d'enrôlement + écran Élèves d'une
 *   classe (où se fait aussi l'import Excel des élèves ET des notes).
 * - Création / édition d'une classe : indispensable pour utiliser ces
 *   deux fonctions.
 */
export function isAllowedForEssentiel(path: string): boolean {
  const p = (path || '/').split('?')[0];
  // Accès de base (toujours ouverts) : accueil, mon espace (abonnement).
  if (p === '/' || p === '/profile') return true;
  // Fonction 1 : ENRÔLEMENT DES ÉLÈVES.
  if (p.startsWith('/enrolement-eleves')) return true;
  if (p === '/class/new') return true;
  // Fonction 2 : IMPORTATION DES NOTES — écran Élèves d'une classe
  // (ajout d'élèves + fichier Excel officiel : élèves ET notes).
  if (p.startsWith('/class/') && (p.endsWith('/students') || p.endsWith('/edit'))) return true;
  // Tableau de bord d'une classe : hub indispensable (fonctions non incluses
  // y restent affichées avec un cadenas, et bloquées à l'ouverture).
  if (p === '/class' || /^\/class\/[^/]+$/.test(p)) return true;
  return false;
}

/** Une fonction est-elle accessible avec ce plan ? */
export function canAccessPath(plan: SubscriptionPlan, path: string): boolean {
  if (plan === 'complet') return true;
  return isAllowedForEssentiel(path);
}

/** Libellé court des fonctions incluses dans le plan Essentiel. */
export function essentielSummary(): string {
  return 'Enrôlement des élèves • Importation des notes';
}
