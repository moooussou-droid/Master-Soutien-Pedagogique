import { ChevronLeft, Crown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PLANS } from '../utils/subscription';
import { getActivationChrono } from '../utils/userProfile';
import { openWhatsApp } from '../utils/contact';

/**
 * Écran affiché quand un utilisateur de la formule ESSENTIEL (999 FCFA/an)
 * tente d'ouvrir une fonction non incluse. Il propose de passer à la formule
 * COMPLET (1500 FCFA/an) par WhatsApp.
 */
export default function UpgradeScreen({ blockedPath }: { blockedPath: string }) {
  const navigate = useNavigate();
  const chrono = getActivationChrono();

  function askUpgrade() {
    openWhatsApp(
      `Bonjour, je souhaite accéder à une fonction non incluse dans ma formule et passer au plan COMPLET de Master Soutien Pédagogique.\n\nFormule actuelle : Essentiel (999 FCFA/an)\nNom : ${chrono.name || '...'}\nFonction souhaitée : ${blockedPath}\n\nMerci de me communiquer la procédure (1500 FCFA/an).`
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-slate-900 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 bg-white/10 rounded-lg"><ChevronLeft className="w-6 h-6" /></button>
          <div>
            <h1 className="font-bold text-lg">Fonction non incluse</h1>
            <p className="text-slate-300 text-sm">Votre abonnement — Master Soutien Pédagogique</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24 max-w-lg mx-auto space-y-4">
        <div className="bg-white rounded-2xl shadow p-6 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-100">
            <Crown className="h-8 w-8 text-amber-600" />
          </div>
          <h2 className="text-xl font-black text-gray-900">Cette fonction fait partie de la formule <span className="text-emerald-700">COMPLET</span></h2>
          <p className="text-gray-500 text-sm mt-2">
            Votre abonnement <strong>Essentiel (999 FCFA/an)</strong> donne accès à :<br />
            ✔️ Enrôlement des élèves<br />
            ✔️ Importation des notes
          </p>
          <div className="mt-4 rounded-xl border-2 border-emerald-200 bg-emerald-50 p-4">
            <p className="font-black text-emerald-800">⭐ Formule COMPLET — {PLANS.complet.price}</p>
            <p className="text-xs text-emerald-700 mt-1">Toutes les fonctionnalités de l'application, sans limitation.</p>
          </div>
          <button onClick={askUpgrade} className="mt-4 w-full bg-emerald-600 text-white py-3.5 rounded-xl font-bold">
            📲 Demander le passage à COMPLET (1500 FCFA/an) — WhatsApp
          </button>
          <button onClick={() => navigate('/')} className="mt-2 w-full bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold">
            Retour à l'accueil
          </button>
        </div>
      </main>
    </div>
  );
}
