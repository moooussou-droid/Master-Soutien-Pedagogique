# NoteFacile Bénin 🇧🇯

Application mobile web (PWA) de gestion des notes pour les enseignants du primaire au Bénin.

## 🎯 Objectif

Aider les enseignants béninois à générer facilement le fichier Excel requis par **educmaster.bj** pour l'importation des notes des élèves, sans avoir besoin de maîtriser Excel.

## ✨ Fonctionnalités

### 📱 Gestion des Classes
- Création de classes avec niveau (CI, CP, CE1, CE2, CM1, CM2)
- Configuration : école, année scolaire, séquence/trimestre
- Gestion de plusieurs classes en parallèle

### 👥 Gestion des Élèves
- Ajout manuel rapide (matricule, nom, prénoms)
- **Import Excel intelligent** : importez un fichier .xlsx contenant Matricule, Nom, Prénoms
  - Détection automatique des colonnes (même dans le format EducMaster à 2 lignes d'en-tête)
  - **Nouveau modèle officiel du primaire** : toutes les feuilles sont lues
    (Evaluation formative 1, Evaluation sommative 1/2/3), chaque note est rattachée à
    son évaluation, élèves dédupliqués entre feuilles
  - Aperçu avant import + gestion des doublons
  - Mode "Ajouter" ou "Remplacer tout"
  - Matricules conservés en texte (zéros initiaux préservés)
  - Modèle Excel vierge téléchargeable (au format officiel pour le primaire)
- Suppression facile

### 📝 Saisie des Notes
- **Maternelle / Primaire** : une évaluation à la fois (formative 1, sommative 1/2/3) —
  **chaque évaluation a son bulletin de notes**.
- **Secondaire** : saisie par type d'épreuve — **interrogations écrites (MEPE)**,
  **devoir surveillé 1 (NPS1)**, **devoir surveillé 2 (NPS2)** ; le bulletin
  officiel affiche MEPE / NPS1 / NPS2 / MS / MSC, les coefficients, les rangs,
  les moyennes de classe (plus faible / plus forte) et les bilans littéraire /
  scientifique / autres matières.
- **Écran simplifié** : une matière à la fois
- **Pavé numérique tactile** : gros boutons faciles à utiliser
- **Navigation fluide** : élève suivant/précédent
- **Barre de progression** : visualisation de l'avancement
- **Bouton "Absent"** : marquage rapide
- **Saisie note par note** : note obtenue + perfectionnement

### 📊 Tableau de Bord
- Vue tableau complète pour vérification
- Statistiques par matière (moyennes de classe)
- Top 3 des meilleurs élèves
- Identification des élèves à accompagner

### 📤 Export Excel
- **Format exact EducMaster** : respect parfait du modèle
- **Primaire** : une feuille par évaluation (formative 1, sommatives 1/2/3) aux noms
  exacts du modèle officiel, réimportable telle quelle
- En-têtes fusionnés sur 2 lignes
- Matricules conservés avec zéros initiaux (format texte)
- Nom de fichier automatique : `AAAAMMJJHHMMSS_model-importation-note_ANNEE-epp-<ecole>-<classe>.xlsx`

### 🔒 Confidentialité & Sécurité
- **100% hors-ligne** : aucune donnée ne quitte le téléphone
- **Stockage local** : IndexedDB
- **Sauvegarde/restauration** : export/import JSON
- **Effacement total** : bouton pour tout supprimer

### 📲 PWA (Progressive Web App)
- **Installable** : icône sur l'écran d'accueil
- **Fonctionne sans connexion** : après première visite
- **Notifications** : prêt pour les futures notifications

## 🧭 Modules d'enrichissement

- **Orientation scolaire** — conseil d'orientation par domaine adapté au niveau de la
  classe (préscolaire = éveil, primaire = passage au collège, secondaire = séries du
  BAC), analyse par évaluation (formative / sommatives 1-3), évolution entre les
  évaluations sommatives, rapport élève imprimable **et synthèse d'orientation de la
  classe** (profil dominant, matière forte, stade, répartition) pour le conseil des
  professeurs.
- **Orientation post-BAC** — recherche des séries et établissements, fiches
  imprimables.
- **Administration d'établissement** — pilotage de l'école, checklists avec
  progression par catégorie, documents officiels (PV, notes de service…)
  archivés/réimprimables, élèves à accompagner (moyenne < 10) et **rapport de
  pilotage imprimable** pour la circonscription.
- **Cloud & Support** — synchronisation chiffrée avec **test de connexion**,
  format du code vérifié (typos détectées), date relative de dernière synchro,
  erreurs expliquées simplement, **diagnostic transparent** (aperçu avant envoi)
  et FAQ enrichie.

## 🎨 Design

Palette de couleurs inspirée du drapeau béninois :
- 🟢 Vert émeraude (principal)
- 🟡 Jaune ambre (accent)
- 🔴 Rouge (alertes)

Interface optimisée pour mobile :
- Gros boutons (≥ 48px)
- Typographie large et lisible
- Navigation simplifiée

## 🚀 Installation

### Sur Mobile (Recommandé)

1. Ouvrez l'application dans votre navigateur mobile (Chrome, Safari, Firefox)
2. Appuyez sur le menu (⋮ ou ⇧)
3. Sélectionnez **"Ajouter à l'écran d'accueil"** ou **"Installer l'application"**
4. L'icône NoteFacile apparaît sur votre écran d'accueil
5. Lancez l'application comme une app native !

### En Local (Développement)

```bash
# Installer les dépendances
npm install

# Lancer en mode développement
npm run dev

# Construire pour production
npm run build
```

## 📖 Guide d'Utilisation

### 1. Créer une Classe
1. Appuyez sur **"Nouvelle Classe"**
2. Remplissez : nom, école, niveau, année, séquence
3. Validez

### 2. Ajouter des Élèves
1. Dans la classe, appuyez sur **"Élèves"**
2. Appuyez sur le bouton **+**
3. Saisissez : matricule, nom, prénoms
4. Répétez pour chaque élève

### 3. Saisir les Notes
1. Dans la classe, appuyez sur **"Notes"**
2. Sélectionnez une matière
3. Pour chaque élève :
   - Tapez la note obtenue (sur 20)
   - Tapez la note de perfectionnement (sur 10)
   - Ou marquez comme "Absent"
4. Appuyez sur **"Suivant"** pour passer à l'élève suivant

### 4. Exporter vers Excel
1. Dans la classe, appuyez sur **"Export"**
2. Vérifiez la progression de saisie
3. Appuyez sur **"Télécharger le fichier Excel"**
4. Le fichier est prêt à être importé sur educmaster.bj !

### 5. Sauvegarder ses Données
1. Allez dans **"Réglages"**
2. Appuyez sur **"Sauvegarder (export JSON)"**
3. Conservez le fichier en lieu sûr
4. Pour restaurer : **"Restaurer (import JSON)"**

## 🔧 Matières par Défaut

L'application inclut les matières standard du système éducatif béninois :
- Dictée
- Mathématiques
- Expression écrite
- Compréhension de l'écrit
- EST (Étude des Sciences et Technologies)
- ES (Éducation Scientifique)
- EA Oral (Éducation Artistique)
- EA Dessin/Couture
- EPS (Éducation Physique et Sportive)

Les matières sont **modifiables** dans l'onglet **"Matières"** de chaque classe.

## 📊 Structure du Fichier Excel Généré

```
Ligne 1 : | Matricule | Nom | Prénoms | Dictée | Dictée | Math | Math | ...
          |           |     |         | Note   | Perf.  | Note | Perf.|
          |           |     |         | obtenue|        |obt.  |      |
Ligne 2 : |           |     |         |--------|--------|------|------|
          |           |     |         | Note   | Note   | Note | Note |
          |           |     |         | obtenue| Perf.  |obt.  | Perf.|
Ligne 3+ :| 001234    | KOFFI| Jean   | 15     | 8      | 18   | 9    |
```

## 🛡️ Respect des Données Personnelles

Conformément aux principes de protection des données :
- ✅ Aucune donnée n'est envoyée sur internet
- ✅ Aucune base de données distante
- ✅ Aucun compte utilisateur requis
- ✅ Toutes les données restent sur votre téléphone
- ✅ Possibilité d'effacer toutes les données à tout moment

## 🆚 Comparaison avec MasterNote

| Fonctionnalité | NoteFacile Bénin | MasterNote |
|---------------|------------------|------------|
| Prix | **Gratuit** | Payant |
| Hors-ligne | **100%** | Partiel |
| Confidentialité | **Données locales** | Cloud |
| Simplicité | **Écran par écran** | Tableau complet |
| Format Excel | **Identique EducMaster** | Variable |
| Installation | **PWA (léger)** | App native |

## 🤝 Support

Pour toute question ou suggestion :
- Consultez l'aide dans l'application (Réglages)
- Vérifiez que votre navigateur est à jour
- Assurez-vous d'avoir assez d'espace de stockage

## 📄 Licence

Application développée pour les enseignants du Bénin.
Usage gratuit et libre pour un usage éducatif.

## 🔑 Accès (v28)

- **Utilisateur** : un simple **code à 6 chiffres** (ex. `783 420`) suffit,
  sans nom obligatoire, **sans serveur ni connexion** (validation locale).
- **Administrateur** : Espace Administrateur → **Accès** : le **code maître**
  (6 chiffres, modifiable) et « **Générer 5 codes** » (envoi WhatsApp, copie).
- Les anciens codes personnels (16 caractères liés au nom) restent valides.

## 🌍 Culture & formation (v25)

- **Encyclopédie** : 9 domaines et 24 thématiques, sans marque tiers.
- **Cours → Cultivons-nous** : rubriques de formation **Pédagogie Générale**,
  **Législation de l'Administration Scolaire**, **Morale Professionnelle**,
  **Épreuves et Corrigés** — cours des administrateurs avec **nom de l'auteur**,
  **gratuits ou payants** (prix FCFA) et **nombre de visiteurs** consultable
  par les administrateurs (Espace Administrateur → Cours).
- Formulaire **Nouvelle classe** : **Période** (trimestres / semestres) et
  **Type d'évaluation** (Évaluation / Devoir surveillé / Interrogation écrite).

## 🚀 Mise en ligne (lien partageable)

Une seule commande puis un glisser-déposer :

```
npm install          (la première fois seulement)
npm run deploy:check
```

L'assistant construit l'application, vérifie les fichiers et affiche les
étapes Netlify / Vercel. Détails complets : `GUIDE-PUBLICATION-LIEN.md`.

---

**NoteFacile Bénin** - Fait avec ❤️ pour l'éducation au Bénin 🇧🇯
