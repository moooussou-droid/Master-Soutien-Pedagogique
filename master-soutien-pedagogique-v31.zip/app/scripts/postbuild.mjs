#!/usr/bin/env node
/**
 * Post-build — Master Soutien Pédagogique
 * Exécuté automatiquement après `vite build` :
 *   1. crée dist/404.html (copie de index.html) : sur Vercel, les routes
 *      inconnues renvoient 404.html → l'application s'affiche TOUJOURS,
 *      même si les rewrites du vercel.json ne sont pas appliqués (glisser-déposer).
 *   2. copie dist/ → deploy/ : un dossier 100 % prêt à déposer
 *      sur Netlify / Vercel, sans aucune commande npm.
 *   3. vérifie que tous les fichiers de publication sont présents.
 */
import { existsSync, copyFileSync, mkdirSync, readdirSync, statSync, writeFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';

const DIST = join(process.cwd(), 'dist');
const DEPLOY = join(process.cwd(), 'deploy');

function copyDir(src, dest) {
  mkdirSync(dest, { recursive: true });
  for (const ent of readdirSync(src, { withFileTypes: true })) {
    const s = join(src, ent.name);
    const d = join(dest, ent.name);
    if (ent.isDirectory()) copyDir(s, d);
    else copyFileSync(s, d);
  }
}

console.log('\n[postbuild] Préparation des fichiers de publication…');

/* 1 — 404.html (fallback Vercel / tout hébergeur statique) */
if (existsSync(join(DIST, 'index.html'))) {
  copyFileSync(join(DIST, 'index.html'), join(DIST, '404.html'));
  console.log('  ✅ dist/404.html créé (routes inconnues → application, même sans vercel.json)');
} else {
  console.error('  ❌ dist/index.html introuvable — le build a-t-il réussi ?');
  process.exit(1);
}

/* 2 — deploy/ prêt à l'emploi (zéro commande) */
if (existsSync(DEPLOY)) rmSync(DEPLOY, { recursive: true, force: true });
copyDir(DIST, DEPLOY);
writeFileSync(
  join(DEPLOY, 'COMMENT-DEPLOYER.txt'),
  [
    '══════════════════════════════════════════════════════════════',
    '  MASTER SOUTIEN PÉDAGOGIQUE — DOSSIER DE PUBLICATION PRÊT',
    '══════════════════════════════════════════════════════════════',
    '',
    'Ce dossier contient l\'application COMPLÈTE, déjà construite.',
    'AUCUNE commande n\'est nécessaire pour la mettre en ligne.',
    '',
    'NETLIFY (2 minutes, gratuit, sans compte) :',
    '  1. Ouvrez https://app.netlify.com/drop',
    '  2. Ouvrez CE dossier et glissez-DÉPOSEZ SON CONTENU',
    '     (ce qui se trouve DANS ce dossier) dans la zone.',
    '  3. C\'est en ligne ! ⚠️ Notez l\'adresse affichée : c\'est votre lien',
    '     à partager. Pour le personnaliser, créez un compte gratuit puis',
    '     allez dans « Domain settings » (ex. master-soutien.netlify.app).',
    '',
    'VERCEL (2 minutes, gratuit, sans compte) :',
    '  1. Ouvrez https://vercel.com/new → onglet « Deploy »',
    '     (ou https://vercel.com/drag-drop)',
    '  2. Glissez-DÉPOSEZ le contenu de CE dossier dans la zone.',
    '  3. Vercel publie immédiatement (le vercel.json + 404.html',
    '     inclus garantissent que toutes les pages s\'affichent).',
    '',
    'POUR METTRE À JOUR (le lien ne change pas) :',
    '  - Netlify : sur votre site, onglet « Deploys » → glissez à nouveau',
    '    le contenu de ce dossier (re-construit à jour).',
    '  - Vercel : sur votre projet, « Deployments → Upload » → même chose.',
    '',
    '⚠️ NE DÉPOSEZ JAMAIS : le dossier « app/ », ni le fichier .zip.',
    '   → Sinon Vercel affiche « 404: NOT_FOUND » et Netlify une page vide.',
    '   → Déposez toujours le CONTENU de ce dossier (les fichiers DEDANS).',
    '',
    'Vérifier que votre lien est sain :  npm run deploy:verify <votre-lien>',
    '══════════════════════════════════════════════════════════════',
  ].join('\n')
);
console.log('  ✅ deploy/ créé (copie de dist/ + COMMENT-DEPLOYER.txt)');

/* 3 — vérification */
const required = ['index.html', '404.html', 'sw.js', 'vercel.json', '_redirects', 'manifest.json'];
let allOk = true;
for (const f of required) {
  const ok = existsSync(join(DIST, f));
  if (!ok) allOk = false;
  console.log(`  ${ok ? '✅' : '❌'} dist/${f}`);
}
if (!allOk) {
  console.error('  ❌ Fichiers manquants !');
  process.exit(1);
}
const kb = Math.round(statSync(join(DIST, 'index.html')).size / 1024);
console.log(`\n  ✅ Publication prête : dist/ (${kb} Ko, application complète) et deploy/`);
console.log('  → Déposez le CONTENU de deploy/ sur https://app.netlify.com/drop ou https://vercel.com/new\n');
