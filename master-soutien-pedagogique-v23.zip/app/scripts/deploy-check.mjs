#!/usr/bin/env node
/**
 * Assistant de publication — Master Soutien Pédagogique
 * ---------------------------------------------
 * Une seule commande :  npm run deploy:check
 *   1. Construit automatiquement l'application si nécessaire (npm run build).
 *   2. Vérifie que tous les fichiers de publication sont présents dans dist/.
 *   3. Affiche la marche à suivre (2 minutes) pour Netlify et Vercel.
 *
 * Aucune bibliothèque requise (Node.js ≥ 18).
 */
import { existsSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { execSync } from 'node:child_process';

const DIST = join(process.cwd(), 'dist');
const ok = (b) => (b ? '✅' : '❌');
const hr = '─'.repeat(62);

console.log('\n' + '═'.repeat(62));
console.log('  ASSISTANT DE PUBLICATION — MASTER SOUTIEN PÉDAGOGIQUE');
console.log('═'.repeat(62));

/* 1 — construction ------------------------------------------------ */
if (!existsSync(join(DIST, 'index.html'))) {
  console.log('\n[1/3] dist/ introuvable → construction automatique…');
  try {
    execSync('npm run build', { stdio: 'inherit' });
  } catch {
    console.error('❌ Le build a échoué. Vérifiez que les dépendances sont installées : npm install');
    process.exit(1);
  }
} else {
  console.log('\n[1/3] dist/ déjà construit (relancez « npm run build » pour une mise à jour).');
}

/* 2 — vérifications ---------------------------------------------- */
console.log('\n[2/3] Vérification des fichiers de publication :');
const required = ['index.html', 'sw.js', 'vercel.json', '_redirects', 'manifest.json'];
let allOk = true;
for (const f of required) {
  const present = existsSync(join(DIST, f));
  if (!present) allOk = false;
  console.log(`  ${ok(present)} dist/${f}${present ? '' : '  ← manquant !'}`);
}
if (!allOk) {
  console.error('❌ Fichiers manquants → exécutez : npm run build, puis relancez cette commande.');
  process.exit(1);
}
const size = Math.round(statSync(join(DIST, 'index.html')).size / 1024);
console.log(`  (index.html : ${size} Ko — application complète en un seul fichier)`);

/* 3 — marche à suivre -------------------------------------------- */
console.log('\n[3/3] Publication en 2 minutes :\n');
console.log(hr);
console.log('  OPTION A — NETLIFY (gratuit, sans compte Git)');
console.log(hr);
console.log('  1. Ouvrez https://app.netlify.com/drop');
console.log('  2. GLISSEZ LE DOSSIER dist/ ENTIER dans la zone de dépôt.');
console.log('  3. C’est en ligne ! (adresse en fin de page → « Site configuration » pour la renommer).');
console.log('  ⚠️  Ne déposez PAS le .zip ni le dossier source du projet :');
console.log('      déposez le CONTENU de dist/ (ce qui se trouve DANS le dossier dist).\n');
console.log(hr);
console.log('  OPTION B — VERCEL (gratuit, sans compte Git)');
console.log(hr);
console.log('  1. Ouvrez https://vercel.com/new → onglet « Deploy » (ou vercel.com/drag-drop).');
console.log('  2. GLISSEZ LE DOSSIER dist/ ENTIER dans la zone de dépôt.');
console.log('  3. Vercel détecte automatiquement dist/vercel.json : toutes les pages répondent.');
console.log('     Si l’écran vous demande un « Project Name », laissez le pré-rempli → Deploy.');
console.log('  ⚠️  Si vous voyez « 404: NOT_FOUND » : vous avez déposé le .zip ou la source.');
console.log('      Reprenez à l’étape 2 en déposant le contenu du dossier dist/.\n');
console.log(hr);
console.log('  OPTION C — VERCEL avec compte GitHub (mises à jour automatiques)');
console.log(hr);
console.log('  1. Poussez le dossier du projet (sans node_modules ni dist) sur GitHub.');
console.log('  2. vercel.com/new → Importez le dépôt → Framework « Vite » →');
console.log('     Output Directory : dist → Deploy (le vercel.json fait le reste).');
console.log('  3. À chaque git push, Vercel reconstruit et publie.\n');
console.log('POUR METTRE À JOUR une version déjà en ligne : npm run build, puis re-déposez dist/.');
console.log('═'.repeat(62) + '\n');
