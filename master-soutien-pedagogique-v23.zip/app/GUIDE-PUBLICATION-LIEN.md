# 🔗 Master Soutien Pédagogique — Obtenir le lien de l'application (v22)

Votre application est **prête à être mise en ligne**. Le dossier `dist/` produit
par `npm run build` contient **toute l'application en un seul fichier**
(`index.html`) plus les accessoires (icônes, mode hors-ligne, réécritures de
routes). Il suffit de le déposer sur Netlify ou Vercel pour obtenir un lien
partageable (ex. `https://master-soutien.netlify.app`).

---

## ⚡ La méthode « 1 commande » (recommandée)

Ouvrez un terminal dans le dossier `app/` et lancez :

```
npm install          (la première fois seulement)
npm run deploy:check
```

Cet assistant :
1. **construit automatiquement** l'application si `dist/` n'existe pas ;
2. vérifie que tous les fichiers de publication sont bien présents ;
3. affiche la marche à suivre pour Netlify et Vercel, **étape par étape**.

---

## ✅ Méthode 1 — Netlify Drop (LA PLUS RAPIDE, sans compte)

1. Ouvrez **https://app.netlify.com/drop**
2. **Ouvrez le dossier `dist/`** et glissez-déposez **son contenu** (les fichiers
   qui sont DANS `dist/`) dans la zone de dépôt.
   > ❌ Ne glissez PAS le ZIP, ni `app/`, ni `master-soutien/` : ces dossiers ne
   > contiennent pas `index.html` à la racine → page « introuvable ».
3. Netlify génère immédiatement un lien : `https://nom-aleatoire-12345.netlify.app`
4. (Optionnel) Créez un compte gratuit pour **renommer** le lien en
   `https://master-soutien-pedagogique.netlify.app`
5. **Partagez ce lien** par WhatsApp à tous les enseignants ! 🎉

> 💡 Chaque enseignant ouvre le lien puis fait « Ajouter à l'écran d'accueil »
> pour installer l'application sur son téléphone (fonctionne hors-ligne).

---

## ✅ Méthode 2 — Vercel (alternative gratuite, lien permanent)

> ⚠️ **Vercel affiche « 404: NOT_FOUND » si `index.html` n'est pas à la racine
> de ce qui est déposé** (dossier source `app/`, ZIP…). Déposez toujours le
> **contenu du dossier `dist/`**.

### 2.A — Glisser-déposer le contenu de `dist/` (simple, sans Git)

1. `npm run deploy:check` (voir ci-dessus) → le dossier `dist/` est prêt.
2. Ouvrez **https://vercel.com/new → Deploy** (ou **vercel.com/drag-drop**).
3. **Ouvrez le dossier `dist/`**, sélectionnez **tout son contenu** (index.html,
   vercel.json, sw.js, icônes…) et glissez ces fichiers dans la zone.
4. Vercel déploie instantanément : `https://nom-du-projet.vercel.app`.
5. Testez la racine **et** `https://nom-du-projet.vercel.app/cours` : les deux
   doivent afficher l'application (le `vercel.json` réécrit les routes vers
   `index.html`).

### 2.B — Depuis Git (mises à jour automatiques)

1. Poussez le projet (le dossier `app/` à la racine du dépôt) sur GitHub.
2. **vercel.com → Add New → Project** → importez le dépôt.
3. **Framework Preset : Vite** (détecté automatiquement) ; si demandé :
   - Build Command : `npm run build`
   - **Output Directory : `dist`** ← c'est la valeur qui évite le 404
4. **Deploy**. À chaque `git push`, Vercel reconstruit et publie tout seul.

---

## 🔧 Dépannage

| Problème | Cause | Solution |
|---|---|---|
| Netlify : « Page not found » / dossier vide | ZIP ou mauvais dossier déposé | Déposez le **contenu de `dist/`** (pas le ZIP, pas `app/`) |
| Vercel : « 404: NOT_FOUND » | `index.html` absent à la racine du dépôt | Méthode 2.A (contenu de `dist/`) ou 2.B avec **Output Directory = dist** |
| Les notes / classes ne se déplacent pas d'un appareil à l'autre | Chaque appareil a son stockage local | Utilisez le module **Sauvegarde Cloud** (écran « Cloud » + code de chiffrement) |
| Une ancienne version s'affiche | Service worker en cache | Re-déposez `dist/` ; les utilisateurs voient la nouvelle version au prochain rechargement (mise à jour automatique) |

**Pour mettre à jour une version déjà en ligne :** `npm run build` puis
re-déposez le contenu de `dist/` (même site : le lien ne change pas).

---

### 📦 Ce qui est inclus dans `dist/` (fichiers de publication)

`index.html` (l'application complète) · `sw.js` (mode hors-ligne) ·
`manifest.json` + icônes (installation sur téléphone) · `vercel.json`
(routes Vercel) · `_redirects` (routes Netlify) · `benin-flag.svg`, `cover.png`.
