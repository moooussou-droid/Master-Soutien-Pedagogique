import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { applyTheme, getSavedTheme } from "./utils/theme";

// Apply theme before React render to avoid a light/dark flash.
applyTheme(getSavedTheme());

// Register service worker for PWA (uniquement en http/https, pas en file://)
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js')
      .then((registration) => {
        console.log('SW registered:', registration.scope);
        // Vérifie régulièrement l'existence d'une nouvelle version de l'app.
        // (sans ceci, le navigateur ne re-télécharge sw.js qu'une fois par 24 h)
        setInterval(() => {
          registration.update().catch(() => {});
        }, 60 * 60 * 1000); // toutes les heures
      })
      .catch((error) => {
        console.log('SW registration failed:', error);
      });

    // Une nouvelle version est disponible (sw.js changé) : recharger une fois.
    if (navigator.serviceWorker.controller) {
      // Un service worker contrôlait DÉJÀ la page → il s'agit d'une vraie mise à jour.
      let refreshed = false;
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (refreshed) return;
        refreshed = true;
        window.location.reload();
      });
    }
  });
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
