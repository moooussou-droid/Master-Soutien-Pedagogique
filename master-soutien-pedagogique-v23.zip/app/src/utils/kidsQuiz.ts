/**
 * Quiz « Devine le mot » pour les petits écoliers.
 * Génération déterministe (graine) → testable, aucun réseau requis.
 */

export interface QuizWord {
  word: string;
  definition: string;
  example: string;
}

export interface QuizQuestion {
  definition: string;
  example: string;
  correct: string;
  options: string[];
}

export interface QuizResult {
  score: number;
  total: number;
}

const BEST_KEY = 'msp_kids_quiz_best';

function hashSeed(str: string): number {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return h >>> 0;
}

function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Génère `count` questions (définition → 4 choix de mots). */
export function generateQuiz(pool: QuizWord[], count = 5, seed = 'quiz'): QuizQuestion[] {
  const rng = mulberry32(hashSeed(seed));
  const items = [...pool];
  // Mélange Fisher-Yates déterministe
  for (let i = items.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [items[i], items[j]] = [items[j], items[i]];
  }
  const selected = items.slice(0, Math.max(0, Math.min(count, items.length)));
  return selected.map(item => {
    const wrongs = items.filter(i => i.word !== item.word).slice(0, 3).map(i => i.word);
    const options = [item.word, ...wrongs];
    // Mélange des 4 options
    for (let i = options.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [options[i], options[j]] = [options[j], options[i]];
    }
    return { definition: item.definition, example: item.example, correct: item.word, options };
  });
}

/* ------- Meilleur score (stockage local) ------- */

export function loadBestScore(key = BEST_KEY): number {
  try { return parseInt(localStorage.getItem(key) || '0', 10) || 0; } catch { return 0; }
}

export function saveBestScore(score: number, key = BEST_KEY): void {
  try {
    const best = loadBestScore(key);
    if (score > best) localStorage.setItem(key, String(score));
  } catch { /* quota */ }
}

/** Message d'encouragement selon le score. */
export function quizMessage(score: number, total: number): string {
  const pct = total > 0 ? score / total : 0;
  if (pct >= 0.8) return 'Bravo, champion ! 🏆';
  if (pct >= 0.6) return 'Très bien, continue ! 👏';
  if (pct >= 0.4) return 'C’est bien, encore un effort ! 💪';
  return 'Recommence, tu vas y arriver ! 🌱';
}
