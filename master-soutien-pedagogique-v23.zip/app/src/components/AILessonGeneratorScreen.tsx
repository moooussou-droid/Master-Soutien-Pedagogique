import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bot, ChevronLeft, Clipboard, ExternalLink, ImageUp, KeyRound, Pencil, Printer, Save, Wand2, FileText, Sparkles, Eye } from 'lucide-react';
import { downloadFicheDocx, printFiche } from '../utils/ficheExport';
import { copyText } from '../utils/clipboard';
import {
  AIProvider,
  AISettings,
  buildLessonPrompt,
  extractModelText,
  fileToInlineImage,
  generateLessonPlan,
  getAISettings,
  PROMPT_MAGIC_FICHE_PEDAGOGIQUE,
  PROMPT_MAGIC_EXERCICES_ADAPTATIFS,
  saveAISettings,
  GeneratedLessonPlan,
  GenerationKind,
  PedagogicalStandard,
  GEMINI_MODELS,
  GEMINI_FREE_KEY_URL,
} from '../utils/aiLessonGenerator';

const FICHES_KEY = 'msp_fiches_pedagogiques';

function today() {
  return new Date().toISOString().split('T')[0];
}

function loadFiches(): any[] {
  try {
    return JSON.parse(localStorage.getItem(FICHES_KEY) || '[]');
  } catch {
    return [];
  }
}

function saveGeneratedAsFiche(plan: GeneratedLessonPlan) {
  const fiches = loadFiches();
  const fiche = {
    id: `fiche-ai-${Date.now()}`,
    titre: plan.titre,
    classe: plan.classe,
    matiere: plan.matiere,
    domaine: plan.domaine,
    duree: plan.duree,
    date: today(),
    competence: plan.competence,
    objectif: plan.objectif,
    materiel: plan.materiel,
    deroulement: plan.deroulement,
    evaluation: plan.evaluation,
    statut: 'prete',
    createdAt: Date.now(),
  };
  localStorage.setItem(FICHES_KEY, JSON.stringify([fiche, ...fiches]));
}

export default function AILessonGeneratorScreen() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState<AISettings>(getAISettings());
  const [niveau, setNiveau] = useState('CE1');
  const [matiere, setMatiere] = useState('Mathématiques');
  const [theme, setTheme] = useState('');
  const [duree, setDuree] = useState('45 min');
  const [objectif, setObjectif] = useState('');
  const [consignes, setConsignes] = useState('');
  const [generationKind, setGenerationKind] = useState<GenerationKind>('fiche');
  const [standard, setStandard] = useState<PedagogicalStandard>('APC_BENIN');
  const [image, setImage] = useState<{ mimeType: string; base64: string } | undefined>();
  const [imageName, setImageName] = useState('');
  const [modelFileName, setModelFileName] = useState('');
  const [modelText, setModelText] = useState('');
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<GeneratedLessonPlan | null>(null);
  const [draft, setDraft] = useState<GeneratedLessonPlan | null>(null); // version modifiable
  const [editing, setEditing] = useState(false);

  function updateSettings(patch: Partial<AISettings>) {
    const next = { ...settings, ...patch };
    setSettings(next);
    saveAISettings(next);
  }

  async function handleImage(file?: File) {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Choisissez une image JPG ou PNG.');
      return;
    }
    setImage(await fileToInlineImage(file));
    setImageName(file.name);
  }

  async function handleGenerate() {
    setGenerating(true);
    try {
      const plan = await generateLessonPlan(settings, { niveau, matiere, theme, duree, objectif, consignes, generationKind, standard, modelText, image });
      setResult(plan);
      setDraft(plan);
      setEditing(false);
      // Faire défiler jusqu'au résultat sur mobile
      setTimeout(() => {
        document.getElementById('resultat-fiche')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    } catch (e: any) {
      alert(e.message || 'Génération impossible. Essayez le générateur intégré sans clé API.');
    } finally {
      setGenerating(false);
    }
  }

  function updateDraft(patch: Partial<GeneratedLessonPlan>) {
    setDraft((prev) => (prev ? { ...prev, ...patch } : prev));
  }

  async function copyPrompt() {
    const prompt = buildLessonPrompt({ niveau, matiere, theme, duree, objectif, consignes, generationKind, standard, modelText, image });
    const okCopy = await copyText(prompt);
    alert(okCopy ? 'Prompt copié. Vous pouvez le coller dans Gemini, Claude, ChatGPT, Copilot, Mistral, DeepSeek ou Perplexity.' : 'Impossible de copier automatiquement : sélectionnez le prompt manuellement.');
  }

  async function copyMagicPrompt() {
    const prompt = generationKind === 'exercices'
      ? PROMPT_MAGIC_EXERCICES_ADAPTATIFS
      : PROMPT_MAGIC_FICHE_PEDAGOGIQUE;
    const okCopy = await copyText(prompt);
    alert(okCopy ? (generationKind === 'exercices' ? 'Prompt Magic 2 copié.' : 'Prompt Magic 1 copié.') : 'Impossible de copier automatiquement : sélectionnez le prompt manuellement.');
  }

  function saveFiche() {
    if (!draft) return;
    saveGeneratedAsFiche(draft);
    alert('Fiche enregistrée dans Mes fiches.');
  }

  async function handleModelFile(file?: File) {
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase();
    setModelFileName(file.name);
    try {
      if (file.type.startsWith('image/')) {
        setImage(await fileToInlineImage(file));
        setImageName(file.name);
        setModelText('');
        return;
      }
      if (ext === 'pdf' || ext === 'docx' || ext === 'doc') {
        const text = await extractModelText(file);
        setModelText(text);
        return;
      }
      alert('Format non pris en charge pour le modèle. Utilisez DOC, DOCX, PDF, JPG ou PNG.');
    } catch (e) {
      console.error(e);
      alert('Impossible de lire ce modèle. Essayez de le convertir en PDF ou DOCX.');
    }
  }

  const THEME_SUGGESTIONS: Record<string, string[]> = {
    'Mathématiques': ['Addition avec retenue', 'Soustraction sans retenue', 'Multiplication par un chiffre', 'Division simple', 'Fractions simples', 'Les nombres jusqu\'à 10 000', 'Problèmes de partage', 'Les mesures de longueur'],
    'Math': ['Addition avec retenue', 'Soustraction sans retenue', 'Multiplication par un chiffre', 'Division simple', 'Fractions simples', 'Les nombres jusqu\'à 10 000', 'Problèmes de partage', 'Les mesures de longueur'],
    'Dictée': ['Dictée : les mots de la semaine', 'Dictée : le son « on »', 'Dictée : accords sujet-verbe', 'Dictée préparée : le marché', 'Dictée : les homophones'],
    'Lecture': ['Lecture : conte africain', 'Lecture : texte documentaire', 'Lecture : le renard et la hyène', 'Lecture : la vie au village', 'Lecture : poème de la rentrée'],
    'Expression écrite': ['Rédaction : je me présente', 'Rédaction : une journée à l\'école', 'Rédaction : la fête de la naissance', 'Rédaction : mon animal préféré', 'Rédaction : un souvenir de vacances'],
    'Compréhension de l\'écrit': ['Texte : la saison des pluies', 'Texte : le marché de Cotonou', 'Texte : l\'hygiène à l\'école', 'Texte : le baobab'],
    'EST': ['La germination du haricot', 'L\'eau et ses états', 'Le tri des déchets', 'Les plantes de notre environnement', 'Les animaux de la ferme'],
    'ES': ['L\'hygiène corporelle', 'L\'alimentation équilibrée', 'Le paludisme : prévention', 'Les dents et leur entretien', 'Le sommeil et le repos'],
    'EPS': ['Course de vitesse', 'Lancer de balle', 'Sauts et parcours', 'Jeux collectifs : béret', 'Relais et coopération'],
    'Français': ['La phrase : sujet et verbe', 'Le présent de l\'indicatif', 'Les types de phrases', 'Les déterminants', 'Le futur simple'],
    'Anglais': ['Greetings and introductions', 'Numbers 1-20', 'Colours', 'My family', 'At the market'],
    'Histoire-Géographie': ['Les grands fleuves du Bénin', 'Les ethnies et langues du Bénin', 'La vie au temps des anciens', 'Les villes du Bénin', 'La carte du Bénin'],
    'PCT': ['Les états de la matière', 'Les leviers simples', 'Les circuits électriques simples', 'Les mélanges et solutions', 'Les machines simples'],
    'SVT': ['La respiration', 'La nutrition des plantes', 'La reproduction des plantes', 'Le cycle de l\'eau', 'Les écosystèmes'],
    'Philosophie': ['Peut-on se passer de la philosophie ?', 'La liberté et la responsabilité', 'La conscience et la connaissance', 'Le bonheur : qu\'est-ce que c\'est ?'],
    'Conduite': ['La signalisation routière', 'Traverser la route en sécurité', 'Les panneaux de signalisation', 'Comportement du piéton'],
  };

  const suggestions = THEME_SUGGESTIONS[matiere] || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/fiches-pedagogiques')} className="p-2 bg-white/20 rounded-lg">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="font-bold text-lg">Générateur de Fiches APC avec IA</h1>
            <p className="text-emerald-100 text-sm">Sans clé API par défaut, avec options Gemini, Claude, ChatGPT, Copilot...</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24 space-y-4">
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
          <p className="text-amber-800 text-sm">
            Le générateur intégré fonctionne sans clé API. Les clés externes sont facultatives et restent stockées uniquement sur cet appareil.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow p-4">
          <h2 className="font-bold text-gray-800 mb-3 flex items-center gap-2"><KeyRound className="w-5 h-5" /> IA à utiliser</h2>
          <select
            value={settings.provider}
            onChange={e => updateSettings({ provider: e.target.value as AIProvider })}
            className="w-full p-3 border border-gray-300 rounded-lg mb-3"
          >
            <option value="local">Générateur intégré (sans clé API)</option>
            <option value="gemini">Google AI Studio / Gemini (clé gratuite) ⭐</option>
            <option value="copilot">Microsoft Copilot / Azure OpenAI</option>
            <option value="openai">ChatGPT / OpenAI</option>
            <option value="anthropic">Claude / Anthropic</option>
            <option value="mistral">Mistral AI</option>
            <option value="deepseek">DeepSeek</option>
            <option value="perplexity">Perplexity Sonar</option>
          </select>
          {settings.provider === 'local' && (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
              Génération locale activée : aucune clé API n’est nécessaire. Le résultat est produit à partir de modèles pédagogiques intégrés.
            </div>
          )}
          {settings.provider === 'gemini' && (
            <div className="space-y-2">
              <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
                <p className="font-bold flex items-center gap-2"><ExternalLink className="w-4 h-4" /> Google AI Studio — clé GRATUITE en 2 minutes</p>
                <p className="mt-1">1. Créez/connectez un compte Google · 2. Cliquez sur « Get API key » · 3. Copiez la clé (commence par <span className="font-mono">AIza...</span>).</p>
                <a
                  href={GEMINI_FREE_KEY_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-3 py-2 text-white font-bold text-xs"
                >
                  <ExternalLink className="w-4 h-4" /> Obtenir ma clé gratuite
                </a>
              </div>
              <KeyInput value={settings.geminiKey || ''} onChange={v => updateSettings({ geminiKey: v })} placeholder="Clé API Google AI Studio (AIza...)" />
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Modèle</label>
                <select
                  value={settings.geminiModel || 'gemini-2.5-flash'}
                  onChange={e => updateSettings({ geminiModel: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                >
                  {GEMINI_MODELS.map(m => (
                    <option key={m.id} value={m.id}>{m.label} — {m.note}</option>
                  ))}
                </select>
                <p className="text-xs text-gray-500 mt-1">💡 Le modèle Flash est gratuit et largement suffisant pour les fiches. Les clés sont stockées uniquement sur cet appareil.</p>
              </div>
            </div>
          )}
          {settings.provider === 'copilot' && (
            <div className="space-y-2">
              <KeyInput value={settings.copilotEndpoint || ''} onChange={v => updateSettings({ copilotEndpoint: v })} placeholder="Endpoint Azure OpenAI / Copilot Studio" />
              <KeyInput value={settings.copilotKey || ''} onChange={v => updateSettings({ copilotKey: v })} placeholder="Clé API Microsoft Copilot / Azure" />
            </div>
          )}
          {settings.provider === 'openai' && <KeyInput value={settings.openaiKey || ''} onChange={v => updateSettings({ openaiKey: v })} placeholder="Clé API OpenAI" />}
          {settings.provider === 'anthropic' && <KeyInput value={settings.anthropicKey || ''} onChange={v => updateSettings({ anthropicKey: v })} placeholder="Clé API Anthropic" />}
          {settings.provider === 'mistral' && <KeyInput value={settings.mistralKey || ''} onChange={v => updateSettings({ mistralKey: v })} placeholder="Clé API Mistral" />}
          {settings.provider === 'deepseek' && <KeyInput value={settings.deepseekKey || ''} onChange={v => updateSettings({ deepseekKey: v })} placeholder="Clé API DeepSeek" />}
          {settings.provider === 'perplexity' && <KeyInput value={settings.perplexityKey || ''} onChange={v => updateSettings({ perplexityKey: v })} placeholder="Clé API Perplexity" />}
        </div>

        <div className="bg-white rounded-xl shadow p-4 space-y-3">
          <h2 className="font-bold text-gray-800 flex items-center gap-2"><Bot className="w-5 h-5 text-emerald-600" /> Informations de la fiche</h2>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Production</label>
              <select value={generationKind} onChange={e => setGenerationKind(e.target.value as GenerationKind)} className="w-full p-3 border border-gray-300 rounded-lg text-sm">
                <option value="fiche">Fiche pédagogique APC</option>
                <option value="exercices">Exercices + corrigés</option>
                <option value="cours_en_ligne">Cours à mettre en ligne</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Norme pédagogique</label>
              <select value={standard} onChange={e => setStandard(e.target.value as PedagogicalStandard)} className="w-full p-3 border border-gray-300 rounded-lg text-sm">
                <option value="APC_BENIN">APC Bénin</option>
                <option value="PPO">PPO</option>
                <option value="COMPETENCE">Approche compétences</option>
                <option value="DIFFERENCIATION">Différenciation</option>
                <option value="BLOOM">Taxonomie de Bloom</option>
                <option value="UNIVERSAL_DESIGN">Inclusion / CUA</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Input label="Niveau" value={niveau} onChange={setNiveau} />
            <Input label="Matière" value={matiere} onChange={setMatiere} />
          </div>
          <Input label="Thème / Leçon" value={theme} onChange={setTheme} placeholder="Ex: Addition avec retenue" />
          {suggestions.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-emerald-700 mb-2 flex items-center gap-1">
                <Sparkles className="w-4 h-4" /> Suggestions pour « {matiere} » :
              </p>
              <div className="flex flex-wrap gap-2">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    onClick={() => setTheme(s)}
                    className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-800 hover:bg-emerald-100"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            <Input label="Durée" value={duree} onChange={setDuree} />
            <Input label="Objectif" value={objectif} onChange={setObjectif} />
          </div>
          <Area label="Consignes complémentaires" value={consignes} onChange={setConsignes} />
          <label className="border-2 border-dashed border-emerald-300 bg-emerald-50 rounded-xl p-4 flex items-center gap-3 cursor-pointer">
            <ImageUp className="w-6 h-6 text-emerald-600" />
            <div className="flex-1">
              <p className="font-medium text-emerald-800 text-sm">Modèle de fiche à analyser</p>
              <p className="text-emerald-700 text-xs">
                {modelFileName || 'Formats acceptés : DOC, DOCX, PDF, JPG, JPEG, PNG'}
              </p>
              {modelText && <p className="text-emerald-600 text-xs mt-1">Texte extrait : {modelText.length} caractères</p>}
            </div>
            <input type="file" accept=".doc,.docx,.pdf,image/*" onChange={e => handleModelFile(e.target.files?.[0])} className="hidden" />
          </label>
          <label className="border-2 border-dashed border-gray-300 rounded-xl p-4 flex items-center gap-3 cursor-pointer">
            <ImageUp className="w-6 h-6 text-gray-400" />
            <div className="flex-1">
              <p className="font-medium text-gray-700 text-sm">Modèle de fiche ou image support (facultatif)</p>
              <p className="text-gray-400 text-xs">{imageName || 'Image du modèle, page de manuel, exercice, schéma...'}</p>
            </div>
            <input type="file" accept="image/*" onChange={e => handleImage(e.target.files?.[0])} className="hidden" />
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button onClick={copyMagicPrompt} className="bg-amber-50 text-amber-700 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 text-sm"><Clipboard className="w-5 h-5" /> {generationKind === 'exercices' ? 'Prompt Magic 2' : 'Prompt Magic 1'}</button>
            <button onClick={copyPrompt} className="bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold flex items-center justify-center gap-2"><Clipboard className="w-5 h-5" /> Copier prompt</button>
            <button onClick={handleGenerate} disabled={generating} className="bg-emerald-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50"><Wand2 className="w-5 h-5" /> {generating ? 'Génération...' : 'Générer'}</button>
          </div>
        </div>

        {result && draft && (
          <div id="resultat-fiche" className="bg-white rounded-xl shadow p-4 scroll-mt-20">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-gray-800">Fiche générée</h2>
              <div className="flex items-center gap-2">
                {editing
                  ? <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-700">✏️ Édition</span>
                  : <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">✓ Prête</span>}
                <button
                  onClick={() => setEditing(!editing)}
                  className="rounded-full border border-gray-300 px-3 py-1 text-xs font-bold text-gray-600 flex items-center gap-1"
                >
                  {editing ? <><Eye className="w-3.5 h-3.5" /> Aperçu</> : <><Pencil className="w-3.5 h-3.5" /> Modifier</>}
                </button>
              </div>
            </div>

            {editing ? (
              <div className="space-y-3">
                <EditInput label="Titre" value={draft.titre} onChange={v => updateDraft({ titre: v })} />
                <div className="grid grid-cols-2 gap-2">
                  <EditInput label="Classe" value={draft.classe} onChange={v => updateDraft({ classe: v })} />
                  <EditInput label="Matière" value={draft.matiere} onChange={v => updateDraft({ matiere: v })} />
                </div>
                <EditInput label="Domaine" value={draft.domaine} onChange={v => updateDraft({ domaine: v })} />
                <EditInput label="Durée" value={draft.duree} onChange={v => updateDraft({ duree: v })} />
                <EditArea label="Compétence" value={draft.competence} onChange={v => updateDraft({ competence: v })} rows={3} />
                <EditArea label="Objectif" value={draft.objectif} onChange={v => updateDraft({ objectif: v })} rows={2} />
                <EditArea label="Matériel" value={draft.materiel} onChange={v => updateDraft({ materiel: v })} rows={2} />
                <EditArea label="Déroulement" value={draft.deroulement} onChange={v => updateDraft({ deroulement: v })} rows={10} big />
                <EditArea label="Évaluation" value={draft.evaluation} onChange={v => updateDraft({ evaluation: v })} rows={6} />
                <p className="text-xs text-gray-400">✏️ Modifiez librement : vos changements seront utilisés pour la sauvegarde, l'impression et l'export Word.</p>
              </div>
            ) : (
              <>
                <Preview label="Titre" value={draft.titre} />
                <Preview label="Compétence" value={draft.competence} />
                <Preview label="Objectif" value={draft.objectif} />
                <Preview label="Matériel" value={draft.materiel} />
                <Preview label="Déroulement" value={draft.deroulement} big />
                <Preview label="Évaluation" value={draft.evaluation} />
              </>
            )}

            <div className="grid grid-cols-2 gap-2 mt-3">
              <button onClick={saveFiche} className="bg-emerald-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2"><Save className="w-5 h-5" /> Mes fiches</button>
              <button onClick={() => printFiche(draft)} className="bg-[#006b4f] text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2"><Printer className="w-5 h-5" /> Imprimer / PDF</button>
            </div>
            <button onClick={() => downloadFicheDocx(draft)} className="w-full mt-2 bg-white border border-emerald-300 text-emerald-700 py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
              <FileText className="w-5 h-5" /> Télécharger en Word (.docx)
            </button>
          </div>
        )}
      </main>
    </div>
  );
}

function KeyInput({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return <input type="password" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="w-full p-3 border border-gray-300 rounded-lg text-sm" />;
}

function Input({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="w-full p-3 border border-gray-300 rounded-lg text-sm" />
    </div>
  );
}

function Area({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <textarea value={value} onChange={e => onChange(e.target.value)} rows={3} className="w-full p-3 border border-gray-300 rounded-lg text-sm resize-none" />
    </div>
  );
}

function EditInput({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1">{label}</label>
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full p-2.5 border-2 border-amber-200 bg-amber-50/50 rounded-lg text-sm focus:border-amber-400 focus:outline-none" />
    </div>
  );
}

function EditArea({ label, value, onChange, rows = 4, big }: { label: string; value: string; onChange: (v: string) => void; rows?: number; big?: boolean }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1">{label}</label>
      <textarea value={value} onChange={e => onChange(e.target.value)} rows={rows}
        className={`w-full p-2.5 border-2 border-amber-200 bg-amber-50/50 rounded-lg focus:border-amber-400 focus:outline-none ${big ? 'font-mono text-xs leading-relaxed' : 'text-sm'}`} />
    </div>
  );
}

function Preview({ label, value, big }: { label: string; value: string; big?: boolean }) {
  // Met en évidence les lignes de phase (commençant par • ou MODULE/EXERCICE)
  const lines = (value || '-').split('\n');
  return (
    <div className="mb-3">
      <p className="text-xs font-semibold text-gray-500 mb-1">{label}</p>
      <div className={`${big ? 'text-sm' : 'text-sm'} text-gray-700 whitespace-pre-wrap bg-gray-50 rounded-lg p-3`}>
        {lines.map((line, i) => {
          const isPhase = /^•/.test(line) || /^(MODULE|EXERCICE)\b/i.test(line) || /^(— )/.test(line);
          const isSub = /^   —/.test(line) || /^(Remédiation|Corrigé|Barème|Critères|Évaluation|Quiz|Devoir)/i.test(line);
          return (
            <p key={i} className={isPhase ? 'font-bold text-gray-900 mt-1' : isSub ? 'text-gray-500' : ''}>
              {line || '\u00A0'}
            </p>
          );
        })}
      </div>
    </div>
  );
}
