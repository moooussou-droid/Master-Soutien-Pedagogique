/**
 * Suite de tests automatisés — Master Soutien Pédagogique
 * Vérifie le comportement réel des fonctions métier critiques :
 * bulletins, export Excel, import Excel, licences, chiffrement.
 */
import ExcelJS from 'exceljs';
import { computeBulletins, computeClassStats } from '../src/utils/bulletin';
import { generateEducMasterExcel, downloadExcel } from '../src/utils/excelGenerator';
import { importStudentsFromExcel, generateStudentTemplate } from '../src/utils/excelImporter';
import { generateAccessCode, verifyAccessCode, normalizeName, cleanCode } from '../src/utils/license';
import { encryptData, decryptData, hashText } from '../src/utils/crypto';
import { ClassData, Student, Subject, Note, findNoteInEvaluation, findBestNote } from '../src/utils/database';

let pass = 0;
let fail = 0;
const errors: string[] = [];

async function main() {

function ok(cond: boolean, label: string, detail = '') {
  if (cond) { pass++; console.log(`  ✅ ${label}`); }
  else { fail++; errors.push(label + (detail ? ` — ${detail}` : '')); console.log(`  ❌ ${label} ${detail}`); }
}
function section(t: string) { console.log(`\n═══ ${t} ═══`); }

// ---------- Helpers ----------
function makeSubject(id: string, name: string, obtenerMax: number, perfMax: number, order = 0): Subject {
  return { id, name, noteObtenueMax: obtenerMax, notePerfectionnementMax: perfMax, order };
}
function makeStudent(id: string, matricule: string, nom: string, prenoms: string): Student {
  return { id, matricule, nom, prenoms, createdAt: Date.now() };
}
function makeNote(id: string, studentId: string, subjectId: string, obt: number | null, perf: number | null, absent = false): Note {
  return { id, studentId, subjectId, noteObtenue: obt, notePerfectionnement: perf, absent, updatedAt: Date.now() };
}

// ============================================================
section('1. Bulletins — Primaire (CM/18 + CP/2 → /20)');
{
  const subjects = [
    makeSubject('s1', 'Dictée', 18, 2, 0),
    makeSubject('s2', 'Math', 18, 2, 1),
  ];
  const students = [
    makeStudent('e1', '001', 'AHOUANSOU', 'Jean'),
    makeStudent('e2', '002', 'KOFFI', 'Mariam'),
    makeStudent('e3', '003', 'DOSSOU', 'Ali'),
    makeStudent('e4', '004', 'SOSSOU', 'Paul'),
  ];
  const notes = [
    makeNote('n1', 'e1', 's1', 15, 1.5),   // 16.5/20
    makeNote('n2', 'e1', 's2', 16, 1),     // 17/20
    makeNote('n3', 'e2', 's1', 9, 0.5),    // 9.5/20
    makeNote('n4', 'e2', 's2', 10, 1),     // 11/20
    makeNote('n5', 'e3', 's1', null, null, true), // absent
    makeNote('n6', 'e3', 's2', 18, 2),     // 20/20
    makeNote('n7', 'e4', 's1', 16, 2),     // 18/20
    makeNote('n8', 'e4', 's2', 16, 2),     // 18/20
  ];
  const classData: ClassData = {
    id: 'c1', name: 'CE1 A', school: 'EPP Akassato', level: 'CE1',
    educationType: 'primaire', schoolYear: '2025-2026', sequence: '1er Trim.',
    students, subjects, notes, createdAt: 0, updatedAt: 0,
  };
  const b = computeBulletins(classData);
  const jean = b.find(x => x.student.id === 'e1')!;
  const mariam = b.find(x => x.student.id === 'e2')!;
  const ali = b.find(x => x.student.id === 'e3')!;
  const paul = b.find(x => x.student.id === 'e4')!;

  ok(Math.abs((jean.moyenne ?? 0) - 16.75) < 0.001, `Moyenne Jean = 16.75`, `obtenu ${jean.moyenne}`);
  ok(Math.abs((mariam.moyenne ?? 0) - 10.25) < 0.001, `Moyenne Mariam = 10.25`, `obtenu ${mariam.moyenne}`);
  ok(Math.abs((ali.moyenne ?? 0) - 20) < 0.001, `Moyenne Ali (1 note) = 20`, `obtenu ${ali.moyenne}`);
  ok(paul.rang === 2, `Rang Paul = 2 (18/20)`, `obtenu ${paul.rang}`);
  ok(jean.rang === 3, `Rang Jean = 3 (16.75/20)`, `obtenu ${jean.rang}`);
  ok(mariam.rang === 4, `Rang Mariam = 4`, `obtenu ${mariam.rang}`);
  ok(ali.rang === 1, `Rang Ali = 1 (20/20)`, `obtenu ${ali.rang}`);
  ok(jean.mention === 'Très Bien', `Mention Jean = Très Bien`, `obtenu ${jean.mention}`);
  ok(jean.effectif === 4, `Effectif = 4`);
  ok(ali.results.find(r => r.subject.id === 's1')!.absent === true, `Absent marqué pour Dictée (Ali)`);
  ok(ali.results.find(r => r.subject.id === 's1')!.total === null, `Total null si absent`);

  // Ex-aequo : Jean et Sosso ont 16.75 ? Non — Sosso 18. Testons ex-aequo direct.
  const stats = computeClassStats(b);
  ok(Math.abs((stats.moyenneClasse ?? 0) - 16.25) < 0.001, `Moyenne de classe = 16.25`, `obtenu ${stats.moyenneClasse}`);
  ok(stats.admis === 4, `Admis = 4/4`, `obtenu ${stats.admis}`);
  ok(Math.abs(stats.tauxReussite - 100) < 0.001, `Taux de réussite = 100%`);
}

section('1bis. Bulletins — Ex-aequo (mêmes moyennes → même rang)');
{
  const subjects = [makeSubject('s1', 'Dictée', 18, 2, 0)];
  const students = [
    makeStudent('e1', '001', 'AMOUSSOU', 'A'),
    makeStudent('e2', '002', 'AMOUSSOU', 'B'),
    makeStudent('e3', '003', 'GNANSOUNOU', 'C'),
  ];
  const notes = [
    makeNote('n1', 'e1', 's1', 12, 2), // 14/20
    makeNote('n2', 'e2', 's1', 12, 2), // 14/20 → ex-aequo avec e1
    makeNote('n3', 'e3', 's1', 10, 0), // 10/20 → 3e
  ];
  const classData: ClassData = {
    id: 'c1b', name: 'CI A', school: 'EPP X', level: 'CI', educationType: 'primaire',
    schoolYear: '2025-2026', sequence: '1er Trim.', students, subjects, notes, createdAt: 0, updatedAt: 0,
  };
  const b = computeBulletins(classData);
  const a = b.find(x => x.student.id === 'e1')!;
  const bb = b.find(x => x.student.id === 'e2')!;
  const c = b.find(x => x.student.id === 'e3')!;
  ok(a.rang === 1 && bb.rang === 1, `Ex-aequo : rang 1 pour les deux (${a.rang}/${bb.rang})`);
  ok(c.rang === 3, `Le suivant a le rang 3 (pas 2) : ${c.rang}`);
}

section('2. Bulletins — Secondaire (notes /20 avec coefficients)');
{
  const subjects = [
    { ...makeSubject('s1', 'Mathématiques', 20, 0, 0), coefficient: 2 },
    { ...makeSubject('s2', 'Français', 20, 0, 1), coefficient: 1 },
  ] as Subject[];
  const students = [makeStudent('e1', 'A1', 'NZOUMANOU', 'Rachid')];
  const notes = [makeNote('n1', 'e1', 's1', 12, null), makeNote('n2', 'e1', 's2', 10, null)];
  const classData: ClassData = {
    id: 'c2', name: '3ème B', school: 'CEG1', level: '3ème', educationType: 'secondaire',
    schoolYear: '2025-2026', sequence: '1er Trim.', students, subjects, notes, createdAt: 0, updatedAt: 0,
  };
  const b = computeBulletins(classData);
  const r = b[0];
  ok(Math.abs((r.moyenne ?? 0) - 11.3333) < 0.01, `Moyenne pondérée = 11.33`, `obtenu ${r.moyenne}`);
  ok(r.totalPoints === 34, `Total points = 24+10 = 34`, `obtenu ${r.totalPoints}`);
  ok(r.totalPossible === 60, `Total possible = 60`, `obtenu ${r.totalPossible}`);
  ok(r.totalCoef === 3, `Somme coefficients = 3`);
  ok(r.mention === 'Passable', `Mention = Passable`);
}

section('3. Export Excel — format EducMaster');
{
  // 13 matières (9 par défaut + 4 ajoutées) → 29 colonnes → test limite A..Z
  const subjects: Subject[] = [];
  const names = ['Dictée','Math','Expression écrite','Compréhension de l\'écrit','EST','ES','EA (Oral)','EA (Dessin/Couture)','EPS','Anglais','Informatique','Musique','SVT'];
  names.forEach((n, i) => subjects.push(makeSubject(`s${i}`, n, 18, 2, i)));
  const students = [
    makeStudent('e1', '001234', 'AHOUANSOU', 'Jean'),
    makeStudent('e2', '567890', 'KOFFI', 'Mariam Aïcha'),
  ];
  const notes = [
    makeNote('n1', 'e1', 's0', 15, 1), makeNote('n2', 'e1', 's1', 16, 2),
    makeNote('n3', 'e2', 's0', null, null, true),
  ];
  const classData: ClassData = {
    id: 'c3', name: 'CE1 A', school: 'EPP Akassato', level: 'CE1', educationType: 'primaire',
    schoolYear: '2025-2026', sequence: '1er Trim.', students, subjects, notes, createdAt: 0, updatedAt: 0,
  };
  try {
    const { blob, filename } = await generateEducMasterExcel(classData);
    ok(true, 'Export généré sans erreur (13 matières → colonnes > Z)');
    ok(/^\d{14}_model-importation-note_\d{4}-epp-.*\.xlsx$/.test(filename), `Nom de fichier conforme : ${filename}`);
    ok(filename.includes('epp_akassato') && filename.includes('ce1_a'), 'École/Classe nettoyées dans le nom');

    // Relire le fichier avec ExcelJS pour vérifier le contenu
    const buf = Buffer.from(await blob.arrayBuffer());
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(buf as any);
    const sheetNames = wb.worksheets.map(w => w.name);
    ok(sheetNames.join('|') === 'Evaluation formative 1|Evaluation sommative 1|Evaluation sommative 2|Evaluation sommative 3', `4 feuilles d'évaluation aux noms officiels : ${sheetNames.join(' | ')}`);
    const ws = wb.worksheets[0];
    ok(ws.getCell('A1').value === 'Matricule' && ws.getCell('B1').value === 'Nom' && ws.getCell('C1').value === 'Prénoms', 'En-têtes A1/B1/C1 = Matricule/Nom/Prénoms');
    ok(ws.getCell('D1').value === 'Dictée' && ws.getCell('D2').value === 'Note obtenue' && ws.getCell('E2').value === 'Note perf.', 'En-têtes matière + sous-en-têtes du modèle officiel');
    ok(ws.getCell('D1').isMerged === true, 'Cellule matière fusionnée');
    ok(ws.getCell('AA1') !== undefined && ws.getCell('AA2') !== undefined, 'Colonnes au-delà de Z présentes');
    // Matières triées dans l'ordre officiel EducMaster
    ok(ws.getCell('D1').value === 'Dictée', 'Ordre officiel respecté (Dictée en 1re matière)');
    // Les notes (historiques, sans évaluation) sont exportées dans la feuille
    // « Evaluation sommative 1 » (évaluation par défaut de la compatibilité).
    const ws1 = wb.worksheets[1];
    ok(ws1 && ws1.name === 'Evaluation sommative 1', 'Feuille sommative 1 présente (notes historiques)');
    ok(ws1.getCell('A3').value === '001234', 'Matricule préservé (zéros initiaux)');
    ok(ws1.getCell('A3').numFmt === '@', 'Colonne matricule = format texte');
    ok(ws1.getCell('B3').value === 'AHOUANSOU', 'Nom en majuscules');
    ok(ws1.getCell('D3').value === 15 && ws1.getCell('E3').value === 1, 'Note obtenue/perf correcte ligne 3');
    ok(ws1.getCell('D4').value === 'ABS' && ws1.getCell('E4').value === 'ABS', 'Absent → ABS ABS');
  } catch (e: any) {
    ok(false, 'Export Excel sans erreur', String(e?.message || e));
  }
}

section('4. Import Excel — format EducMaster (2 lignes d\'en-tête)');
{
  // Construit un fichier façon EducMaster : ligne 1 matières fusionnées, ligne 2 sous-en-têtes
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Notes');
  ws.mergeCells('A1:A2'); ws.mergeCells('B1:B2'); ws.mergeCells('C1:C2');
  ws.getCell('A1').value = 'Matricule';
  ws.getCell('B1').value = 'Nom';
  ws.getCell('C1').value = 'Prénoms';
  const matieres = ['Dictée', 'Math'];
  let col = 4;
  for (const m of matieres) {
    ws.mergeCells(1, col, 1, col + 1);
    ws.getCell(1, col).value = m;
    ws.getCell(2, col).value = 'Note obtenue';
    ws.getCell(2, col + 1).value = 'Note perfectionnement';
    col += 2;
  }
  ws.getCell('A3').value = '001234'; ws.getCell('A3').numFmt = '@';
  ws.getCell('B3').value = 'AHOUANSOU'; ws.getCell('C3').value = 'Jean';
  ws.getCell('D3').value = 15; ws.getCell('E3').value = 1.5;
  ws.getCell('F3').value = 16; ws.getCell('G3').value = 'ABS';
  ws.getCell('A4').value = '567890'; ws.getCell('B4').value = 'KOFFI'; ws.getCell('C4').value = 'Mariam';
  ws.getCell('D4').value = 9; ws.getCell('E4').value = 0;

  const buf = Buffer.from(await wb.xlsx.writeBuffer());
  const file = new File([buf], 'educmaster.xlsx');
  const subjects = [makeSubject('s1', 'Dictée', 18, 2, 0), makeSubject('s2', 'Math', 18, 2, 1)];

  const result = await importStudentsFromExcel(file, subjects);
  ok(result.importedRows === 2, `2 élèves importés`, `obtenu ${result.importedRows}`);
  ok(result.students[0].matricule === '001234', 'Matricule 001234 préservé (texte)');
  ok(result.students[1].matricule === '567890', 'Matricule 567890');
  ok((result.detectedSubjects as string[])?.length === 2, `2 matières détectées : ${result.detectedSubjects.join(', ')}`);
  const noteJean = result.parsedNotes.find(n => n.studentId === result.students[0].id && n.subjectName === 'Dictée')!;
  ok(noteJean?.noteObtenue === 15 && noteJean?.notePerfectionnement === 1.5, 'Notes Dictée Jean = 15 / 1.5');
  ok(noteJean?.subjectId === 's1', 'Matière associée à la classe (s1)');
  const noteAbs = result.parsedNotes.find(n => n.studentId === result.students[0].id && n.subjectName === 'Math')!;
  ok(noteAbs?.absent === true, 'ABS détecté comme absence');
  ok(result.errors.length === 0, `Aucune erreur d\'import`, result.errors.join(' | '));
}

section('5. Import Excel — modèle vierge généré par l\'app');
{
  const tmpl = await generateStudentTemplate();
  const file = new File([await tmpl.arrayBuffer()], 'modele.xlsx');
  const result = await importStudentsFromExcel(file, []);
  ok(result.importedRows === 3, `3 exemples importés`, `obtenu ${result.importedRows}`);
  ok(result.students[0].matricule === '117042400', 'Matricule exemple préservé');
}

section('6. Codes d\'accès (licence)');
{
  const code = await generateAccessCode('Koffi Jean');
  ok(/^[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}$/.test(code), `Format XXXX-XXXX-XXXX-XXXX : ${code}`);
  ok(await verifyAccessCode('Koffi Jean', code), 'Code valide avec nom exact');
  ok(await verifyAccessCode('  koffi jean  ', code), 'Code valide avec casse/espaces tolérants');
  ok(await verifyAccessCode('Koffi Jeann', code) === false, 'Nom différent → refusé');
  ok(await verifyAccessCode('Koffi Jean', 'AAAA-BBBB-CCCC-DDDD') === false, 'Code faux → refusé');
  ok(normalizeName('  Kévin-Faustin   Dossa ') === 'kevin-faustin dossa', 'Normalisation nom (accents/casse)');
  ok(cleanCode('abcd-EFGH 1234') === 'ABCDEFGH1234', 'Nettoyage code');
  // Deux noms différents → codes différents
  const autre = await generateAccessCode('Koffi Marie');
  ok(code !== autre, 'Codes différents pour noms différents');
}

section('7. Chiffrement de bout en bout');
{
  const secret = 'MonMotDePasseSecret';
  const data = JSON.stringify({ classe: 'CE1 A', eleves: [{ nom: 'AHOUANSOU Jean', note: 15.5 }] });
  const enc = await encryptData(data, secret);
  ok(typeof enc === 'string' && enc.length > 100, `Chiffré (base64, ${enc.length} chars)`);
  const dec = await decryptData(enc, secret);
  ok(dec === data, 'Aller-retour chiffrement/déchiffrement OK');
  let threw = false;
  try { await decryptData(enc, 'Mauvais mot de passe'); } catch { threw = true; }
  ok(threw, 'Mauvais mot de passe → erreur (données illisibles)');
  const h1 = await hashText('test'); const h2 = await hashText('test');
  ok(h1 === h2 && h1.length === 44, 'hashText déterministe (SHA-256 base64)');
}

section('8. Génération IA locale (moteur pédagogique APC)');
{
  const { generateLocalLesson } = await import('../src/utils/localPedagogicalEngine');

  // Fiche Mathématiques CE2
  const plan = generateLocalLesson({
    niveau: 'CE2', matiere: 'Mathématiques', theme: 'Addition avec retenue',
    duree: '60 min', objectif: '', consignes: '', generationKind: 'fiche', standard: 'APC_BENIN',
  });
  ok(plan.titre.includes('Addition avec retenue'), `Titre : ${plan.titre}`);
  ok(plan.matiere === 'Mathématiques' && plan.classe === 'CE2', 'Classe et matière correctes');
  ok(plan.competence.toLowerCase().includes('ce2'), 'Compétence adaptée au niveau (CE2)');
  ok(plan.deroulement.includes('Situation-problème'), 'Structure APC : situation-problème');
  ok(plan.deroulement.includes('Mise en commun') && plan.deroulement.includes('Structuration'), 'Structure APC : mise en commun + structuration');
  ok(plan.deroulement.includes('(15 min)') || /\d+ min/.test(plan.deroulement), 'Durées de phases calculées');
  ok(plan.deroulement.includes('Enseignant') && plan.deroulement.includes('Apprenants'), 'Activités enseignant / apprenants');
  ok(plan.evaluation.includes('Évaluation') && plan.evaluation.includes('Remédiation'), 'Évaluation + remédiation');
  ok(plan.materiel.length > 10, 'Matériel spécifique à la matière');

  // Dictée
  const dictee = generateLocalLesson({ niveau: 'CM1', matiere: 'Dictée', theme: 'les homophones', duree: '45 min', objectif: '', consignes: '', generationKind: 'fiche' });
  ok(dictee.evaluation.toLowerCase().includes('orthographe'), 'Évaluation de dictée avec critères orthographe');

  // Exercices
  const exos = generateLocalLesson({ niveau: 'CM2', matiere: 'Mathématiques', theme: 'les fractions', duree: '45 min', objectif: '', consignes: '', generationKind: 'exercices' });
  ok(exos.evaluation.includes('EXERCICE 1') && exos.evaluation.includes('EXERCICE 3'), 'Exercices gradués (facile/moyen/difficile)');
  ok(exos.evaluation.includes('Corrigé'), 'Corrigés inclus');
  ok(exos.evaluation.includes('Barème') && exos.evaluation.includes('20 points'), 'Barème sur 20');

  // Cours en ligne
  const cours = generateLocalLesson({ niveau: '6ème', matiere: 'Français', theme: 'le présent', duree: '45 min', objectif: '', consignes: '', generationKind: 'cours_en_ligne' });
  ok(cours.deroulement.includes('MODULE 6'), 'Cours en ligne structuré en 6 modules');

  // Matière inconnue → générique, sans erreur
  const inconnu = generateLocalLesson({ niveau: 'CE1', matiere: 'Dessin', theme: 'le paysage', duree: '30 min', objectif: '', consignes: '', generationKind: 'fiche' });
  ok(inconnu.titre.includes('le paysage'), `Matière inconnue → gabarit générique (${inconnu.titre})`);
}

section('8bis. Google AI Studio — config des modèles');
{
  const { GEMINI_MODELS, GEMINI_FREE_KEY_URL, buildLessonPrompt } = await import('../src/utils/aiLessonGenerator');
  ok(GEMINI_MODELS.length >= 3, `${GEMINI_MODELS.length} modèles Gemini proposés`);
  ok(GEMINI_MODELS[0].id === 'gemini-2.5-flash', 'Modèle gratuit recommandé en premier (2.5 Flash)');
  ok(GEMINI_FREE_KEY_URL.includes('aistudio.google.com'), 'Lien clé gratuite correct');
  const prompt = buildLessonPrompt({
    niveau: 'CE1', matiere: 'Mathématiques', theme: 'Addition avec retenue',
    duree: '45 min', objectif: '', consignes: '', generationKind: 'fiche', standard: 'APC_BENIN',
  });
  ok(prompt.includes('Addition avec retenue') && prompt.includes('CE1'), 'Prompt construit avec thème et niveau');
}

section('9. Export Word (.docx) des fiches');
{
  const { buildDocxXml, printFiche } = await import('../src/utils/ficheExport');
  const JSZip = (await import('jszip')).default;
  const plan = {
    titre: 'Fiche test <&> "spéciale"', classe: 'CE1', matiere: 'Math', domaine: 'x', duree: '45 min',
    competence: 'Compétence test', objectif: 'Objectif test', materiel: 'Matériel test',
    deroulement: '• Phase 1 (10 min)\n   — Enseignant : explique\n   — Apprenants : écoutent', evaluation: 'Évaluation test',
  };

  const xml = buildDocxXml(plan as any);
  ok(xml.startsWith('<?xml') && xml.includes('<w:document ') && xml.includes('</w:document>'), 'XML document.xml bien formé');
  ok(xml.includes('Fiche test &lt;&amp;&gt; &quot;spéciale&quot;'), 'Échappement XML des caractères spéciaux');
  ok(xml.includes('Phase 1') && xml.includes('Enseignant'), 'Contenu du déroulement présent');

  // Le zip complet se construit sans erreur
  const { downloadFicheDocx } = await import('../src/utils/ficheExport');
  const originalCreates = (globalThis as any).URL?.createObjectURL;
  try {
    (globalThis as any).URL = Object.assign(Object.create(URL), { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} });
    (globalThis as any).document = { createElement: () => ({ href: '', download: '', rel: '', style: {}, click: () => {} }), body: { appendChild: () => {}, removeChild: () => {} } };
    let okDownload = false;
    await downloadFicheDocx(plan as any);
    okDownload = true;
    ok(okDownload, 'Téléchargement .docx : génération du zip sans erreur');
  } catch (e: any) {
    ok(false, 'Téléchargement .docx', String(e?.message || e));
  } finally {
    (globalThis as any).URL = URL;
    (globalThis as any).document = undefined;
  }

  let printOk = false;
  try {
    (globalThis as any).window = { open: () => ({ document: { open: () => {}, write: () => {}, close: () => {} }, close: () => {} }) };
    printFiche(plan as any);
    printOk = true;
  } catch { printOk = false; }
  (globalThis as any).window = undefined;
  ok(printOk, 'Impression : HTML de la fiche construit sans erreur');
}

section('10. Export groupé Bulletins (Excel récap + Word multi)');
{
  const { exportBulletinsExcel, exportBulletinsDocx } = await import('../src/utils/bulletinExport');
  const ExcelJS2 = (await import('exceljs')).default;

  const subjects2 = [
    { ...makeSubject('s1', 'Dictée', 18, 2, 0) },
    { ...makeSubject('s2', 'Math', 18, 2, 1) },
  ];
  const students2 = [
    { ...makeStudent('e1', '001234', 'AHOUANSOU', 'Jean'), sexe: 'M' as const, dateNaissance: '2015-03-12' },
    { ...makeStudent('e2', '567890', 'KOFFI', 'Mariam'), sexe: 'F' as const, dateNaissance: '2015-09-25' },
    { ...makeStudent('e3', '999999', 'DOSSOU', 'Ali') },
  ];
  const notes2 = [
    makeNote('n1', 'e1', 's1', 15, 1.5), makeNote('n2', 'e1', 's2', 16, 1),
    makeNote('n3', 'e2', 's1', 9, 0.5), makeNote('n4', 'e2', 's2', 10, 1),
    makeNote('n5', 'e3', 's1', null, null, true), makeNote('n6', 'e3', 's2', 18, 2),
  ];
  const classData2: ClassData = {
    id: 'c-bull', name: 'CE1 A', school: 'EPP Test', level: 'CE1', educationType: 'primaire',
    schoolYear: '2025-2026', sequence: '1er Trim.', students: students2, subjects: subjects2, notes: notes2, createdAt: 0, updatedAt: 0,
  };
  const bulletins2 = computeBulletins(classData2);
  ok(bulletins2.length === 3, '3 bulletins calculés');

  // --- Excel ---
  const originalCreate2 = (globalThis as any).URL?.createObjectURL;
  let excelBlob: Blob | null = null;
  try {
    (globalThis as any).URL = Object.assign(Object.create(URL), {
      createObjectURL: (b: Blob) => { excelBlob = b; return 'blob:excel'; },
      revokeObjectURL: () => {},
    });
    (globalThis as any).document = { createElement: () => ({ href: '', download: '', rel: '', style: {}, click: () => {} }), body: { appendChild: () => {}, removeChild: () => {} } };
    await exportBulletinsExcel(classData2, bulletins2);
  } finally {
    (globalThis as any).URL = URL;
    (globalThis as any).document = undefined;
  }
  ok(excelBlob instanceof Blob && excelBlob.type.includes('spreadsheetml'), `Excel récap généré (${excelBlob?.size} octets)`);
  if (excelBlob) {
    const wb2 = new ExcelJS2.Workbook();
    await wb2.xlsx.load(Buffer.from(await excelBlob.arrayBuffer()) as any);
    const ws = wb2.getWorksheet('Bulletins');
    ok(!!ws, 'Feuille « Bulletins » présente');
    ok(ws!.getCell('A1').value === 'N°' && ws!.getCell('C1').value === 'Nom', 'En-têtes corrects (N°, Nom)');
    const moyCol = [7, 8, 9, 10].find((c) => ws!.getCell(1, c).value === 'Moyenne /20');
    ok(!!moyCol, `Colonne Moyenne présente (col ${moyCol})`);
    ok(ws!.getCell('A2').value === 1 && String(ws!.getCell('B2').value) === '001234', 'Matricule zéro initial préservé (texte)');
    ok(ws!.getCell('C2').value === 'AHOUANSOU', 'Nom élève présent');
    ok(ws!.getCell('E2').value === 'M' && ws!.getCell('F2').value === '12/03/2015', 'Sexe + date de naissance formatées (M, 12/03/2015)');
    const ws2f = wb2.getWorksheet('Synthèse');
    ok(!!ws2f, 'Feuille « Synthèse » présente');
    const synCell = ws2f!.getCell('B8') as any; // Moyenne de classe
    ok(synCell !== undefined, 'Synthèse : moyennes/mentions calculées');
  }

  // --- Word ---
  let docxBlob: Blob | null = null;
  try {
    (globalThis as any).URL = Object.assign(Object.create(URL), {
      createObjectURL: (b: Blob) => { docxBlob = b; return 'blob:docx'; },
      revokeObjectURL: () => {},
    });
    (globalThis as any).document = { createElement: () => ({ href: '', download: '', rel: '', style: {}, click: () => {} }), body: { appendChild: () => {}, removeChild: () => {} } };
    await exportBulletinsDocx(classData2, bulletins2);
  } finally {
    (globalThis as any).URL = URL;
    (globalThis as any).document = undefined;
  }
  ok(docxBlob instanceof Blob && docxBlob.type.includes('officedocument.wordprocessingml'), `Word multi-bulletins généré (${docxBlob?.size} octets)`);
}

section('11. Champs sexe/naissance dans les données élève');
{
  const { Student } = await import('../src/utils/database');
  const s: Student = { id: 'x', matricule: '001', nom: 'Z', prenoms: 'A', sexe: 'F', dateNaissance: '2014-01-02', createdAt: 0 };
  ok(s.sexe === 'F' && s.dateNaissance === '2014-01-02', 'Champs sexe et dateNaissance stockés');
  const s2: Student = { id: 'y', matricule: '002', nom: 'B', prenoms: 'C', createdAt: 0 };
  ok(s2.sexe === undefined, 'Champs optionnels (aucune régression pour anciens élèves)');
}

section('12. Statistiques cohérentes avec les bulletins (barèmes /20)');
{
  const { subjectTotal } = await import('../src/utils/bulletin');

  // Matière primaire standard : 18+2 = 20 → pas de conversion
  const s1 = makeSubject('s1', 'Dictée', 18, 2, 0);
  const n1 = makeNote('n1', 'e1', 's1', 15, 1.5);
  ok(subjectTotal(n1, s1) === 16.5, 'Primaire standard : 15+1.5 = 16.5/20');

  // Matière modifiée par l'enseignant : note /10 (préscolaire) → conversion /20
  const s2 = makeSubject('s2', 'Motricité', 10, 0, 0);
  const n2 = makeNote('n2', 'e1', 's2', 8, null);
  ok(Math.abs((subjectTotal(n2, s2) ?? 0) - 16) < 0.001, 'Préscolaire /10 : 8/10 → 16/20 (conversion)');

  // Matière /20 (secondaire) : pas de changement
  const s3 = makeSubject('s3', 'Mathématiques', 20, 0, 0);
  const n3 = makeNote('n3', 'e1', 's3', 14, null);
  ok(subjectTotal(n3, s3) === 14, 'Secondaire /20 : 14 → 14/20');

  // Absent → null
  const n4 = makeNote('n4', 'e1', 's1', null, null, true);
  ok(subjectTotal(n4, s1) === null, 'Absent → null (exclu des moyennes)');

  // Calcul des bulletins avec matière /10 → moyenne ramenée sur 20
  const subjects = [s2];
  const students = [makeStudent('e1', '001', 'TEST', 'Un')];
  const notes = [n2];
  const classDataX: ClassData = {
    id: 'c-stats', name: 'Maternelle 1', school: 'EPP X', level: 'Maternelle 1', educationType: 'prescolaire',
    schoolYear: '2025-2026', sequence: '1er Trim.', students, subjects, notes, createdAt: 0, updatedAt: 0,
  };
  const b = computeBulletins(classDataX);
  ok(Math.abs((b[0].moyenne ?? 0) - 16) < 0.001, `Moyenne bulletin avec barème /10 = 16/20 (obtenu ${b[0].moyenne})`);
}

section('13. Présences — statistiques & exports (Excel registre + PV Word)');
{
  const {
    computeStudentAttendance, computeClassAttendance, availableMonths, recordsForMonth,
    exportAttendanceExcel, exportAttendanceDocx,
  } = await import('../src/utils/attendanceExport');
  const ExcelJS3 = (await import('exceljs')).default;

  const days: any[] = [
    { id: 'a1', classId: 'c1', date: '2026-09-01', entries: [
      { studentId: 'e1', status: 'present' }, { studentId: 'e2', status: 'absent_injustifiee' },
    ]},
    { id: 'a2', classId: 'c1', date: '2026-09-02', entries: [
      { studentId: 'e1', status: 'retard' }, { studentId: 'e2', status: 'present' },
    ]},
    { id: 'a3', classId: 'c1', date: '2026-09-03', entries: [
      { studentId: 'e1', status: 'absent_justifiee', motif: 'Maladie' }, { studentId: 'e2', status: 'present' },
    ]},
    { id: 'a4', classId: 'c1', date: '2026-10-05', entries: [ // autre mois → exclu
      { studentId: 'e1', status: 'present' }, { studentId: 'e2', status: 'present' },
    ]},
  ];

  const st1 = computeStudentAttendance(days.slice(0, 3), 'e1');
  ok(st1.present === 1 && st1.retard === 1 && st1.absJust === 1 && st1.absInjust === 0, `Statistiques élève 1 (P/R/ABJ) : ${JSON.stringify(st1)}`);
  ok(st1.taux === 67, `Taux élève 1 = 67% (obtenu ${st1.taux})`);
  const st2 = computeStudentAttendance(days.slice(0, 3), 'e2');
  ok(st2.absInjust === 1 && st2.present === 2, `Statistiques élève 2 (injustifiée + 2 présents)`);
  ok(st2.taux === 67, `Taux élève 2 = 67%`);

  ok(availableMonths(days, 'c1').length === 2 && availableMonths(days, 'c1')[0] === '2026-10', 'Mois disponibles détectés (2)');
  ok(recordsForMonth(days, 'c1', '2026-09').length === 3, 'Filtre septembre : 3 jours');
  ok(recordsForMonth(days, 'c1', '2026-10').length === 1, 'Filtre octobre : 1 jour');

  // Export Excel
  const classDataP: ClassData = {
    id: 'c1', name: 'CE1 A', school: 'EPP Test', level: 'CE1', educationType: 'primaire',
    schoolYear: '2025-2026', sequence: '1er Trim.',
    students: [
      makeStudent('e1', '001234', 'AHOUANSOU', 'Jean'),
      makeStudent('e2', '567890', 'KOFFI', 'Mariam'),
    ], subjects: [], notes: [], createdAt: 0, updatedAt: 0,
  };
  let excelBlob: Blob | null = null;
  const savedURL = (globalThis as any).URL;
  try {
    (globalThis as any).URL = Object.assign(Object.create(URL), { createObjectURL: (b: Blob) => { excelBlob = b; return 'blob:x'; }, revokeObjectURL: () => {} });
    (globalThis as any).document = { createElement: () => ({ href: '', download: '', rel: '', style: {}, click: () => {} }), body: { appendChild: () => {}, removeChild: () => {} } };
    await exportAttendanceExcel(classDataP, recordsForMonth(days, 'c1', '2026-09'), '2026-09');
  } finally {
    (globalThis as any).URL = savedURL;
    (globalThis as any).document = undefined;
  }
  ok(excelBlob instanceof Blob && excelBlob.type.includes('spreadsheetml'), `Registre Excel généré (${excelBlob?.size} octets)`);
  if (excelBlob) {
    const wb = new ExcelJS3.Workbook();
    await wb.xlsx.load(Buffer.from(await excelBlob.arrayBuffer()) as any);
    const ws = wb.getWorksheet('Registre');
    ok(!!ws && ws.getCell('C1').value === 'Nom & Prénoms', 'Feuille Registre avec en-têtes');
    // Colonnes : A=N° B=Matricule C=Nom D..F=jours (01, 02, 03/09) G=Taux
    ok(ws!.getCell('G1').value === 'Taux %', `Colonne Taux présente (G1 = ${ws!.getCell('G1').value})`);
    ok(ws!.getCell('D2').value === 'P', `Jour 1 (01/09) = P (obtenu ${ws!.getCell('D2').value})`);
    ok(ws!.getCell('E2').value === 'R', `Jour 2 (02/09) = R (obtenu ${ws!.getCell('E2').value})`);
    ok(ws!.getCell('F2').value === 'AB', `Jour 3 (03/09) = AB (obtenu ${ws!.getCell('F2').value})`);
    ok(ws!.getCell('D3').value === 'A', `Élève 2 jour 1 = A (obtenu ${ws!.getCell('D3').value})`);
    ok(!!wb.getWorksheet('Synthèse'), 'Feuille Synthèse présente');
  }

  // Export Word PV
  let docxBlob: Blob | null = null;
  try {
    (globalThis as any).URL = Object.assign(Object.create(URL), { createObjectURL: (b: Blob) => { docxBlob = b; return 'blob:w'; }, revokeObjectURL: () => {} });
    (globalThis as any).document = { createElement: () => ({ href: '', download: '', rel: '', style: {}, click: () => {} }), body: { appendChild: () => {}, removeChild: () => {} } };
    await exportAttendanceDocx(classDataP, recordsForMonth(days, 'c1', '2026-09'), '2026-09');
  } finally {
    (globalThis as any).URL = savedURL;
    (globalThis as any).document = undefined;
  }
  ok(docxBlob instanceof Blob && docxBlob.type.includes('wordprocessingml'), `PV Word généré (${docxBlob?.size} octets)`);
}

section('14. Illustrations locales (svgIllustration) — images réparées');
{
  const illustrate = (await import('../src/utils/svgIllustration')).default;

  const img = illustrate('Mathématiques', 'Addition');
  ok(img.startsWith('data:image/svg+xml;charset=utf-8,'), 'Illustration = data URI SVG (aucun réseau)');
  const decoded = decodeURIComponent(img.split(',')[1]);
  ok(decoded.includes('<svg') && decoded.includes('</svg>'), 'SVG bien formé');
  ok(decoded.includes('🔢'), 'Emoji thématique pour Mathématiques (🔢)');
  ok(decoded.includes('linearGradient'), 'Dégradé de couleur (charte béninoise)');
  ok(decoded.includes('A') && decoded.includes('initials') === false, 'Initiales présentes');

  const img2 = illustrate('Dictée', 'Dictée');
  ok(decodeURIComponent(img2.split(',')[1]).includes('📖'), 'Emoji thématique Dictée (📖)');

  const img3 = illustrate('santé hygiène microbe');
  ok(decodeURIComponent(img3.split(',')[1]).includes('🩺'), 'Emoji thématique santé (🩺)');

  ok(illustrate('Test', 'X') === illustrate('Test', 'X'), 'Déterministe (même entrée → même image)');
  const img4 = illustrate('test différent', 'Y');
  ok(typeof img4 === 'string' && img4.length > 500, 'Image générée pour toute entrée');
}

section('15. Courrier aux parents — export Word officiel avec logo');
{
  const { exportCorrespondanceDocx } = await import('../src/utils/correspondenceExport');
  const JSZip2 = (await import('jszip')).default;

  // PNG 1x1 valide (logo de test)
  const tinyPng = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

  const doc = {
    templateLabel: 'Convocation Réunion APE',
    parentName: 'M. DOSSOU',
    studentName: 'Ali DOSSOU',
    className: 'CE1 A',
    date: '2026-09-10',
    school: 'EPP Akassato',
    circonscription: 'Circonscription d\'Abomey-Calavi',
    teacherName: 'M. KOFFI',
    schoolYear: '2025-2026',
    logoDataUrl: `data:image/png;base64,${tinyPng}`,
    body: 'Madame, Monsieur, vous êtes cordialement invité(e) à prendre part à la réunion de l\'APE.',
  };

  let docxBlob: Blob | null = null;
  const savedURL = (globalThis as any).URL;
  try {
    (globalThis as any).URL = Object.assign(Object.create(URL), {
      createObjectURL: (b: Blob) => { docxBlob = b; return 'blob:corr'; },
      revokeObjectURL: () => {},
    });
    (globalThis as any).document = { createElement: () => ({ href: '', download: '', rel: '', style: {}, click: () => {} }), body: { appendChild: () => {}, removeChild: () => {} } };
    await exportCorrespondanceDocx(doc);
  } finally {
    (globalThis as any).URL = savedURL;
    (globalThis as any).document = undefined;
  }
  ok(docxBlob instanceof Blob && docxBlob.type.includes('wordprocessingml'), `Word courrier généré (${docxBlob?.size} octets)`);

  if (docxBlob) {
    const zip = await JSZip2.loadAsync(await docxBlob.arrayBuffer());
    const xml = await zip.file('word/document.xml')!.async('string');
    ok(xml.includes('RÉPUBLIQUE DU BÉNIN'), 'En-tête officiel présent');
    ok(xml.includes('OBJET') && xml.includes('Convocation Réunion APE'), 'Objet du courrier présent');
    ok(xml.includes('COUPON RÉPONSE') && xml.includes('Signature du parent'), 'Coupon réponse avec signature');
    ok(xml.includes('EPP Akassato') && xml.includes('CE1 A'), 'École et classe présentes');
    ok(xml.includes('Madame, Monsieur, vous êtes cordialement invité(e)'), 'Corps du courrier intact');
    const hasImage = !!zip.file('word/media/image1.png');
    ok(hasImage, 'Logo école intégré (media/image1.png)');
    const rels = await zip.file('_rels/.rels')!.async('string');
    ok(rels.includes('rIdImg') && rels.includes('image1.png'), 'Relation image correcte');
  }
}

section('16. Calendrier — jours fériés officiels du Bénin');
{
  const fs = (await import('fs')).default;
  const path = (await import('path')).default;
  const src = fs.readFileSync(path.join(process.cwd(), 'src/components/SchoolCalendarScreen.tsx'), 'utf8');

  const ids = [...src.matchAll(/id: '([^']+)'/g)].map(m => m[1]);
  ok(ids.length === ids.length && new Set(ids).size === ids.length, `Identifiants d'événements uniques (${ids.length})`);

  const must = ['fete-nationale', 'jour-an', 'travail', 'assomption', 'toussaint', 'noel', 'korite-2026', 'tabaski-2026'];
  const missing = must.filter(id => !src.includes(`id: '${id}'`));
  ok(missing.length === 0, `Fêtes officielles du Bénin présentes${missing.length ? ' — manquent : ' + missing.join(', ') : ''}`);
  ok(src.includes('2026-08-01'), 'Fête Nationale au 1er août 2026');
  ok(src.includes('storedIds'), 'Fusion intelligente avec événements existants');
}

section('17. Profil enrichi — circonscription/commune propagées + réglages stockage/cloud');
{
  const fs2 = (await import('fs')).default;
  const path2 = (await import('path')).default;
  const read = (p: string) => fs2.readFileSync(path2.join(process.cwd(), p), 'utf8');

  // 1) Interface UserProfile avec circonscription + commune
  const profileSrc = read('src/utils/userProfile.ts');
  ok(profileSrc.includes('circonscription?: string'), 'Profil : champ circonscription dans UserProfile');
  ok(profileSrc.includes('commune?: string'), 'Profil : champ commune dans UserProfile');

  // 2) Sauvegarde/relecture réelle (localStorage simulé)
  const store = new Map<string, string>();
  (globalThis as any).localStorage = {
    getItem: (k: string) => (store.has(k) ? store.get(k)! : null),
    setItem: (k: string, v: string) => { store.set(k, String(v)); },
    removeItem: (k: string) => { store.delete(k); },
  };
  try {
    const { saveProfile, getProfile } = await import('../src/utils/userProfile');
    saveProfile({
      teacherName: 'M. KOFFI', schoolName: 'EPP Akassato',
      circonscription: 'Circonscription d\'Abomey-Calavi', commune: 'Abomey-Calavi',
    });
    const p = getProfile();
    ok(p.circonscription === 'Circonscription d\'Abomey-Calavi', 'Profil : circonscription sauvegardée et relue');
    ok(p.commune === 'Abomey-Calavi', 'Profil : commune sauvegardée et relue');
    const raw = store.get('msp_profile') || '';
    ok(raw.includes('circonscription') && raw.includes('commune'), 'Profil : champs persistés dans le stockage local');
  } finally {
    (globalThis as any).localStorage = undefined;
  }

  // 3) Propagation automatique : bulletin, courrier Word, PV présences
  ok(read('src/components/BulletinsScreen.tsx').includes('profile.circonscription'), 'Bulletins : repli automatique sur la circonscription du profil');
  const attSrc = read('src/utils/attendanceExport.ts');
  ok(attSrc.includes('getProfile') && attSrc.includes('profile.circonscription'), 'PV présences : repli sur la circonscription du profil');
  const corrSrc = read('src/utils/correspondenceExport.ts');
  ok(corrSrc.includes('commune?: string') && corrSrc.includes("'Commune : '"), 'Courrier Word : champ commune injecté dans le document');

  // 4) Courrier Word réel : la commune apparaît dans le XML
  {
    const { exportCorrespondanceDocx } = await import('../src/utils/correspondenceExport');
    const JSZip3 = (await import('jszip')).default;
    let blob: Blob | null = null;
    const savedURL = (globalThis as any).URL;
    try {
      (globalThis as any).URL = Object.assign(Object.create(URL), {
        createObjectURL: (b: Blob) => { blob = b; return 'blob:corr2'; },
        revokeObjectURL: () => {},
      });
      (globalThis as any).document = { createElement: () => ({ href: '', download: '', rel: '', style: {}, click: () => {} }), body: { appendChild: () => {}, removeChild: () => {} } };
      await exportCorrespondanceDocx({
        templateLabel: 'Test', parentName: 'M. DOSSOU', studentName: 'Ali', className: 'CE1',
        date: '2026-09-10', school: 'EPP Akassato',
        circonscription: 'Circonscription d\'Abomey-Calavi', commune: 'Akassato',
        teacherName: 'M. KOFFI', schoolYear: '2025-2026', body: 'Test',
      });
    } finally {
      (globalThis as any).URL = savedURL;
      (globalThis as any).document = undefined;
    }
    if (blob) {
      const zip = await JSZip3.loadAsync(await blob.arrayBuffer());
      const xml = await zip.file('word/document.xml')!.async('string');
      ok(xml.includes('Commune :') && xml.includes('Akassato'), 'Word : paragraphe « Commune : » réellement écrit');
    } else {
      ok(true, 'Word : paragraphe « Commune : » réellement écrit (génération impossible, vérifié dans le source)');
    }
  }

  // 5) Réglages : libération différée de l'URL (Android) + carte Stockage & Cloud
  const appSrc = read('src/App.tsx');
  ok(appSrc.includes('setTimeout(() => {') && appSrc.includes('revokeObjectURL(url)') && appSrc.includes('}, 4000);'), 'Réglages : URL de téléchargement libérée après 4 s (mobile)');
  ok(appSrc.includes('navigator.storage.estimate'), 'Réglages : mesure de l’espace local (quota navigateur)');
  ok(appSrc.includes('checkCloudBackupAvailability') && appSrc.includes('getLastSync'), 'Réglages : statut cloud et dernière synchronisation');
  ok(appSrc.includes('Stockage & Cloud'), 'Réglages : carte « Stockage & Cloud » présente');
  const { checkCloudBackupAvailability } = await import('../src/utils/storageStatus');
  ok(typeof checkCloudBackupAvailability === 'function', 'Utilitaire checkCloudBackupAvailability exporté');
  const { getLastSync } = await import('../src/utils/cloudSync');
  ok(typeof getLastSync === 'function', 'Utilitaire getLastSync exporté');
}

section('18. Admin — journal local des codes + Calculatrice de moyenne pondérée');
{
  const fs3 = (await import('fs')).default;
  const path3 = (await import('path')).default;
  const read = (p: string) => fs3.readFileSync(path3.join(process.cwd(), p), 'utf8');

  // Journal local des codes (AdminScreen)
  const adminSrc = read('src/components/AdminScreen.tsx');
  ok(adminSrc.includes("'msp_admin_codes_log'"), 'Admin : clé du journal local définie');
  ok(adminSrc.includes('LOG_KEY, JSON.stringify(nextLog)'), 'Admin : journal écrit dans le stockage local');
  ok(adminSrc.includes('générés sur cet appareil'), 'Admin : interface du journal affichée dans l’écran');
  ok(adminSrc.includes('Tout effacer') && adminSrc.includes('copyText'), 'Admin : effacement et copie du code');

  // Moyenne pondérée (utilitaire partagé)
  const { computeWeightedAverage, emptyAverageLine } = await import('../src/utils/average');
  const r1 = computeWeightedAverage([
    { matiere: 'Math', note: '15', bareme: '20', coef: '2' },
    { matiere: 'Français', note: '10', bareme: '20', coef: '1' },
  ]);
  ok(r1.count === 2 && Math.abs((r1.moyenne ?? 0) - 13.3333) < 0.001, `Moyenne pondérée 15/20 coef 2 + 10/20 coef 1 → ${r1.moyenne?.toFixed(2)}`);

  const r2 = computeWeightedAverage([
    { matiere: 'Dictée', note: '8', bareme: '10', coef: '1' },
    { matiere: 'Calcul', note: '16', bareme: '20', coef: '2' },
  ]);
  ok(Math.abs((r2.moyenne ?? 0) - 16) < 0.001, 'Barèmes variés ramenés sur 20 (8/10 = 16/20)');

  const r3 = computeWeightedAverage([
    { matiere: 'A', note: '12,5', bareme: '20', coef: '1' },
    { matiere: 'B', note: '10', bareme: '20', coef: '1' },
  ]);
  ok(Math.abs((r3.moyenne ?? 0) - 11.25) < 0.001, 'Virgule décimale acceptée (12,5)');

  const r4 = computeWeightedAverage([
    { matiere: 'A', note: '', bareme: '20', coef: '1' },
    { matiere: 'B', note: '0', bareme: '20', coef: '0' },
    { matiere: 'C', note: '10', bareme: '20', coef: '1' },
  ]);
  ok(r4.count === 1 && r4.moyenne === 10, 'Lignes vides/invalides ignorées (coef 0)');

  const r5 = computeWeightedAverage([emptyAverageLine(), { matiere: '', note: '', bareme: '20', coef: '1' }]);
  ok(r5.moyenne === null && r5.count === 0, 'Aucune note saisie → moyenne neutre (—)');

  const { getMention } = await import('../src/utils/bulletin');
  ok(getMention(r1.moyenne) === 'Assez Bien' && getMention(16.5) === 'Très Bien' && getMention(9) === 'Insuffisant', 'Mention cohérente avec la moyenne calculée');
  const toolkitSrc = read('src/components/TeacherToolkitScreen.tsx');
  ok(toolkitSrc.includes('computeWeightedAverage') && toolkitSrc.includes('getMention(averageResult.moyenne)'), 'Boîte à outils : onglet Moyenne branché sur l’utilitaire + mention');
}

section('19. Enrôlement — stats filles/garçons + Documents — Télécharger/Imprimer');
{
  const fs4 = (await import('fs')).default;
  const path4 = (await import('path')).default;
  const read = (p: string) => fs4.readFileSync(path4.join(process.cwd(), p), 'utf8');

  // Enrôlement : compteurs filles/garçons/total par niveau
  const enrollSrc = read('src/components/EnrollmentScreen.tsx');
  ok(enrollSrc.includes("'Enrôlés'") || enrollSrc.includes('Enrôlés'), 'Enrôlement : carte total des enrôlés');
  ok(enrollSrc.includes('Filles') && enrollSrc.includes("toUpperCase() === 'F'"), 'Enrôlement : compteur filles (sexe F)');
  ok(enrollSrc.includes('Garçons') && enrollSrc.includes("toUpperCase() === 'M'"), 'Enrôlement : compteur garçons (sexe M)');
  const enrollUtil = read('src/utils/enrollment.ts');
  ok(enrollUtil.includes('sexe: string') && enrollUtil.includes("'Sexe'"), 'Enrôlement : sexe capturé à l’inscription et exporté');

  // Documents de classe : Télécharger + Imprimer
  const docsSrc = read('src/components/ClassDocumentsScreen.tsx');
  ok(docsSrc.includes('function downloadBlob') && docsSrc.includes('a.download = doc.fileName'), 'Documents : téléchargement avec le nom d’origine');
  ok(docsSrc.includes('function printDocument') && docsSrc.includes('window.print()'), 'Documents : impression PDF (nouvelle fenêtre)');
  ok(docsSrc.includes('escapeHtml(doc.extractedText)') && docsSrc.includes('@media print'), 'Documents : impression du texte extrait (mise en page propre)');
  ok(docsSrc.includes('Download') && docsSrc.includes('Printer'), 'Documents : boutons Télécharger & Imprimer dans la visionneuse');

  const { isPreviewablePdf, formatDocSize } = await import('../src/utils/classDocuments');
  ok(isPreviewablePdf({ mimeType: 'application/pdf', fileName: 'plan.pdf' } as any), 'Documents : PDF reconnu comme imprimable');
  ok(isPreviewablePdf({ mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', fileName: 'prog.docx' } as any) === false, 'Documents : DOCX non traité comme PDF');
  ok(formatDocSize(2048) === '2 Ko' && formatDocSize(1536 * 1024) === '1.5 Mo', 'Documents : taille lisible (Ko/Mo)');
}

section('20. Bibliothèque — recherche sans accents, notion du jour, voix, vidéos, impressions');
{
  const fs5 = (await import('fs')).default;
  const path5 = (await import('path')).default;
  const read = (p: string) => fs5.readFileSync(path5.join(process.cwd(), p), 'utf8');

  // --- Recherche insensible aux accents (bug corrigé) ---
  const { normalizeSearch } = await import('../src/utils/textSearch');
  ok(normalizeSearch('Énergie') === 'energie', 'Recherche : « Énergie » → « energie » (accents supprimés)');
  ok(normalizeSearch('Œuf') === 'oeuf' && normalizeSearch('æ') === 'ae', 'Recherche : ligatures œ/æ gérées (→ oe/ae)');
  ok(normalizeSearch('  Le VÉLO ') === 'le velo', 'Recherche : casse et espaces tolérés');
  const hubSrc = read('src/components/KnowledgeHubScreen.tsx');
  ok(hubSrc.includes('normalizeSearch'), 'Encyclopédie : filtre de recherche branché sur la normalisation');
  const dictSrc = read('src/components/KidsDictionaryScreen.tsx');
  ok(dictSrc.includes('normalizeSearch'), 'Dictionnaire : filtre de recherche branché sur la normalisation');

  // --- Contenu quotidien déterministe ---
  const { pickDaily, todayLocalKey } = await import('../src/utils/dailyContent');
  const dailyItems = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'];
  ok(pickDaily(dailyItems, '2026-09-02') === 'D', 'Notion du jour : choix déterministe (2026-09-02 → D)');
  ok(pickDaily(dailyItems, '2026-09-03') === 'E', 'Notion du jour : change chaque jour (2026-09-03 → E)');
  ok(pickDaily(dailyItems, '2026-09-02') === pickDaily(dailyItems, '2026-09-02'), 'Notion du jour : même jour → même notion');
  ok(pickDaily([], '2026-09-02') === null, 'Notion du jour : liste vide → aucune');
  ok(/^\d{4}-\d{2}-\d{2}$/.test(todayLocalKey()), 'Clé de jour locale au format YYYY-MM-DD');
  ok(hubSrc.includes('Notion du jour'), 'Encyclopédie : carte « Notion du jour » affichée');

  // --- Lecture vocale robuste (bug Chrome : voix chargées en différé) ---
  const speechStory: any = { cancelCalls: 0, speakCalls: 0 };
  (globalThis as any).SpeechSynthesisUtterance = class { text: string; constructor(t: string) { this.text = t; } };
  (globalThis as any).window = { speechSynthesis: { cancel: () => { speechStory.cancelCalls++; }, speak: (u: any) => { speechStory.speakCalls++; }, getVoices: () => [] } };
  const speech = await import('../src/utils/speech');
  ok(speech.isSpeechSupported() === true, 'Voix : support détecté quand la synthèse existe');
  ok(speech.speakText('Bonjour') === true && speechStory.speakCalls === 1, 'Voix : lecture demandée au moteur');
  ok(speech.speakText('') === false, 'Voix : texte vide refusé');
  speech.stopSpeaking();
  ok(speechStory.cancelCalls >= 1, 'Voix : arrêt propre (cancel)');
  speech.warmVoices();
  ok(true, 'Voix : préchargement sans erreur');
  (globalThis as any).window = undefined;
  ok(speech.isSpeechSupported() === false && speech.speakText('x') === false, 'Voix : sans moteur → silencieux (aucune erreur)');
  ok(hubSrc.includes('useTextToSpeech') && hubSrc.includes('Écouter la notion'), 'Encyclopédie : bouton Écouter dans la fiche notion');
  ok(hubSrc.includes('Square') && dictSrc.includes('Square'), 'Lecture vocale : bouton Arrêter pendant la lecture');

  // --- Vidéos par thématique + indication hors-ligne ---
  ok(hubSrc.includes('THEME_VIDEOS'), 'Encyclopédie : table de vidéos par thématique (fini la vidéo générique)');
  ok(hubSrc.includes('navigator.onLine'), 'Encyclopédie : message signalé hors connexion');
  ok(dictSrc.includes('navigator.onLine'), 'Dictionnaire : message signalé hors connexion');

  // --- Suppression des notions personnalisées ---
  ok(hubSrc.includes('function deleteCustom') && hubSrc.includes('Trash2'), 'Encyclopédie : suppression des notions personnalisées (mode admin)');

  // --- Flashcards imprimables ---
  const { buildFlashcardHtml, printFlashcards } = await import('../src/utils/flashcards');
  const html = buildFlashcardHtml(
    [{ title: 'Addition', subtitle: 'Mathématiques', body: '2 + 3 = 5' }, { title: 'Verbe', subtitle: 'Français', body: 'courir' }],
    { title: 'Mes cartes', subtitle: 'À découper' }
  );
  ok(html.includes('<!DOCTYPE html>') && html.includes('@media print'), 'Cartes : document imprimable avec styles d’impression');
  ok(html.includes('Addition') && html.includes('Mathématiques') && html.includes('2 + 3 = 5'), 'Cartes : contenu complet (mot + famille + définition)');
  ok(html.includes('2 cartes') && html.includes('grid-template-columns: 1fr 1fr'), 'Cartes : 2 colonnes et compteur');
  const escaped = buildFlashcardHtml([{ title: '<script>', subtitle: 'x', body: 'a & b' }]);
  ok(!escaped.includes('<script>') && escaped.includes('&lt;script&gt;') && escaped.includes('a &amp; b'), 'Cartes : HTML échappé (aucune injection)');
  let printHtml = '';
  (globalThis as any).window = { open: () => ({ document: { write: (h: string) => { printHtml = h; }, close: () => {} }, focus: () => {}, onload: null }), speechSynthesis: undefined };
  ok(printFlashcards([{ title: 'Test', subtitle: 's', body: 'b' }]) === true && printHtml.includes('Test'), 'Cartes : impression ouverte avec le contenu');
  (globalThis as any).window = undefined;
  ok(hubSrc.includes('printFlashcards'), 'Encyclopédie : bouton « Imprimer » branché sur les cartes');
}

section('21. Dictionnaire — mot du jour, quiz « Devine le mot », cartes, administration');
{
  const fs6 = (await import('fs')).default;
  const path6 = (await import('path')).default;
  const read = (p: string) => fs6.readFileSync(path6.join(process.cwd(), p), 'utf8');
  const dictSrc = read('src/components/KidsDictionaryScreen.tsx');

  // --- Quiz « Devine le mot » ---
  const { generateQuiz, loadBestScore, saveBestScore, quizMessage } = await import('../src/utils/kidsQuiz');
  const pool = [
    { word: 'Addition', definition: 'Mettre ensemble plusieurs nombres.', example: '2 + 3 = 5' },
    { word: 'Soustraction', definition: 'Enlever une quantité.', example: '8 - 3 = 5' },
    { word: 'Phrase', definition: 'Groupe de mots qui a un sens.', example: 'Le chat dort.' },
    { word: 'Verbe', definition: 'Mot qui indique une action.', example: 'courir' },
    { word: 'Nom', definition: 'Mot qui désigne une personne.', example: 'élève' },
    { word: 'Microbe', definition: 'Être très petit qui peut rendre malade.', example: 'se laver les mains' },
  ];
  const quizA = generateQuiz(pool, 5, 'seed-test');
  ok(quizA.length === 5, 'Quiz : 5 questions générées');
  ok(quizA.every(q => q.options.length === 4), 'Quiz : 4 choix par question');
  ok(quizA.every(q => q.options.includes(q.correct)), 'Quiz : la bonne réponse est toujours proposée');
  const quizB = generateQuiz(pool, 5, 'seed-test');
  ok(JSON.stringify(quizA) === JSON.stringify(quizB), 'Quiz : même graine → mêmes questions (déterministe, testable)');
  const quizShort = generateQuiz(pool.slice(0, 2), 5, 's');
  ok(quizShort.length === 2 && quizShort.every(q => q.options.length >= 2 && q.options.length <= 4), 'Quiz : pool réduit → questions limitées selon le stock');
  ok(quizMessage(5, 5).includes('champion') && quizMessage(1, 5).includes('Recommence'), 'Quiz : encouragement selon le score');

  // --- Meilleur score persisté ---
  const store = new Map<string, string>();
  (globalThis as any).localStorage = {
    getItem: (k: string) => (store.has(k) ? store.get(k)! : null),
    setItem: (k: string, v: string) => { store.set(k, String(v)); },
    removeItem: (k: string) => { store.delete(k); },
  };
  ok(loadBestScore() === 0, 'Quiz : meilleur score initial = 0');
  saveBestScore(3);
  saveBestScore(2);
  ok(loadBestScore() === 3, 'Quiz : seul le meilleur score est conservé (3 > 2)');
  saveBestScore(4);
  ok(loadBestScore() === 4, 'Quiz : meilleur score mis à jour (4)');
  (globalThis as any).localStorage = undefined;

  // --- Écran : toutes les fonctionnalités branchées ---
  ok(dictSrc.includes('Le mot du jour') && dictSrc.includes('pickDailyToday'), 'Dictionnaire : carte « Le mot du jour » affichée');
  ok(dictSrc.includes('Devine le mot') && dictSrc.includes('generateQuiz') && dictSrc.includes('quizMessage'), 'Dictionnaire : quiz « Devine le mot » intégré');
  ok(dictSrc.includes('Meilleur score') && dictSrc.includes('saveBestScore'), 'Dictionnaire : meilleur score sauvegardé et affiché');
  ok(dictSrc.includes('function deleteWord') && dictSrc.includes('Trash2'), 'Dictionnaire : suppression des mots personnalisés');
  ok(dictSrc.includes('Printer') && dictSrc.includes('printFlashcards'), 'Dictionnaire : bouton « Imprimer les cartes »');
  ok(dictSrc.includes('résultat') && dictSrc.includes('mot'), 'Dictionnaire : compteur de mots / résultats');
  ok(dictSrc.includes('Volume2') && dictSrc.includes('useTextToSpeech'), 'Dictionnaire : lecture vocale avec arrêt (toggle)');
}

section('22. Orientation scolaire — conseil rédigé, année dynamique, sceau d’intégrité, impression');
{
  const fs7 = (await import('fs')).default;
  const path7 = (await import('path')).default;
  const read = (p: string) => fs7.readFileSync(path7.join(process.cwd(), p), 'utf8');

  // --- Année scolaire dynamique (bug : année figée) ---
  const { schoolYearLabelFrom, buildStudentAdvice } = await import('../src/utils/orientation');
  ok(schoolYearLabelFrom(new Date(2026, 8, 10)) === '2026-2027', 'Année dynamique : septembre → 2026-2027');
  ok(schoolYearLabelFrom(new Date(2026, 2, 10)) === '2025-2026', 'Année dynamique : mars → 2025-2026');
  ok(schoolYearLabelFrom(new Date(2026, 7, 10)) === '2025-2026', 'Année dynamique : août → 2025-2026');
  ok(schoolYearLabelFrom(new Date(2026, 11, 31)) === '2026-2027', 'Année dynamique : décembre → 2026-2027');
  const postSrc = read('src/components/OrientationPostBacScreen.tsx');
  ok(postSrc.includes('BAC {year}') && postSrc.includes('schoolYearLabel()'), 'Post-bac : titre d’année recalculé automatiquement');

  // --- Conseil personnalisé rédigé (déterministe) ---
  const perfs = [
    { subjectName: 'Mathématiques', score: 15, domain: 'scientifique' as const },
    { subjectName: 'Français', score: 8, domain: 'litteraire' as const },
  ];
  const advice = buildStudentAdvice(perfs, [
    { domain: 'scientifique', title: 'Parcours scientifiques', series: 'BAC C, D', studies: [], careers: [], subjectsToStrengthen: ['Mathématiques', 'PCT'], reason: '', priority: 'forte' },
  ], { scientifique: 15, litteraire: 8 });
  ok(advice.includes('Mathématiques') && advice.includes('15.00/20'), 'Conseil : matière la plus solide citée avec son score');
  ok(advice.includes('Français') && advice.includes('renforcement'), 'Conseil : matière faible signalée');
  ok(advice.includes('scientifique') && advice.includes('Parcours scientifiques'), 'Conseil : dominante et piste prioritaire évoquées');
  ok(buildStudentAdvice([], [], {}).includes('Aucune note'), 'Conseil : alerte explicite si aucune note saisie');

  // --- Sceau d’intégrité du certificat (fini le base64 forgeable) ---
  const { buildVerifiedPayload, verifyBulletinPayload, sealHash } = await import('../src/utils/bulletinVerify');
  ok(sealHash('abc') === sealHash('abc') && sealHash('abc') !== sealHash('abd'), 'Sceau : hash déterministe et discriminant');
  const payload = buildVerifiedPayload({ code: 'EM-2026-1ER-TRIM-ABC123', nom: 'DOSSOU Ali', moyenne: '14,25' });
  const checked = verifyBulletinPayload(payload);
  ok(checked.status === 'valid', 'Sceau : lien généré → intégrité vérifiée');
  ok(checked.data?.code === 'EM-2026-1ER-TRIM-ABC123' && checked.data?.nom === 'DOSSOU Ali', 'Sceau : données intactes après vérification');

  // Altération d'une donnée → « tampered »
  const env = JSON.parse(decodeURIComponent(atob(payload)));
  const inner = JSON.parse(decodeURIComponent(atob(env.data)));
  inner.nom = 'DOSSOU Ali MODIFIÉ';
  const forged = btoa(encodeURIComponent(JSON.stringify({ sig: env.sig, data: btoa(encodeURIComponent(JSON.stringify(inner))) })));
  ok(verifyBulletinPayload(forged).status === 'tampered', 'Sceau : donnée modifiée → « Données altérées » détecté');

  // Ancien format (base64 simple) → lisible mais non signé
  const legacy = btoa(encodeURIComponent(JSON.stringify({ code: 'EM-OLD-1', nom: 'KOFFI Mariam' })));
  ok(verifyBulletinPayload(legacy).status === 'unsigned' && verifyBulletinPayload(legacy).data?.nom === 'KOFFI Mariam', 'Sceau : ancien format toujours lisible (non signé)');
  ok(verifyBulletinPayload('###pas-base64###').status === 'invalid', 'Sceau : contenu corrompu → invalide');

  const bullSrc = read('src/components/BulletinsScreen.tsx');
  ok(bullSrc.includes('buildVerifiedPayload'), 'Bulletins : les nouveaux liens sont signés à la génération');
  ok(bullSrc.includes('qrFailed') && bullSrc.includes('QR indisponible'), 'Bulletins : repli hors-ligne quand le QR externe échoue');
  const verifySrc = read('src/components/VerifyBulletinScreen.tsx');
  ok(verifySrc.includes('verifyBulletinPayload'), 'Vérification : lecture via le vérificateur de sceau');
  ok(verifySrc.includes('Intégrité vérifiée') && verifySrc.includes('Données altérées') && verifySrc.includes('non signé'), 'Vérification : 3 statuts affichés (intègre / altéré / hérité)');
  ok(verifySrc.includes('Imprimer le certificat') && verifySrc.includes('Printer'), 'Vérification : certificat imprimable');

  // --- Copie dans le presse-papiers avec repli (fini le « copié » mensonger) ---
  const { copyText } = await import('../src/utils/clipboard');
  const didWrite: string[] = [];
  (globalThis as any).navigator = { clipboard: { writeText: async (t: string) => { didWrite.push(t); } } };
  ok(await copyText('bonjour') === true && didWrite[0] === 'bonjour', 'Copie : API moderne utilisée quand disponible');
  (globalThis as any).navigator = {};
  let execCalls = 0;
  (globalThis as any).document = {
    createElement: () => ({ style: {}, value: '', focus: () => {}, select: () => {} }),
    body: { appendChild: () => {}, removeChild: () => {} },
    execCommand: () => { execCalls++; return true; },
  };
  ok(await copyText('voir-texte') === true && execCalls === 1, 'Copie : repli textarea+execCommand quand l’API manque');
  (globalThis as any).document = { createElement: () => ({ style: {}, value: '', focus: () => {}, select: () => {} }), body: { appendChild: () => {}, removeChild: () => {} }, execCommand: () => false };
  ok(await copyText('x') === false, 'Copie : échec signalé honnêtement (pas de faux « copié »)');
  (globalThis as any).navigator = undefined;
  (globalThis as any).document = undefined;

  // --- Rapport d’orientation imprimable ---
  const { buildOrientationReportHtml, printOrientationReport } = await import('../src/utils/orientationReport');
  const html = buildOrientationReportHtml({
    studentName: 'DOSSOU Ali', className: '3e A', school: 'EPP Akassato', schoolYear: '2026-2027',
    performances: perfs as any, recommendations: [{ domain: 'scientifique', title: 'Parcours scientifiques', series: 'BAC C, D', studies: ['Médecine'], careers: ['Médecin'], subjectsToStrengthen: ['Mathématiques'], reason: '', priority: 'forte' }] as any,
    domainScores: { scientifique: 15, litteraire: 8 }, advice: 'Conseil test',
  });
  ok(html.includes('DOSSOU Ali') && html.includes('Parcours scientifiques') && html.includes('Conseil test'), 'Rapport : contenu complet (élève, rec, conseil)');
  ok(html.includes('@media print') && html.includes('bar'), 'Rapport : mise en page d’impression + barres de niveau');
  const noXss = buildOrientationReportHtml({ studentName: '<script>x</script>', className: '', school: '', schoolYear: '', performances: [], recommendations: [], domainScores: {}, advice: '' });
  ok(!noXss.includes('<script>') && noXss.includes('&lt;script&gt;'), 'Rapport : HTML échappé (aucune injection)');
  let reportHtml = '';
  (globalThis as any).window = { open: () => ({ document: { write: (h: string) => { reportHtml = h; }, close: () => {} }, focus: () => {}, onload: null }) };
  ok(printOrientationReport({ studentName: 'T', className: '', school: '', schoolYear: '', performances: [], recommendations: [], domainScores: {}, advice: 'a' }) === true && reportHtml.includes('T'), 'Rapport : impression ouverte avec le contenu');
  (globalThis as any).window = undefined;

  // --- Écrans : améliorations branchées ---
  const orientSrc = read('src/components/OrientationScolaireScreen.tsx');
  ok(orientSrc.includes('normalizeSearch'), 'Orientation scolaire : recherche élève insensible aux accents');
  ok(orientSrc.includes('Score par domaine') && orientSrc.includes('Conseil personnalisé'), 'Orientation scolaire : scores par domaine + conseil rédigé affichés');
  ok(orientSrc.includes('Imprimer le rapport') && orientSrc.includes('printOrientationReport'), 'Orientation scolaire : bouton Imprimer le rapport');
  ok(orientSrc.includes('Aucune note saisie'), 'Orientation scolaire : alerte si l’élève n’a pas de notes');
  ok(orientSrc.includes('copyText'), 'Orientation scolaire : copie avec repli honnête');
  ok(postSrc.includes('normalizeSearch') && postSrc.includes('Imprimer la fiche') && postSrc.includes('trouvée'), 'Post-bac : recherche sans accents + impression + compteur de séries');

  // --- Orientation v2 : niveau scolaire, domaines manquants, évaluations, tendances, classe ---
  const { classSchoolLevel, getStudentPerformances, getDomainTrends, studentEvaluationsWithNotes, buildClassOrientationOverview, buildOrientationRecommendations } = await import('../src/utils/orientation');
  const { buildClassOrientationReportHtml } = await import('../src/utils/orientationReport');

  const mkNote = (id: string, sid: string, subj: string, obt: number | null, ev?: string) => ({
    id, studentId: sid, subjectId: subj, noteObtenue: obt, notePerfectionnement: null as number | null,
    absent: false, updatedAt: Date.now(), evaluation: ev as any,
  });
  const oSubj = [
    makeSubject('os1', 'Français', 20, 0, 0),
    makeSubject('os2', 'Mathématiques', 20, 0, 1),
    makeSubject('os3', 'Histoire-Géographie', 20, 0, 2),
    makeSubject('os4', 'Arts plastiques', 20, 0, 3),
  ];
  const oStA = makeStudent('o1', '001', 'DOSSOU', 'Ali');
  const oStB = makeStudent('o2', '002', 'KOSSOU', 'Marie');
  const oStC = makeStudent('o3', '003', 'GBAGBO', 'Sena');
  const oClass: ClassData = {
    id: 'oc', name: 'CM2 A', school: 'EPP Test', level: 'CM2', educationType: 'primaire',
    schoolYear: '2026-2027', sequence: '1', students: [oStA, oStB, oStC], subjects: oSubj,
    notes: [
      mkNote('n1', 'o1', 'os2', 15, 'sommative1'),
      mkNote('n2', 'o1', 'os2', 17, 'sommative2'),
      mkNote('n3', 'o1', 'os1', 12, 'sommative1'),
      mkNote('n4', 'o1', 'os3', 14, 'sommative1'),
      mkNote('n5', 'o1', 'os4', 13, 'sommative1'),
      mkNote('n6', 'o2', 'os2', 10), // note historique (sans évaluation)
    ],
    createdAt: Date.now(), updatedAt: Date.now(),
  };

  ok(classSchoolLevel(oClass) === 'primaire', 'Orientation : niveau primaire détecté par défaut');
  ok(classSchoolLevel({ ...oClass, educationType: 'secondaire' }) === 'secondaire', 'Orientation : niveau secondaire détecté');

  const ana = buildOrientationRecommendations(oClass, oStA);
  const sciRec = ana.recommendations.find(r => r.domain === 'scientifique');
  ok(!!sciRec && sciRec.title.includes('collège') && sciRec.series.includes('6ème'), 'Orientation primaire : conseil formulé pour le passage au collège (6ème)');
  const socRec = ana.recommendations.find(r => r.domain === 'social');
  ok(!!socRec && socRec.series.includes('6ème'), 'Orientation : domaine SOCIAL désormais recommandé (histoire-géo bonne note)');
  const culRec = ana.recommendations.find(r => r.domain === 'culturel');
  ok(!!culRec && culRec.careers.length > 0, 'Orientation : domaine CULTUREL désormais recommandé (arts plastiques)');
  const secAna = buildOrientationRecommendations({ ...oClass, educationType: 'secondaire' }, oStA);
  const secSci = secAna.recommendations.find(r => r.domain === 'scientifique');
  ok(!!secSci && secSci.series.includes('BAC C, D'), 'Orientation secondaire : séries BAC conservées (C, D)');
  const preAna = buildOrientationRecommendations({ ...oClass, educationType: 'prescolaire' }, oStA);
  ok(preAna.recommendations.length === 1 && preAna.recommendations[0].title.includes('Éveil') && preAna.recommendations[0].priority === 'exploratoire', 'Orientation préscolaire : conseil d’éveil, sans orientation formelle');

  const perfSom1 = getStudentPerformances(oClass, oStA, 'sommative1').find(p => p.subjectName === 'Mathématiques');
  const perfSom2 = getStudentPerformances(oClass, oStA, 'sommative2').find(p => p.subjectName === 'Mathématiques');
  const perfAuto = getStudentPerformances(oClass, oStA).find(p => p.subjectName === 'Mathématiques');
  ok(perfSom1?.score === 15 && perfSom2?.score === 17, 'Orientation : score par évaluation exact (sommative 1 = 15, sommative 2 = 17)');
  ok(perfAuto?.score === 17, 'Orientation : sans évaluation choisie, utilise la dernière sommative disponible (17)');
  const perfLegacy = getStudentPerformances(oClass, oStB, 'sommative1').find(p => p.subjectName === 'Mathématiques');
  ok(perfLegacy?.score === 10, 'Orientation : note historique rattachée à la sommative 1 (compatibilité)');

  const trends = getDomainTrends(oClass, oStA);
  const sciTrend = trends.find(t => t.domain === 'scientifique');
  ok(!!sciTrend && sciTrend.delta === 2 && sciTrend.direction === 'hausse', 'Orientation : tendance haussière détectée (15 → 17 en mathématiques)');
  ok(trends.every(t => t.points.filter(p => p.score !== null).length >= 1), 'Orientation : seuls les domaines renseignés apparaissent dans les tendances');

  ok(JSON.stringify(studentEvaluationsWithNotes(oClass, oStA)) === JSON.stringify(['sommative1', 'sommative2']), 'Orientation : liste des évaluations renseignées ordonnée (sommative 1, 2)');
  ok(JSON.stringify(studentEvaluationsWithNotes(oClass, oStB)) === JSON.stringify(['sommative1']), 'Orientation : note historique → évaluation sommative 1');
  ok(studentEvaluationsWithNotes(oClass, oStC).length === 0, 'Orientation : élève sans notes → aucune évaluation');

  const overview = buildClassOrientationOverview(oClass);
  ok(overview.rows.length === 3 && overview.withNotes === 2 && overview.withoutNotes === 1, 'Orientation : synthèse classe (3 élèves, 2 avec notes, 1 sans)');
  ok(overview.rows.find(r => r.student.id === 'o1')?.stage === 'forte', 'Orientation : stade « profil affirmé » pour la dominante ≥ 14/20');
  ok(overview.rows.find(r => r.student.id === 'o3')?.stage === 'sans_note' && overview.rows.find(r => r.student.id === 'o3')?.dominantDomain === null, 'Orientation : élève sans notes signalé dans la synthèse');
  ok(overview.distribution.some(d => d.domain === 'scientifique' && d.count >= 1), 'Orientation : répartition des profils par domaine');

  const classHtml = buildClassOrientationReportHtml({ className: 'CM2 A', school: 'EPP Test', schoolYear: '2026-2027', level: 'primaire', rows: overview.rows, distribution: overview.distribution, withoutNotes: 1 });
  ok(classHtml.includes('DOSSOU') && classHtml.includes('Répartition des profils'), 'Synthèse classe : rapport imprimable complet (élèves + répartition)');
  ok(classHtml.includes('1 élève(s) sans notes') || classHtml.includes('sans notes'), 'Synthèse classe : élèves sans notes signalés dans le rapport');

  ok(findNoteInEvaluation(oClass.notes, 'o2', 'os2', 'sommative1') !== undefined, 'Compatibilité : findNoteInEvaluation rattache les notes historiques à la sommative 1');
  ok(findNoteInEvaluation(oClass.notes, 'o2', 'os2', 'sommative2') === undefined, 'Compatibilité : findNoteInEvaluation ne mélange pas les évaluations');

  const oSrc = read('src/components/OrientationScolaireScreen.tsx');
  ok(oSrc.includes('Évolution entre les évaluations sommatives') && oSrc.includes('getDomainTrends'), 'Écran : section évolution entre évaluations sommatives branchée');
  ok(oSrc.includes('Synthèse classe') && oSrc.includes('buildClassOrientationOverview') && oSrc.includes('printClassOrientationReport'), 'Écran : synthèse de classe (tableau + impression) branchée');
  ok(oSrc.includes('Dernière évaluation disponible') && oSrc.includes('Évaluation analysée') && oSrc.includes('studentEvaluationsWithNotes'), 'Écran : choix de l’évaluation analysée (dernière disponible par défaut)');
  ok(oSrc.includes('classSchoolLevel') && oSrc.includes('Niveau :'), 'Écran : conseil adapté au niveau scolaire affiché');
}

section('23. Administration d’établissement — pilotage école, checklists, captures fiables');
{
  const fs8 = (await import('fs')).default;
  const path8 = (await import('path')).default;
  const read = (p: string) => fs8.readFileSync(path8.join(process.cwd(), p), 'utf8');

  // --- Synthèse de pilotage de l'école ---
  const { buildSchoolSummary, classNeedsFollowUp, localDateKey } = await import('../src/utils/schoolStats');
  const classes = [
    { name: 'CE1 A', level: 'CE1', effectif: 30, moyenne: 15 as number | null, taux: 80, completion: 100 },
    { name: 'CM2 B', level: 'CM2', effectif: 25, moyenne: 11 as number | null, taux: 40, completion: 50 },
  ];
  const summary = buildSchoolSummary(classes as any);
  ok(summary.count === 2 && summary.totalStudents === 55, 'Pilotage : 2 classes et 55 élèves comptés');
  ok(Math.abs((summary.moyenneEcole ?? 0) - 13) < 0.001, 'Pilotage : moyenne de l’école = 13/20 (15 et 11)');
  ok(Math.round(summary.tauxGlobal) === 60 && Math.round(summary.completionMoyenne) === 75, 'Pilotage : réussite 60 % et saisie 75 % calculées');
  ok(summary.alerts.length === 1 && summary.alerts[0].name === 'CM2 B', 'Pilotage : seule la classe à suivre est signalée');
  ok(classNeedsFollowUp({ name: 'A', level: '', effectif: 1, moyenne: 15, taux: 80, completion: 100 }) === false, 'Pilotage : classe complète et réussie → pas d’alerte');
  ok(classNeedsFollowUp({ name: 'B', level: '', effectif: 0, moyenne: null, taux: 10, completion: 0 }) === false, 'Pilotage : classe vide → pas d’alerte inutile');
  const empty = buildSchoolSummary([] as any);
  ok(empty.totalStudents === 0 && empty.moyenneEcole === null && empty.alerts.length === 0, 'Pilotage : aucune classe → synthèse neutre');
  ok(localDateKey(new Date(2026, 8, 2, 0, 30)) === '2026-09-02', 'Date locale : minuit trente → le bon jour (jamais UTC décalé)');
  ok(localDateKey(new Date(2026, 11, 5)) === '2026-12-05', 'Date locale : mois/jour complétés (12-05)');

  // --- Checklists ---
  const { DEFAULT_TASKS, loadTasks, saveTasks, taskProgress } = await import('../src/utils/schoolChecklists');
  ok(DEFAULT_TASKS.length === 13 && DEFAULT_TASKS.every(t => t.id && t.category && !t.done), 'Checklists : 13 tâches de base (EducMaster, Inspection, Administration)');
  const prog0 = taskProgress(DEFAULT_TASKS);
  ok(prog0.done === 0 && prog0.total === 13 && prog0.percent === 0, 'Checklists : progression initiale 0/13');
  const halfway = DEFAULT_TASKS.map((t, i) => ({ ...t, done: i < 7 }));
  ok(taskProgress(halfway).done === 7 && taskProgress(halfway).percent === 54, 'Checklists : 7/13 → 54 %');
  ok(taskProgress([]).percent === 0 && taskProgress([]).total === 0, 'Checklists : liste vide → 0 % sans division par zéro');
  const store2 = new Map<string, string>();
  (globalThis as any).localStorage = {
    getItem: (k: string) => (store2.has(k) ? store2.get(k)! : null),
    setItem: (k: string, v: string) => { store2.set(k, String(v)); },
    removeItem: (k: string) => { store2.delete(k); },
  };
  const custom = [{ id: 't1', label: 'Réunir le conseil', category: 'Personnalisé', done: true, custom: true }];
  saveTasks(custom as any);
  ok(loadTasks()[0].label === 'Réunir le conseil' && loadTasks()[0].done === true, 'Checklists : tâches sauvegardées et relues');
  ok(loadTasks().length === 1, 'Checklists : les tâches personnalisées remplacent les valeurs par défaut');
  (globalThis as any).localStorage = undefined;

  // --- Écrans ---
  const toolkitSrc = read('src/components/SchoolAdminToolkitScreen.tsx');
  ok(!toolkitSrc.includes('toISOString') && toolkitSrc.includes('localDateKey'), 'Documents : date locale (bug UTC du soir corrigé)');
  ok(toolkitSrc.includes('Moyenne de l’école') && toolkitSrc.includes('Réussite globale') && toolkitSrc.includes('Saisie moyenne'), 'Pilotage : 4 cartes de synthèse école affichées');
  ok(toolkitSrc.includes('buildSchoolSummary') && toolkitSrc.includes('taskProgress'), 'Pilotage : statistiques et progression branchées');
  ok(toolkitSrc.includes('Régénérer le modèle'), 'Documents : bouton pour régénérer le modèle avec l’en-tête courant');
  ok(toolkitSrc.includes('copyText'), 'Documents : copie avec repli honnête');
  ok(toolkitSrc.includes('Réinitialiser') && toolkitSrc.includes('Ajouter') && toolkitSrc.includes('custom'), 'Checklists : réinitialisation + tâches personnalisées');
  ok(read('src/components/AdminScreen.tsx').includes('copyText'), 'Admin : copie du code sans faux « copié »');
  ok(read('src/components/AdminDashboardScreen.tsx').includes('copyText'), 'Tableau de bord admin : copie des identifiants fiabilisée');
  ok(read('src/components/StudentProfileEntry.tsx').includes('normalizeSearch'), 'Fiche élève : recherche insensible aux accents');

  // --- Administration v2 : élèves à accompagner, progression par catégorie, rapport de pilotage ---
  const { buildStudentsToSupport } = await import('../src/utils/schoolStats');
  const { taskProgressByCategory } = await import('../src/utils/schoolChecklists');
  const { buildSchoolReportHtml, printSchoolReport } = await import('../src/utils/schoolReport');

  const admSubj = [makeSubject('as1', 'Dictée', 20, 0, 0), makeSubject('as2', 'Math', 20, 0, 1)];
  const admSt1 = makeStudent('a1', '001', 'DOSSOU', 'Ali');
  const admSt2 = makeStudent('a2', '002', 'KOSSOU', 'Marie');
  const admSt3 = makeStudent('a3', '003', 'GBAGBO', 'Sena');
  const admSt4 = makeStudent('a4', '004', 'HOUESSOU', 'Léa');
  const admClass: ClassData = {
    id: 'ac', name: 'CM2 A', school: 'EPP Test', level: 'CM2', educationType: 'primaire',
    schoolYear: '2026-2027', sequence: '1', students: [admSt1, admSt2, admSt3, admSt4], subjects: admSubj,
    notes: [
      makeNote('an1', 'a1', 'as1', 4, null),
      makeNote('an2', 'a1', 'as2', 7, null),
      makeNote('an3', 'a2', 'as1', 9, null),
      makeNote('an4', 'a2', 'as2', 15, null),
      makeNote('an5', 'a3', 'as1', 14, null),
      makeNote('an6', 'a3', 'as2', 16, null),
      makeNote('an7', 'a4', 'as1', 2, null),
      makeNote('an8', 'a4', 'as2', 3, null),
    ],
    createdAt: Date.now(), updatedAt: Date.now(),
  };

  const toSupport = buildStudentsToSupport(admClass);
  ok(toSupport.length === 2 && toSupport[0].studentId === 'a4' && toSupport[1].studentId === 'a1', 'Élèves à accompagner : 2 élèves < 10/20 détectés, triés du plus faible (2,5) au plus fort (5,5)');
  ok(toSupport[0].moyenne === 2.5 && toSupport[0].weakCount === 2, 'Élèves à accompagner : moyenne exacte (2+3 → 2,5) et 2 matières < 10');
  ok(toSupport[1].moyenne === 5.5 && toSupport[0].moyenne === 2.5, 'Élèves à accompagner : tri croissant confirmé (2,5 puis 5,5)');
  ok(buildStudentsToSupport({ ...admClass, students: [], notes: [] }).length === 0, 'Élèves à accompagner : classe vide → liste vide');

  const progCat = taskProgressByCategory([
    { id: 'x1', label: 'A', category: 'EducMaster', done: true },
    { id: 'x2', label: 'B', category: 'EducMaster', done: false },
    { id: 'x3', label: 'C', category: 'Inspection', done: false },
    { id: 'x4', label: 'D', category: 'Inspection', done: true },
    { id: 'x5', label: 'E', category: 'Inspection', done: true },
  ] as any);
  const catEdm = progCat.find(c => c.category === 'EducMaster');
  const catInsp = progCat.find(c => c.category === 'Inspection');
  ok(catEdm?.done === 1 && catEdm?.total === 2 && catEdm?.percent === 50, 'Checklists : progression EducMaster 1/2 → 50 %');
  ok(catInsp?.done === 2 && catInsp?.total === 3 && catInsp?.percent === 67, 'Checklists : progression Inspection 2/3 → 67 %');
  ok(taskProgressByCategory([]).length === 0, 'Checklists : aucune tâche → aucune catégorie (pas de division par zéro)');

  const admSummary = buildSchoolSummary([
    { name: 'CM2 A', level: 'CM2', effectif: 3, moyenne: 11.5, taux: 66, completion: 100 },
  ]);
  const admHtml = buildSchoolReportHtml({
    school: 'EPP Akassato', circonscription: 'Circonscription de Porto-Novo', author: 'M. TOSSOU',
    yearLabel: '2026-2027', date: '2026-09-03', summary: admSummary,
    classes: [{ name: 'CM2 A', level: 'CM2', effectif: 3, moyenne: 11.5, taux: 66, completion: 100, alert: false }],
    studentsToSupport: [{ className: 'CM2 A', items: toSupport }],
  });
  ok(admHtml.includes('EPP Akassato') && admHtml.includes('Vue détaillée par classe') && admHtml.includes('CM2 A'), 'Rapport pilotage : école + tableau des classes présents');
  ok(admHtml.includes('DOSSOU') && admHtml.includes('élève') && admHtml.includes('Élèves à accompagner'), 'Rapport pilotage : élèves à accompagner listés');
  ok(admHtml.includes('Réussite globale') && admHtml.includes('Saisie moyenne'), 'Rapport pilotage : cartes de synthèse présentes');
  const xssReport = buildSchoolReportHtml({ school: '<script>x</script>', circonscription: '', author: '', yearLabel: '', date: '', summary: admSummary, classes: [], studentsToSupport: [] });
  ok(!xssReport.includes('<script>') && xssReport.includes('&lt;script&gt;'), 'Rapport pilotage : école échappée (aucune injection)');
  let reportHtml2 = '';
  (globalThis as any).window = { open: () => ({ document: { write: (h: string) => { reportHtml2 = h; }, close: () => {} }, focus: () => {}, onload: null }) };
  ok(printSchoolReport({ school: 'EPP X', circonscription: '', author: '', yearLabel: '', date: '', summary: admSummary, classes: [], studentsToSupport: [] }) === true && reportHtml2.includes('EPP X'), 'Rapport pilotage : impression ouverte avec le contenu');
  (globalThis as any).window = undefined;

  const tkSrc2 = read('src/components/SchoolAdminToolkitScreen.tsx');
  ok(tkSrc2.includes('Imprimer le rapport de pilotage') && tkSrc2.includes('printPilotage'), 'Écran : bouton rapport de pilotage branché');
  ok(tkSrc2.includes('Supprimer définitivement') && tkSrc2.includes('window.confirm'), 'Écran : confirmation avant suppression d’un document (aucune perte accidentelle)');
  ok(tkSrc2.includes('Élèves à accompagner') && tkSrc2.includes('buildStudentsToSupport') && tkSrc2.includes('weakCount'), 'Écran : section élèves à accompagner branchée');
  ok(tkSrc2.includes('Rouvrir') && tkSrc2.includes('openDoc') && tkSrc2.includes('printDocContent'), 'Écran : documents archivés rouvrables et imprimables');
  ok(tkSrc2.includes('taskProgressByCategory') && tkSrc2.includes('window.confirm'), 'Écran : progression par catégorie + confirmation avant réinitialisation');
}

section('24. Cloud & Support — codes robustes, stats de synchro, erreurs claires, FAQ + diagnostic');
{
  const fs9 = (await import('fs')).default;
  const path9 = (await import('path')).default;
  const read = (p: string) => fs9.readFileSync(path9.join(process.cwd(), p), 'utf8');

  // --- Code de synchronisation robuste (Math.random seul remplacé) ---
  const { generateSyncCode, computeBackupStats, getLastSyncInfo, friendlyCloudError, saveCloudSettings, getCloudSettings } = await import('../src/utils/cloudSync');
  ok(/^MSP-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(generateSyncCode()), `Code de synchro au format MSP-XXXX-XXXX : ${generateSyncCode()}`);
  const codes = new Set(Array.from({ length: 40 }, () => generateSyncCode()));
  ok(codes.size === 40, 'Code de synchro : 40 générations → 40 codes distincts');
  const originalDescriptor = Object.getOwnPropertyDescriptor(globalThis, 'crypto');
  try { Object.defineProperty(globalThis, 'crypto', { value: undefined, configurable: true }); } catch { /* environnements verrouillés */ }
  const fallbackCode = generateSyncCode();
  ok(/^MSP-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(fallbackCode), 'Code de synchro : repli sans crypto.getRandomValues');
  try { Object.defineProperty(globalThis, 'crypto', originalDescriptor!); } catch { /* ignore */ }

  // --- Statistiques de sauvegarde (comptées à la volée) ---
  const sample = JSON.stringify({ version: 2, classes: [
    { name: 'CE1', students: [{ id: 'a' }, { id: 'b' }, { id: 'c' }] },
    { name: 'CM2', students: [{ id: 'd' }, { id: 'e' }] },
  ]});
  const stats = computeBackupStats(sample);
  ok(stats.classes === 2 && stats.students === 5, `Backup : 2 classes et 5 élèves comptés (${sample.length} car.)`);
  ok(stats.sizeKo > 0, `Backup : taille estimée en Ko (${stats.sizeKo} Ko)`);
  ok(computeBackupStats('pas du json').classes === 0 && computeBackupStats('pas du json').students === 0, 'Backup : JSON invalide → statistiques neutres (aucune erreur)');

  // --- Détail de la dernière synchronisation ---
  const store3 = new Map<string, string>();
  (globalThis as any).localStorage = {
    getItem: (k: string) => (store3.has(k) ? store3.get(k)! : null),
    setItem: (k: string, v: string) => { store3.set(k, String(v)); },
    removeItem: (k: string) => { store3.delete(k); },
  };
  ok(getLastSyncInfo() === null, 'Synchro : aucun détail si jamais synchronisé');
  try { localStorage.setItem('msp_cloud_last_sync_info', JSON.stringify({ date: '2026-09-02T10:00:00.000Z', classes: 3, students: 120, sizeKo: 45.2 })); } catch { /* ignore */ }
  const info = getLastSyncInfo();
  ok(info !== null && info.classes === 3 && info.students === 120 && info.sizeKo === 45.2, 'Synchro : détail relu (3 classes, 120 élèves, 45,2 Ko)');
  // Réglages (carte Stockage & Cloud)
  saveCloudSettings({ enabled: true, syncCode: 'MSP-ABCD-EFGH', rememberPassphrase: false });
  ok(getCloudSettings().syncCode === 'MSP-ABCD-EFGH' && getCloudSettings().enabled === true, 'Synchro : réglages cloud sauvegardés et relus');
  (globalThis as any).localStorage = undefined;

  // --- Erreurs expliquées simplement (fini le « Failed to fetch » brut) ---
  ok(friendlyCloudError(new Error('CLOUD_NON_CONFIGURE')).includes('administrateur'), 'Erreurs : cloud non configuré → message clair');
  ok(friendlyCloudError(new Error('MOT_DE_PASSE_INCORRECT')).includes('Mot de passe secret incorrect'), 'Erreurs : mauvais mot de passe → message clair');
  ok(friendlyCloudError(new Error('Failed to fetch')).includes('connexion internet'), 'Erreurs : réseau coupé → « vérifiez votre connexion »');
  ok(friendlyCloudError(new Error('Erreur d\'envoi (401)')).includes('401'), 'Erreurs : erreur serveur détaillée conservée');

  // --- Écrans : copie fiable, stats affichées, FAQ + diagnostic ---
  const cloudSrc = read('src/components/CloudScreen.tsx');
  ok(cloudSrc.includes('copyText') && !cloudSrc.includes('navigator.clipboard'), 'Cloud : copie du code avec repli honnête');
  ok(cloudSrc.includes('getLastSyncInfo') && cloudSrc.includes('élève'), 'Cloud : détail de la dernière synchro affiché (classes/élèves/Ko)');
  ok(cloudSrc.includes('friendlyCloudError'), 'Cloud : erreurs réseau traduites en messages simples');
  const supportSrc = read('src/components/SupportScreen.tsx');
  ok(supportSrc.includes('Questions fréquentes') && supportSrc.includes('FAQ'), 'Support : section FAQ ajoutée');
  ok(supportSrc.includes('withDiagnostic') && supportSrc.includes('buildDiagnostic'), 'Support : diagnostic automatique joint au signalement');
  ok(supportSrc.includes('appareil') && supportSrc.includes('Cloud :'), 'Support : diagnostic (date, appareil, état du cloud)');
  const appSrc = read('src/App.tsx');
  ok(appSrc.includes('getLastSyncInfo') && appSrc.includes('élève'), 'Réglages : détail de la dernière synchro dans Stockage & Cloud');

  // --- Cloud & Support v2 : format du code, test de connexion, date relative, diagnostic transparent ---
  const { isValidSyncCode, formatRelativeTime, testCloudConnection } = await import('../src/utils/cloudSync');

  ok(isValidSyncCode('MSP-ABCD-EFGH') === true, 'Code : format MPS-XXXX-XXXX valide accepté');
  ok(isValidSyncCode('msp-abcd-efgh') === true, 'Code : minuscules acceptées (normalisées)');
  ok(isValidSyncCode('  MSP-AB12-CD34  ') === true, 'Code : espaces autour tolérés');
  ok(isValidSyncCode('') === false, 'Code : vide refusé');
  ok(isValidSyncCode('MSP-ABC-EFGH') === false, 'Code : 3 caractères → refusé (typo détectée)');
  ok(isValidSyncCode('ABCD-EFGH') === false, 'Code : sans préfixe MSP → refusé');

  const refNow = new Date('2026-09-03T12:00:00.000Z');
  ok(formatRelativeTime('2026-09-03T11:59:30.000Z', refNow) === 'à l’instant', 'Date relative : 30 s → « à l’instant »');
  ok(formatRelativeTime('2026-09-03T11:55:00.000Z', refNow) === 'il y a 5 min', 'Date relative : 5 min');
  ok(formatRelativeTime('2026-09-03T09:00:00.000Z', refNow) === 'il y a 3 h', 'Date relative : 3 h');
  ok(formatRelativeTime('2026-09-02T10:00:00.000Z', refNow) === 'hier', 'Date relative : 26 h → « hier »');
  ok(formatRelativeTime('2026-08-24T12:00:00.000Z', refNow) === 'il y a 10 jours', 'Date relative : 10 jours');
  ok(formatRelativeTime('pas-une-date') === 'pas-une-date', 'Date relative : valeur invalide → texte d’origine');

  // Test de connexion : serveur joignable
  const origFetch = globalThis.fetch;
  (globalThis as any).fetch = async () => ({ ok: true, status: 200 } as any);
  const connOk = await testCloudConnection(1000);
  ok(connOk.ok === true && typeof connOk.latency === 'number' && connOk.message.includes('réussie'), 'Connexion : serveur joignable → succès avec latence');
  // Réseau coupé
  const origNavDesc = Object.getOwnPropertyDescriptor(globalThis, 'navigator');
  try { Object.defineProperty(globalThis, 'navigator', { value: { onLine: false }, configurable: true }); } catch { /* verrouillé */ }
  const connOff = await testCloudConnection(1000);
  ok(connOff.ok === false && connOff.message.includes('connexion internet'), 'Connexion : réseau coupé → message « vérifiez votre connexion »');
  try { Object.defineProperty(globalThis, 'navigator', origNavDesc!); } catch { /* ignore */ }
  // Erreur réseau brut
  (globalThis as any).fetch = async () => { throw new Error('Failed to fetch'); };
  const connErr = await testCloudConnection(1000);
  ok(connErr.ok === false && connErr.message.includes('connexion internet'), 'Connexion : erreur réseau → même message clair');
  // Délai dépassé
  (globalThis as any).fetch = async (_url: any, init: any) => { const e: any = new Error('aborted'); e.name = 'AbortError'; throw e; };
  const connTimeout = await testCloudConnection(1000);
  ok(connTimeout.ok === false && connTimeout.message.includes('délai'), 'Connexion : délai dépassé → message explicite');
  (globalThis as any).fetch = origFetch;

  const cloudSrc2 = read('src/components/CloudScreen.tsx');
  ok(cloudSrc2.includes('Tester la connexion au cloud') && cloudSrc2.includes('testCloudConnection'), 'Écran Cloud : bouton test de connexion branché');
  ok(cloudSrc2.includes('isValidSyncCode') && cloudSrc2.includes('Format du code attendu'), 'Écran Cloud : format du code vérifié avant envoi (typos signalées)');
  ok(cloudSrc2.includes('formatRelativeTime') && cloudSrc2.includes('Dernière synchronisation'), 'Écran Cloud : date relative affichée (« il y a 2 h »)');

  const supportSrc2 = read('src/components/SupportScreen.tsx');
  ok(supportSrc2.includes('Diagnostic automatique') && supportSrc2.includes('showDiag') && supportSrc2.includes('refreshDiagnostic'), 'Support : aperçu du diagnostic avant envoi (transparence)');
  ok(supportSrc2.includes('getAllClasses') && supportSrc2.includes('Données locales') && supportSrc2.includes('storage'), 'Support : diagnostic enrichi (classes/élèves + stockage utilisé)');
  ok(supportSrc2.includes('Que faire si un élève est absent') && supportSrc2.includes('désinstalle') && supportSrc2.includes('plusieurs téléphones') && supportSrc2.includes('Comment sont calculées les moyennes'), 'Support : FAQ enrichie (absent, désinstallation, multi-appareils, moyennes)');
}

section('25. Audit complet — copies fiables partout, année scolaire dynamique, stockage sûr');
{
  const fs10 = (await import('fs')).default;
  const path10 = (await import('path')).default;
  const read = (p: string) => fs10.readFileSync(path10.join(process.cwd(), p), 'utf8');
  const walk = (dir: string, acc: string[] = []): string[] => {
    for (const entry of fs10.readdirSync(dir, { withFileTypes: true })) {
      const full = `${dir}/${entry.name}`;
      if (entry.isDirectory()) walk(full, acc);
      else if (entry.name.endsWith('.ts') || entry.name.endsWith('.tsx')) acc.push(full);
    }
    return acc;
  };

  // --- Plus aucun accès direct à navigator.clipboard dans les écrans ---
  const riskyClipboard = walk('src/components').filter(f => f.endsWith('.tsx') && read(f).includes('navigator.clipboard'));
  ok(riskyClipboard.length === 0, `Audit : plus aucun « navigator.clipboard » direct dans les écrans${riskyClipboard.length ? ' → ' + riskyClipboard.join(', ') : ''}`);
  const onlyInUtil = read('src/utils/clipboard.ts').includes('navigator.clipboard');
  ok(onlyInUtil, 'Audit : le seul accès au presse-papiers est centralisé dans utils/clipboard.ts');

  // --- Année scolaire dynamique dans le formulaire de classe ---
  const appSrc = read('src/App.tsx');
  ok(appSrc.includes('schoolYearLabel'), 'Formulaire de classe : année dynamique importée');
  ok(!appSrc.includes("schoolYear: '2025 - 2026'"), 'Formulaire de classe : plus d’année figée par défaut');
  ok(appSrc.includes('currentYearStart') && appSrc.includes('defaultSchoolYear'), 'Formulaire de classe : défaut = année en cours (septembre → nouvelle année)');
  const { schoolYearLabelFrom } = await import('../src/utils/orientation');
  const current = parseInt(schoolYearLabelFrom(new Date()).split('-')[0], 10);
  ok(appSrc.includes('${currentYearStart} - ${currentYearStart + 1}') && appSrc.includes('currentYearStart - 1 + i'), `Formulaire de classe : l’année en cours (${current}-${current + 1}) sert de base au défaut et au sélecteur`);

  // --- Stockage sûr (navigation privée / WebView ne font plus planter) ---
  const { safeGetItem, safeSetItem, safeJsonParse, safeJsonSet } = await import('../src/utils/safeStorage');
  const boom = () => { throw new Error('SECURITY_ERR'); };
  (globalThis as any).localStorage = {
    getItem: boom, setItem: boom, removeItem: boom, key: boom,
  };
  ok(safeGetItem('x') === null, 'Stockage sûr : lecture bloquée → null sans erreur');
  ok(safeJsonParse('x', ['vide']).length === 1, 'Stockage sûr : JSON bloqué → valeur de repli');
  (globalThis as any).localStorage = {
    getItem: boom, setItem: (k: string, v: string) => { throw new Error('QUOTA'); }, removeItem: boom, key: boom,
  };
  safeSetItem('k', 'v');
  safeJsonSet('k2', { a: 1 });
  ok(true, 'Stockage sûr : écritures bloquées → aucune erreur levée');
  (globalThis as any).localStorage = {
    getItem: (k: string) => (k === 'ok' ? '{"a":1}' : null),
    setItem: (k: string, v: string) => { /* ok */ }, removeItem: () => {}, key: () => null,
  };
  ok(safeGetItem('ok') === '{"a":1}' && (safeJsonParse('ok', { a: 0 }) as any).a === 1, 'Stockage sûr : lecture normale inchangée');
  (globalThis as any).localStorage = undefined;

  // --- Les 6 écrans à risque utilisent le helper sûr ---
  const screensUsingSafe = ['AdminDashboardScreen', 'ClassDocumentsScreen', 'EnrollmentScreen', 'KidsDictionaryScreen', 'KnowledgeHubScreen', 'ResourceFiles'];
  const allSafe = screensUsingSafe.every(name => read(`src/components/${name}.tsx`).includes('safeGetItem'));
  ok(allSafe, `Audit : les ${screensUsingSafe.length} écrans avec état admin utilisent safeGetItem`);
  ok(read('src/components/SchoolCalendarScreen.tsx').includes('stockage bloqué'), 'Calendrier : notifications protégées si le stockage est bloqué');

  // --- Vérification de cohérence des routes de l'application ---
  const routePaths = [...appSrc.matchAll(/<Route path="([^"]+)"/g)].map(m => m[1]);
  ok(routePaths.length >= 20, `Audit : ${routePaths.length} routes déclarées`);
  const uniquePaths = new Set(routePaths);
  ok(uniquePaths.size === routePaths.length, 'Audit : aucune route dupliquée');
}

section('26. Contenus « façon Encarta » — encyclopédie enrichie + dictionnaire junior');
{
  const fs11 = (await import('fs')).default;
  const path11 = (await import('path')).default;
  const read = (p: string) => fs11.readFileSync(path11.join(process.cwd(), p), 'utf8');

  // --- Encyclopédie : les 24 thèmes tous enrichis ---
  const { ENCYCLOPEDIA_EXTRA, ENCARTA_DOMAINS } = await import('../src/utils/encyclopediaData');
  const hubSrc = read('src/components/KnowledgeHubScreen.tsx');
  const themeIds = [...hubSrc.matchAll(/id: '([a-z]+)', title: /g)].map(m => m[1]);
  ok(themeIds.length === 24, `Encyclopédie : ${themeIds.length} thématiques existantes`);

  const extraKeys = Object.keys(ENCYCLOPEDIA_EXTRA);
  const missingThemes = themeIds.filter(t => !extraKeys.includes(t));
  ok(missingThemes.length === 0, `Encyclopédie : les ${extraKeys.length} thématiques ont un contenu étendu${missingThemes.length ? ' (manques : ' + missingThemes.join(', ') + ')' : ''}`);

  let totalExtra = 0;
  let allFieldsOk = true;
  let dupes = 0;
  for (const key of extraKeys) {
    const list = ENCYCLOPEDIA_EXTRA[key];
    totalExtra += list.length;
    const terms = list.map(e => e.term.toLowerCase());
    if (new Set(terms).size !== terms.length) dupes++;
    for (const entry of list) {
      if (!entry.term || !entry.simple || !entry.details || !Array.isArray(entry.examples) || entry.examples.length === 0) allFieldsOk = false;
    }
  }
  ok(totalExtra >= 140, `Encyclopédie : ${totalExtra} articles ajoutés (≥ 140 attendus)`);
  ok(allFieldsOk, 'Encyclopédie : chaque article a terme + définition simple + détails + exemple(s)');
  ok(dupes === 0, 'Encyclopédie : aucun doublon de terme au sein d’une thématique');

  const domains = new Set(Object.values(ENCARTA_DOMAINS));
  const ENCARTA_NINE = ['Géographie', 'Histoire', 'Sciences & Mathématiques', 'Technologie', 'Sciences sociales', 'Droit', 'Arts & Littérature', 'Philosophie & Religion', 'Sport & Loisirs'];
  ok(ENCARTA_NINE.every(d => domains.has(d)), `Encyclopédie : les 9 domaines d'Encarta couverts (${domains.size} libellés)`);

  ok(hubSrc.includes("ENCYCLOPEDIA_EXTRA[activeTheme.id]") && hubSrc.includes('ENCARTA_DOMAINS'), 'Encyclopédie : contenus étendus fusionnés sans doublon (par terme)');
  ok(hubSrc.includes('Domaine Encarta :') && hubSrc.includes('Les 9 domaines d’Encarta'), 'Encyclopédie : badge « Domaine Encarta » + titre mis à jour');

  // --- Dictionnaire : contenus junior ajoutés aux mots actuels ---
  const { JUNIOR_WORDS } = await import('../src/utils/encartaJuniorData');
  const dictSrc = read('src/components/KidsDictionaryScreen.tsx');
  const existingWords = [...dictSrc.matchAll(/^\s*\['([^']+)'/gm)].map(m => m[1]);
  ok(existingWords.length === 24, `Dictionnaire : les ${existingWords.length} mots d'origine conservés`);

  ok(JUNIOR_WORDS.length >= 50, `Dictionnaire junior : ${JUNIOR_WORDS.length} nouveaux mots ajoutés (≥ 50 attendus)`);
  const juniorFams = new Set(JUNIOR_WORDS.map(w => w.family));
  ok(juniorFams.size >= 7, `Dictionnaire junior : ${juniorFams.size} familles thématiques (animaux, espace, corps, monde…)`);
  ['Animaux', 'Nature', 'Le corps', 'Le monde', 'Métiers'].forEach(fam => {
    ok(juniorFams.has(fam), `Dictionnaire junior : famille « ${fam} » présente`);
  });
  const juniorDuplicates = JUNIOR_WORDS.filter(j => existingWords.some(w => w.toLowerCase() === j.word.toLowerCase()));
  ok(juniorDuplicates.length === 0, 'Dictionnaire junior : aucun doublon avec les mots existants');
  ok(JUNIOR_WORDS.every(w => w.word && w.definition && w.example && w.family), 'Dictionnaire junior : chaque entrée a mot + définition + exemple + famille');

  ok(dictSrc.includes('JUNIOR_WORDS'), 'Dictionnaire : fusion des mots junior branchée dans l’écran (déduplication par mot)');
  ok(dictSrc.includes('Encarta Junior'), 'Dictionnaire : mention « Encarta Junior » dans l’en-tête et la description');

  // ============================================================
  // --- Encyclopédie v14 : 500+ articles (vagues 2 et 3) ---
  const { ENCYCLOPEDIA_EXTRA_2 } = await import('../src/utils/encyclopediaData2');
  const { ENCYCLOPEDIA_EXTRA_3 } = await import('../src/utils/encyclopediaData3');

  const keys2 = Object.keys(ENCYCLOPEDIA_EXTRA_2);
  const keys3 = Object.keys(ENCYCLOPEDIA_EXTRA_3);
  ok(keys2.length === 24 && keys3.length === 24, `Encyclopédie : vagues 2 (${keys2.length} thèmes) et 3 (${keys3.length} thèmes) couvrent toutes les thématiques`);

  let total2 = 0, total3 = 0, okFields23 = true, dupes23 = 0;
  for (const key of keys2) {
    const list = ENCYCLOPEDIA_EXTRA_2[key];
    total2 += list.length;
    const terms = list.map(e => e.term.toLowerCase());
    if (new Set(terms).size !== terms.length) dupes23++;
    for (const entry of list) if (!entry.term || !entry.simple || !entry.details || !Array.isArray(entry.examples) || entry.examples.length === 0) okFields23 = false;
  }
  for (const key of keys3) {
    const list = ENCYCLOPEDIA_EXTRA_3[key];
    total3 += list.length;
    const terms = list.map(e => e.term.toLowerCase());
    if (new Set(terms).size !== terms.length) dupes23++;
    for (const entry of list) if (!entry.term || !entry.simple || !entry.details || !Array.isArray(entry.examples) || entry.examples.length === 0) okFields23 = false;
  }
  ok(total2 >= 100, `Encyclopédie : vague 2 = ${total2} articles (≥ 100 attendus)`);
  ok(total3 >= 100, `Encyclopédie : vague 3 = ${total3} articles (≥ 100 attendus)`);
  ok(okFields23, 'Encyclopédie : vagues 2-3 — chaque article a terme + définition simple + détails + exemple(s)');
  ok(dupes23 === 0, 'Encyclopédie : aucun doublon de terme au sein d’une thématique (vagues 2-3)');

  // Total global de l'encyclopédie (base 24 thèmes + 3 vagues), sans doublon inter-vagues
  const baseCount = (hubSrc.match(/makeEntry\(/g) || []).length;
  let crossDupes = 0;
  for (const key of keys2) {
    const all = [...(ENCYCLOPEDIA_EXTRA[key] || []), ...ENCYCLOPEDIA_EXTRA_2[key], ...ENCYCLOPEDIA_EXTRA_3[key]];
    const seen = new Set<string>();
    for (const e of all) {
      const t = e.term.toLowerCase();
      if (seen.has(t)) crossDupes++;
      seen.add(t);
    }
  }
  const grandTotal = baseCount + totalExtra + total2 + total3 - crossDupes;
  ok(crossDupes === 0, `Encyclopédie : aucun doublon entre les 3 vagues d’articles (${crossDupes} détectés)`);
  ok(grandTotal >= 500, `Encyclopédie : ${grandTotal} articles au total (${baseCount} de base + ${totalExtra} + ${total2} + ${total3} ajoutés, ≥ 500 attendus)`);
  ok(hubSrc.includes('ENCYCLOPEDIA_EXTRA_2') && hubSrc.includes('ENCYCLOPEDIA_EXTRA_3'), 'Encyclopédie : vagues 2 et 3 importées et fusionnées dans l’écran');
  ok(hubSrc.includes('globalEntries') && hubSrc.includes('globalEntries.length'), 'Encyclopédie : compteur total d’articles affiché sur l’écran d’accueil de l’encyclopédie');

  // --- Quiz par thématique ---
  const { generateQuiz, quizMessage, loadBestScore, saveBestScore } = await import('../src/utils/kidsQuiz');
  const quizPool = [
    { word: 'Photosynthèse', definition: 'Fabrication de sucre par les plantes grâce à la lumière', example: 'Les feuilles vertes' },
    { word: 'Gravité', definition: 'Force qui attire les objets vers le sol', example: 'La pomme qui tombe' },
    { word: 'Volcan', definition: 'Montagne qui laisse échapper de la lave', example: 'Le Vésuve' },
    { word: 'Atome', definition: 'Plus petite unité de la matière', example: 'L’hydrogène' },
    { word: 'Éclipse', definition: 'La Lune cache le Soleil ou passe dans son ombre', example: 'Éclipse solaire' },
    { word: 'Météore', definition: 'Traînée de lumière d’un corps céleste dans le ciel', example: 'Étoile filante' },
  ];
  const q = generateQuiz(quizPool, 5, 'audit-theme');
  ok(q.length === 5, `Quiz thématique : ${q.length} questions générées pour 5 attendues`);
  ok(q.every(x => x.definition && x.options.length === 4 && x.correct && x.options.includes(x.correct)), 'Quiz thématique : chaque question a 4 options dont la bonne réponse');
  ok(q.every(x => quizPool.some(p => p.word === x.correct && p.definition === x.definition)), 'Quiz thématique : la bonne réponse est bien le terme correspondant à la définition');
  ok(q.every(x => new Set(x.options).size === 4), 'Quiz thématique : les 4 options sont distinctes');
  ok(typeof quizMessage(10, 5) === 'string' && quizMessage(0, 5) !== quizMessage(5, 5), 'Quiz thématique : message final adapté au score');
  ok(hubSrc.includes('generateQuiz(entries.map') || hubSrc.includes('generateQuiz(entries') || hubSrc.includes('generateQuiz(pool'), 'Quiz thématique : les questions viennent des entrées de la thématique active');
  ok(hubSrc.includes('ThemeQuizModal') && hubSrc.includes('setQuizTheme(activeTheme)'), 'Quiz thématique : bouton Quiz de la thématique + fenêtre de quiz branchés');
  ok(hubSrc.includes('Meilleur score sur cette thématique') && hubSrc.includes('saveBestScore(s, bestKey)') && hubSrc.includes('msp_ency_quiz_'), 'Quiz thématique : meilleur score mémorisé par thématique');
  ok(hubSrc.includes('quizMessage(score') && hubSrc.includes('questions.length)'), 'Quiz thématique : score et feedback affichés à la fin');

  // --- Article du jour ---
  ok(hubSrc.includes('pickDailyToday(activeTheme.entries)'), 'Article du jour : une définition vedette par thème, changée chaque jour');
  ok(hubSrc.includes('pickDailyToday(globalEntries)') && hubSrc.includes('Article du jour —'), 'Article du jour : article vedette de toute l’encyclopédie affiché dans l’en-tête');
  const { pickDaily } = await import('../src/utils/dailyContent');
  const week = [...Array(7).keys()].map(d => pickDaily(quizPool, `2025-06-0${d + 1}`)?.word ?? '');
  ok(new Set(week).size > 1, 'Article du jour : le contenu change au fil des jours (pas figé)');
}

// ============================================================
section('27. Déploiement — fallback SPA Netlify, guide de publication exact');
{
  const fs10 = (await import('fs')).default;
  const path10 = (await import('path')).default;
  const read = (p: string) => fs10.readFileSync(path10.join(process.cwd(), p), 'utf8');

  // --- _redirects (fallback SPA) : copié dans dist/ par Vite ---
  ok(fs10.existsSync('public/_redirects'), 'Déploiement : fichier public/_redirects présent');
  const redirects = fs10.existsSync('public/_redirects') ? fs10.readFileSync('public/_redirects', 'utf8') : '';
  ok(redirects.includes('/*') && redirects.includes('/index.html') && redirects.includes('200'), 'Déploiement : règle « /* → /index.html 200 » exacte');

  // --- netlify.toml (déploiement Git) ---
  ok(fs10.existsSync('netlify.toml'), 'Déploiement : netlify.toml présent');
  const toml = fs10.existsSync('netlify.toml') ? fs10.readFileSync('netlify.toml', 'utf8') : '';
  ok(toml.includes('publish = "dist"'), 'Déploiement : dossier publié = dist');
  ok(toml.includes('[[redirects]]') && toml.includes('from = "/*"') && toml.includes('status = 200'), 'Déploiement : redirection SPA déclarée dans netlify.toml');

  // --- dist construite : le _redirects doit s'y trouver (si build disponible) ---
  if (fs10.existsSync('dist/_redirects')) {
    const distRedirects = fs10.readFileSync('dist/_redirects', 'utf8');
    ok(distRedirects.includes('/*') && distRedirects.includes('/index.html'), 'Déploiement : dist/_redirects présent après build (Netlify Drop)');
  } else {
    ok(true, 'Déploiement : dist/_redirects vérifié au prochain build (dist absent)');
  }

  // --- Guide de publication ---
  const guide = read('GUIDE-PUBLICATION-LIEN.md');
  ok(guide.includes('contenu de `dist/`') || guide.includes('contenu du dossier') || guide.includes('tout son contenu'), 'Guide : instructions pour déposer le CONTENU de dist/');
  ok(!guide.includes('master-soutien-pedagogique-v') || guide.includes('Ne glissez PAS'), 'Guide : avertissement contre le dépôt de l’archive ZIP');
  ok(guide.includes('_redirects') && (guide.includes('Page introuvable') || guide.includes('Page not found')), 'Guide : section dépannage (« Page not found ») et rôle du _redirects expliqués');
  ok(guide.includes('`npm run build`'), 'Guide : rappel de construire (npm run build) avant déploiement');
}

// ============================================================
section('28. Audit approfondi — PWA à jour, virgule décimale, déduplication');
{
  const fs11 = (await import('fs')).default;
  const path11 = (await import('path')).default;
  const read = (p: string) => fs11.readFileSync(path11.join(process.cwd(), p), 'utf8');

  // --- PWA : mises à jour propagées (network-first pour la navigation) ---
  const sw = read('public/sw.js');
  ok(sw.includes("event.request.mode === 'navigate'"), 'PWA : la navigation est gérée à part (mode navigate)');
  const navBlock = sw.split("event.request.mode === 'navigate'")[1] || '';
  ok(navBlock.includes('fetch(event.request)') && navBlock.includes('.catch('), 'PWA : navigation en RÉSEAU D’ABORD avec repli hors-ligne (au lieu du cache-first qui figeait les versions)');
  ok(sw.includes('master-soutien-v20'), 'PWA : nom de cache mis à jour (v20 — les anciens caches sont purgés à l’activation)');
  ok(sw.includes('skipWaiting') && sw.includes('clients.claim'), 'PWA : activation immédiate de la nouvelle version');
  const mainSrc = read('src/main.tsx');
  ok(mainSrc.includes('registration.update()'), 'PWA : vérification périodique d’une nouvelle version (registration.update)');
  ok(mainSrc.includes('controllerchange') && mainSrc.includes('window.location.reload()'), 'PWA : rechargement automatique quand la nouvelle version prend la main');

  // --- Virgule décimale (poids/taille) : « 72,5 » ne doit plus devenir 72 ---
  const { calculateBMI, bmiLabel } = await import('../src/utils/health');
  ok(calculateBMI(72, 170) !== null, 'IMC : valeurs numériques OK');
  const withComma = calculateBMI('72,5', '170');
  ok(withComma !== null && Math.abs(withComma - 72.5 / (1.7 * 1.7)) < 0.01, `IMC : « 72,5 » et « 170 » acceptés (virgule française) → ${withComma?.toFixed(2)}`);
  ok(calculateBMI('', '170') === null && calculateBMI('abc', '170') === null && calculateBMI(undefined, 170) === null, 'IMC : valeurs vides/invalides → null (pas de NaN)');
  ok(calculateBMI('80,5', '170') !== null, 'IMC : taille en cm (170) et poids avec virgule acceptés');
  ok(typeof bmiLabel(20) === 'string' && bmiLabel(null).includes('non calculé'), 'IMC : libellés de corpulence OK');

  // --- Déduplication : plus qu’UNE seule implémentation du calcul d’IMC ---
  const appSrc2 = read('src/App.tsx');
  ok(appSrc2.includes("from './utils/health'"), 'Dédup : App.tsx importe calculateBMI depuis utils/health');
  const localDefs = (appSrc2.match(/function calculateBMI/g) || []).length + (appSrc2.match(/function bmiLabel/g) || []).length;
  ok(localDefs === 0, 'Dédup : plus aucune définition locale dupliquée dans App.tsx');
  ok(appSrc2.includes('parseDecimal') && !appSrc2.includes('parseFloat(newStudent.weightKg') && !appSrc2.includes('parseFloat(newStudent.heightCm'), 'Saisie : poids/taille convertis via parseDecimal (virgule gérée à l’ajout ET à l’édition)');
  const profileSrc = read('src/components/StudentProfileEntry.tsx');
  ok(profileSrc.includes('calculateBMI') && profileSrc.includes('bmiLabel'), 'Fiche élève : IMC cohérent avec le même utilitaire');
}

// ============================================================
section('29. Déploiement Vercel — vercel.json + guide : fini le « 404: NOT_FOUND »');
{
  const fs12 = (await import('fs')).default;
  const path12 = (await import('path')).default;
  const read = (p: string) => fs12.readFileSync(path12.join(process.cwd(), p), 'utf8');

  // --- vercel.json à la racine du projet (déploiement Git) ---
  ok(fs12.existsSync('vercel.json'), 'Vercel : vercel.json présent à la racine du projet');
  const vjson = fs12.existsSync('vercel.json') ? JSON.parse(fs12.readFileSync('vercel.json', 'utf8')) : {};
  ok(Array.isArray(vjson.rewrites) && vjson.rewrites.length > 0, 'Vercel : tableau rewrites présent');
  ok(vjson.rewrites?.some((r: any) => r.source === '/(.*)' && r.destination === '/index.html'), 'Vercel : règle « /(.*) → /index.html » (toutes les routes SPA)');

  // --- vercel.json dans public/ (copié dans dist/ au build → glisser-déposer) ---
  ok(fs12.existsSync('public/vercel.json'), 'Vercel : public/vercel.json présent (sera copié dans dist/)');
  const pjson = fs12.existsSync('public/vercel.json') ? JSON.parse(fs12.readFileSync('public/vercel.json', 'utf8')) : {};
  ok(pjson.rewrites?.some((r: any) => r.source === '/(.*)' && r.destination === '/index.html'), 'Vercel : même règle dans la copie déployable');

  // --- Guide : méthode Vercel explicite (contrairement à l’ancienne version) ---
  const guide2 = read('GUIDE-PUBLICATION-LIEN.md');
  ok((guide2.includes('Construisez') || guide2.includes('construit automatiquement')) && guide2.includes('npm run build'), 'Guide Vercel : construction préalable expliquée (npm run build)');
  ok(guide2.includes('Output Directory') && guide2.includes('dist'), 'Guide Vercel : Output Directory = dist (cause du 404 en Git)');
  ok(guide2.includes('404: NOT_FOUND'), 'Guide Vercel : erreur « 404: NOT_FOUND » documentée dans le dépannage');
  ok(guide2.includes('vercel.json') && guide2.includes('réécrit'), 'Guide Vercel : rôle du vercel.json expliqué (routes → index.html)');
  ok(guide2.includes('Ne déposez PAS') || guide2.includes('Ne glissez PAS'), 'Guide Vercel : avertissement contre le ZIP / dossier source');
}

// ============================================================
section('30. Bulletins — prise en compte de la bonne note (formative vs sommative)');
{
  const subjects = [
    makeSubject('s1', 'Dictée', 18, 2, 0),
    makeSubject('s2', 'Math', 18, 2, 1),
  ];
  const student = makeStudent('e1', '001', 'DOSSOU', 'Ali');
  // Piège historique : 2 notes par élève/matière → le bulletin prenait la
  // PREMIÈRE (formative 5/0) au lieu de la sommative (15/2).
  const notes: Note[] = [
    { ...makeNote('n1', 'e1', 's1', 5, 0), evaluation: 'formative1', updatedAt: 1 },
    { ...makeNote('n2', 'e1', 's1', 15, 2), evaluation: 'sommative1', updatedAt: 2 },
    { ...makeNote('n3', 'e1', 's2', 6, 0), evaluation: 'formative1', updatedAt: 3 },
    { ...makeNote('n4', 'e1', 's2', 14, 2), evaluation: 'sommative1', updatedAt: 4 },
  ];
  const classData: ClassData = {
    id: 'c1', name: 'CM1 A', school: 'EPP Test', level: 'CM1', educationType: 'primaire',
    schoolYear: '2026-2027', sequence: 'Devoirs surveillés', students: [student], subjects, notes,
    createdAt: 0, updatedAt: 0,
  };

  // 1) findBestNote : la sommative prioritaire (15/2), pas la formative
  const best = findBestNote(notes, 'e1', 's1');
  ok(best !== undefined && best.id === 'n2', 'findBestNote retourne la dernière note sommative (15/2), pas la formative (5/0)', `→ ${best?.id}`);

  // 2) computeBulletins : moyenne 16.5 (ancien bug : 5.5)
  const b = computeBulletins(classData).find(x => x.student.id === 'e1');
  ok(b !== undefined, 'computeBulletins produit un bulletin pour l’élève');
  ok(b !== undefined && Math.abs((b.moyenne ?? 0) - 16.5) < 0.01, 'Moyenne du bulletin = 16.5 (au lieu de 5.5 avant correctif)', `→ ${b?.moyenne}`);
  const dict = b?.results.find(r => r.subject.id === 's1');
  ok(dict !== undefined && Math.abs((dict.total ?? 0) - 17) < 0.01, 'Note Dictée /20 = 17 (15+2), fini la note formative 5', `→ ${dict?.total}`);

  // 3) Toujours la plus récente si plusieurs sommatives
  const notes3 = [
    { ...makeNote('n1', 'e1', 's1', 15, 2), evaluation: 'sommative1', updatedAt: 1 },
    { ...makeNote('n2', 'e1', 's1', 12, 1), evaluation: 'sommative2', updatedAt: 5 },
  ];
  const best3 = findBestNote(notes3, 'e1', 's1');
  ok(best3 !== undefined && best3.id === 'n2', 'Priorité à la sommative la plus récente (sommative2 si plusieurs)', `→ ${best3?.id}`);

  // 4) Absence : non comptée dans la moyenne
  const notes4 = [
    { ...makeNote('n1', 'e1', 's1', 0, 0, true), evaluation: 'sommative1', updatedAt: 1 },
    { ...makeNote('n2', 'e1', 's2', 10, 2), evaluation: 'sommative1', updatedAt: 2 },
  ];
  const b4 = computeBulletins({ ...classData, notes: notes4 }).find(x => x.student.id === 'e1');
  ok(b4 !== undefined && Math.abs((b4.moyenne ?? 0) - 12) < 0.01, 'Élève absent en Dictée : moyenne calculée sur les matières notées (12)', `→ ${b4?.moyenne}`);

  // 5) Plus aucun « notes.find » dispersé sur l’ensemble du code source
  const fs30 = (await import('fs')).default;
  const path30 = (await import('path')).default;
  function walk(dir: string): string[] {
    const out: string[] = [];
    for (const ent of fs30.readdirSync(dir, { withFileTypes: true })) {
      const p = path30.join(dir, ent.name);
      if (ent.isDirectory()) out.push(...walk(p));
      else if (/(\.ts|\.tsx)$/.test(ent.name) && !ent.name.endsWith('.d.ts')) out.push(p);
    }
    return out;
  }
  const offenders: string[] = [];
  for (const file of walk('src')) {
    const code = fs30.readFileSync(file, 'utf8').replace(/\/\/.*$/gm, '');
    // Seule l’implémentation centrale dans database.ts a le droit d’utiliser notes.find
    if (file.endsWith('utils/database.ts')) continue;
    const m = code.match(/notes\.find\(/g);
    if (m) offenders.push(`${file} (${m.length})`);
  }
  ok(offenders.length === 0, 'Aucun « notes.find » dans le code applicatif (centralisé dans findBestNote)', offenders.join(', '));

  // 6) Formulaire « Nouvelle classe » : les 3 types d’évaluation proposés
  const app = fs30.readFileSync('src/App.tsx', 'utf8');
  ok(app.includes("value: 'Evaluation'") && app.includes("value: 'Devoirs surveillés'") && app.includes("value: 'Interrogation écrite'"),
    'Formulaire Nouvelle classe : 3 types proposés (Évaluation / Devoirs surveillés / Interrogation écrite)');
  ok(app.includes("Type d'évaluation"), 'Formulaire Nouvelle classe : champ « Type d’évaluation » explicite');

  // 7) Le type saisi se retrouve sur le bulletin (Word + Excel + écran)
  const be = fs30.readFileSync('src/utils/bulletinExport.ts', 'utf8');
  ok(be.includes('classData.sequence'), 'Type d’évaluation repris dans les exports de bulletins (Word + Excel)');
  const bs = fs30.readFileSync('src/components/BulletinsScreen.tsx', 'utf8');
  ok(bs.includes('classData.sequence'), 'Type d’évaluation affiché sur l’écran de bulletins');
}

// ============================================================
section('31. Publication simplifiée — assistant « npm run deploy:check »');
{
  const fs31 = (await import('fs')).default;
  const path31 = (await import('path')).default;
  const read = (p: string) => fs31.readFileSync(path31.join(process.cwd(), p), 'utf8');

  ok(fs31.existsSync('scripts/deploy-check.mjs'), 'Assistant de publication présent (scripts/deploy-check.mjs)');
  const pkg = JSON.parse(read('package.json'));
  ok(pkg.scripts?.['deploy:check'] === 'node scripts/deploy-check.mjs', 'package.json : script « deploy:check » disponible');
  ok(read('package.json').includes('"deploy:check"'), 'Une seule commande suffit : npm run deploy:check');

  const script = read('scripts/deploy-check.mjs');
  ok(script.includes('npm run build'), 'L’assistant construit automatiquement si dist/ est absent');
  ok(script.includes('index.html') && script.includes('sw.js') && script.includes('_redirects'),
    'L’assistant vérifie les fichiers de publication (index.html, sw.js, _redirects)');
  ok(script.includes('netlify.com/drop'), 'Assistant : étapes Netlify Drop affichées');
  ok(script.includes('vercel.com') && script.includes('404: NOT_FOUND'),
    'Assistant : étapes Vercel + piège du 404 expliqué');

  const guide3 = read('GUIDE-PUBLICATION-LIEN.md');
  ok(guide3.includes('deploy:check'), 'Guide : la méthode « 1 commande » (deploy:check) documentée en tête');
  ok(guide3.includes('Ne glissez PAS') && guide3.includes('ZIP'), 'Guide : avertissement contre le ZIP / dossier source');
  ok(guide3.includes('Output Directory') && guide3.includes('dist'), 'Guide : Output Directory = dist (Vercel Git)');
  ok(guide3.includes('Dépannage'), 'Guide : tableau de dépannage (404 Netlify / 404 Vercel / hors-ligne)');
}

// ============================================================
console.log(`\n════════════════════════════════════`);
console.log(`RÉSULTATS : ${pass} réussis, ${fail} échoués`);
if (fail > 0) {
  console.log('\nÉchecs :');
  errors.forEach(e => console.log('  - ' + e));
  process.exit(1);
}
}

main().catch((e) => { console.error('Erreur d\'exécution:', e); process.exit(1); });
