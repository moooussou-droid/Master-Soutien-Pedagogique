import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookMarked, ChevronLeft, Plus, Printer, Search, Shield, Square, Trash2, Volume2, X } from 'lucide-react';
import { ADMIN_PASSWORD } from '../utils/adminConfig';
import { getVideoEmbed } from '../utils/courseMarketplace';
import { illustrate } from '../utils/svgIllustration';
import { normalizeSearch } from '../utils/textSearch';
import { pickDailyToday } from '../utils/dailyContent';
import { isSpeechSupported, useTextToSpeech, warmVoices } from '../utils/speech';
import { generateQuiz, loadBestScore, saveBestScore, quizMessage } from '../utils/kidsQuiz';
import { printFlashcards } from '../utils/flashcards';

interface KidWord {
  word: string;
  definition: string;
  example: string;
  family: string;
  imageUrl?: string;
  videoUrl?: string;
}

const CUSTOM_KEY = 'msp_kids_dictionary_custom_words';

function loadCustomWords(): KidWord[] {
  try { return JSON.parse(localStorage.getItem(CUSTOM_KEY) || '[]'); } catch { return []; }
}
function saveCustomWords(words: KidWord[]) { localStorage.setItem(CUSTOM_KEY, JSON.stringify(words)); }

const WORDS: KidWord[] = [
  ['Addition', 'Une addition sert à mettre ensemble plusieurs nombres pour trouver un total.', '2 + 3 = 5.', 'Mathématiques'],
  ['Soustraction', 'Une soustraction sert à enlever une quantité d’une autre.', '8 - 3 = 5.', 'Mathématiques'],
  ['Multiplication', 'Une multiplication est une addition répétée.', '3 × 4 veut dire 4 + 4 + 4.', 'Mathématiques'],
  ['Division', 'Une division sert à partager en parts égales.', '12 bonbons partagés entre 3 enfants donnent 4 bonbons chacun.', 'Mathématiques'],
  ['Phrase', 'Une phrase est un groupe de mots qui a un sens.', 'Le chat dort.', 'Français'],
  ['Verbe', 'Le verbe indique souvent une action ou un état.', 'courir, manger, être.', 'Français'],
  ['Nom', 'Un nom désigne une personne, un animal, une chose ou un lieu.', 'élève, chien, cahier, école.', 'Français'],
  ['Adjectif', 'Un adjectif donne une information sur un nom.', 'un joli dessin.', 'Français'],
  ['Microbe', 'Un microbe est un être très petit qui peut parfois rendre malade.', 'Se laver les mains aide à éviter les microbes.', 'Santé'],
  ['Vaccin', 'Un vaccin aide le corps à se défendre contre une maladie.', 'Le vaccin protège l’enfant.', 'Santé'],
  ['Hygiène', 'L’hygiène est l’ensemble des gestes pour rester propre et en bonne santé.', 'Se laver les mains avant de manger.', 'Santé'],
  ['Citoyen', 'Un citoyen est une personne qui appartient à un pays et respecte ses règles.', 'Un citoyen respecte les lois.', 'Citoyenneté'],
  ['Respect', 'Le respect consiste à bien se comporter avec les autres.', 'On écoute quand quelqu’un parle.', 'Citoyenneté'],
  ['Drapeau', 'Un drapeau est un symbole qui représente un pays ou un groupe.', 'Le drapeau du Bénin est vert, jaune et rouge.', 'Bénin'],
  ['Carte', 'Une carte est un dessin qui représente un lieu.', 'Une carte montre les villes et les routes.', 'Géographie'],
  ['Fleuve', 'Un fleuve est un grand cours d’eau qui se jette dans la mer.', 'Le fleuve Niger traverse plusieurs pays.', 'Géographie'],
  ['Plante', 'Une plante est un être vivant qui pousse dans la terre ou dans l’eau.', 'Le maïs est une plante.', 'Sciences'],
  ['Animal', 'Un animal est un être vivant qui respire et se nourrit.', 'La chèvre est un animal.', 'Sciences'],
  ['Énergie', 'L’énergie permet de faire fonctionner des objets ou de produire un effort.', 'Le soleil donne de l’énergie.', 'Sciences'],
  ['Internet', 'Internet permet d’échanger des informations avec un téléphone ou un ordinateur.', 'On peut apprendre en ligne.', 'Hightech'],
  ['Ordinateur', 'Un ordinateur est une machine qui aide à écrire, calculer et apprendre.', 'Le maître prépare un document sur ordinateur.', 'Hightech'],
  ['Agriculture', 'L’agriculture consiste à cultiver la terre et élever des animaux.', 'Le cultivateur plante du maïs.', 'Agriculture'],
  ['Épargne', 'L’épargne est l’argent qu’on garde pour plus tard.', 'Je garde une partie de mon argent.', 'Finance'],
  ['Métier', 'Un métier est un travail qu’on apprend pour rendre service et gagner sa vie.', 'Médecin, enseignant, mécanicien.', 'Orientation'],
].map(([word, definition, example, family]) => ({ word, definition, example, family }));

const imageUrl = (item: KidWord) => item.imageUrl || illustrate(`${item.word} école enfant`, item.word);
const videoId = (word: string) => {
  const w = word.toLowerCase();
  if (w.includes('addition') || w.includes('multiplication') || w.includes('division')) return '4O8X7xG6dpA';
  if (w.includes('phrase') || w.includes('verbe') || w.includes('nom')) return 'VeSUzYblKio';
  if (w.includes('microbe') || w.includes('vaccin') || w.includes('hygiène')) return 'tZ4lCI6Pyoo';
  return 'KCGamQMZ7Nk';
};

type QuizMode = 'off' | 'playing' | 'done';

export default function KidsDictionaryScreen() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [family, setFamily] = useState('Toutes');
  const [selected, setSelected] = useState<KidWord | null>(null);
  const [customWords, setCustomWords] = useState<KidWord[]>(loadCustomWords());
  const [adminUnlocked, setAdminUnlocked] = useState(localStorage.getItem('msp_kids_dict_admin') === 'true');
  const [newWord, setNewWord] = useState<KidWord>({ word: '', definition: '', example: '', family: 'Général', imageUrl: '', videoUrl: '' });

  // Quiz « Devine le mot »
  const [quizMode, setQuizMode] = useState<QuizMode>('off');
  const [quizQuestions, setQuizQuestions] = useState<ReturnType<typeof generateQuiz>>([]);
  const [quizIndex, setQuizIndex] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [quizPicked, setQuizPicked] = useState<string | null>(null);
  const [bestScore, setBestScore] = useState(loadBestScore());

  const allWords = useMemo(() => {
    const base = [...WORDS];
    for (const custom of customWords) {
      const idx = base.findIndex(w => w.word.toLowerCase() === custom.word.toLowerCase());
      if (idx >= 0) base[idx] = custom;
      else base.push(custom);
    }
    return base;
  }, [customWords]);
  const families = ['Toutes', ...Array.from(new Set(allWords.map(w => w.family)))];
  const nq = normalizeSearch(query);
  const filtered = useMemo(() => allWords.filter(w => (family === 'Toutes' || w.family === family) && normalizeSearch(`${w.word} ${w.definition} ${w.example} ${w.family}`).includes(nq)), [query, family, allWords, nq]);
  const dailyWord = useMemo(() => pickDailyToday(allWords), [allWords]);
  const question = quizQuestions[quizIndex];

  useEffect(() => { warmVoices(); }, []);

  function unlockAdmin() {
    const password = prompt('Mot de passe administrateur :');
    if (password === ADMIN_PASSWORD) { localStorage.setItem('msp_kids_dict_admin', 'true'); setAdminUnlocked(true); }
    else if (password !== null) alert('Mot de passe incorrect.');
  }

  function saveWord() {
    if (!newWord.word.trim()) return alert('Ajoutez un mot.');
    const next = [...customWords.filter(w => w.word.toLowerCase() !== newWord.word.toLowerCase()), newWord];
    setCustomWords(next); saveCustomWords(next);
    setNewWord({ word: '', definition: '', example: '', family: 'Général', imageUrl: '', videoUrl: '' });
  }

  function deleteWord(word: string) {
    if (!confirm(`Supprimer le mot « ${word} » ?`)) return;
    const next = customWords.filter(w => w.word.toLowerCase() !== word.toLowerCase());
    setCustomWords(next); saveCustomWords(next);
  }

  function startQuiz() {
    const questions = generateQuiz(allWords, 5);
    setQuizQuestions(questions);
    setQuizIndex(0);
    setQuizScore(0);
    setQuizPicked(null);
    setQuizMode('playing');
  }

  function pickOption(opt: string) {
    if (!question || quizPicked) return;
    setQuizPicked(opt);
    if (opt === question.correct) {
      const newScore = quizScore + 1;
      setQuizScore(newScore);
      const newBest = Math.max(bestScore, newScore);
      setBestScore(newBest);
      saveBestScore(newScore);
    }
  }

  function nextQuestion() {
    if (quizIndex + 1 >= quizQuestions.length) setQuizMode('done');
    else { setQuizIndex(quizIndex + 1); setQuizPicked(null); }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow"><div className="flex items-center gap-3"><button onClick={() => navigate('/')} className="p-2 bg-white/20 rounded-lg"><ChevronLeft className="w-6 h-6" /></button><div><h1 className="font-bold text-lg">Dictionnaire des petits écoliers</h1><p className="text-emerald-100 text-sm">Mots faciles, images, voix et jeux</p></div></div></header>
      <main className="p-4 pb-24 max-w-5xl mx-auto">
        <section className="bg-white rounded-2xl shadow p-4 mb-4"><h2 className="font-black text-gray-900">Comprendre les mots simplement</h2><p className="text-gray-500 text-sm">Chaque mot est expliqué avec une définition facile, un exemple, une image, une voix et une vidéo.</p><div className="relative mt-4"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Chercher un mot... (sans tenir compte des accents)" className="w-full pl-10 pr-4 py-3 border rounded-lg" /></div></section>

        {/* ⭐ Le mot du jour */}
        {dailyWord && (
          <section className="bg-gradient-to-r from-amber-400 to-orange-400 rounded-2xl shadow p-4 mb-4">
            <div className="flex items-center gap-3">
              <span className="text-3xl">⭐</span>
              <div className="flex-1 min-w-0">
                <p className="text-[11px] font-bold text-amber-900/70 uppercase">Le mot du jour</p>
                <div className="flex items-center gap-2">
                  <h2 className="text-2xl font-black text-amber-950">{dailyWord.word}</h2>
                  {isSpeechSupported() && <DailySpeakButton word={dailyWord} />}
                </div>
                <p className="text-sm text-amber-950/80 line-clamp-2">{dailyWord.definition}</p>
              </div>
            </div>
          </section>
        )}

        {/* 🎓 Devine le mot */}
        <section className="bg-white rounded-2xl shadow p-4 mb-4">
          {quizMode === 'off' && (
            <div className="flex items-center gap-3">
              <span className="text-3xl">🎓</span>
              <div className="flex-1">
                <h2 className="font-black text-gray-900">Devine le mot !</h2>
                <p className="text-gray-500 text-sm">Écoute la définition et choisis le bon mot. {bestScore > 0 && <span className="font-semibold text-emerald-700">Meilleur score : {bestScore}/5</span>}</p>
              </div>
              <button onClick={startQuiz} className="bg-emerald-600 text-white px-4 py-2.5 rounded-xl font-bold shrink-0">Jouer</button>
            </div>
          )}
          {quizMode === 'playing' && question && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-bold text-emerald-700 uppercase">Question {quizIndex + 1} / {quizQuestions.length}</p>
                <button onClick={() => setQuizMode('off')} className="text-gray-400 text-sm">Quitter</button>
              </div>
              <div className="flex items-start gap-2 bg-gray-50 rounded-xl p-4">
                <button
                  onClick={() => speakTextSafe(`${question.definition}${question.example ? ' Exemple : ' + question.example : ''}`)}
                  className="bg-amber-100 text-amber-800 p-2.5 rounded-full shrink-0"
                  title="Écouter la définition"
                >
                  <Volume2 className="w-5 h-5" />
                </button>
                <div>
                  <p className="font-semibold text-gray-800 text-lg">{question.definition}</p>
                  {question.example && <p className="text-sm text-gray-500 mt-1">Exemple : {question.example}</p>}
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3">
                {question.options.map(opt => {
                  const isCorrect = opt === question.correct;
                  const revealed = quizPicked !== null;
                  const good = revealed && isCorrect;
                  const bad = revealed && quizPicked === opt && !isCorrect;
                  return (
                    <button
                      key={opt}
                      onClick={() => pickOption(opt)}
                      disabled={revealed}
                      className={`p-3 rounded-xl border-2 font-bold text-left transition-colors ${good ? 'bg-emerald-50 border-emerald-500 text-emerald-800' : bad ? 'bg-red-50 border-red-400 text-red-700' : revealed ? 'bg-gray-50 border-gray-200 text-gray-400' : 'bg-white border-gray-200 text-gray-800 hover:border-emerald-400'}`}
                    >
                      {opt} {good && '✅'} {bad && '❌'}
                    </button>
                  );
                })}
              </div>
              {quizPicked && (
                <button onClick={nextQuestion} className="mt-3 w-full bg-emerald-600 text-white py-3 rounded-xl font-bold">
                  {quizIndex + 1 >= quizQuestions.length ? 'Voir mon résultat' : 'Question suivante'}
                </button>
              )}
            </div>
          )}
          {quizMode === 'done' && (
            <div className="text-center py-2">
              <p className="text-5xl font-black text-emerald-700">{quizScore} / {quizQuestions.length}</p>
              <p className="font-bold text-gray-800 mt-2 text-lg">{quizMessage(quizScore, quizQuestions.length)}</p>
              <p className="text-gray-500 text-sm mt-1">Meilleur score : {bestScore}/5</p>
              <div className="flex gap-2 mt-4">
                <button onClick={startQuiz} className="flex-1 bg-emerald-600 text-white py-3 rounded-xl font-bold">Rejouer</button>
                <button onClick={() => setQuizMode('off')} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-bold">Fermer</button>
              </div>
            </div>
          )}
        </section>

        <section className="bg-white rounded-2xl shadow p-4 mb-4"><div className="flex items-center justify-between"><h2 className="font-bold text-gray-900">Administration du dictionnaire</h2>{!adminUnlocked && <button onClick={unlockAdmin} className="bg-gray-800 text-white px-3 py-2 rounded-lg text-sm font-semibold flex items-center gap-1"><Shield className="w-4 h-4" /> Admin</button>}</div>{adminUnlocked && <div className="mt-3 grid gap-2"><input value={newWord.word} onChange={e => setNewWord({ ...newWord, word: e.target.value })} placeholder="Mot" className="p-3 border rounded-lg" /><input value={newWord.family} onChange={e => setNewWord({ ...newWord, family: e.target.value })} placeholder="Famille" className="p-3 border rounded-lg" /><input value={newWord.definition} onChange={e => setNewWord({ ...newWord, definition: e.target.value })} placeholder="Définition facile" className="p-3 border rounded-lg" /><input value={newWord.example} onChange={e => setNewWord({ ...newWord, example: e.target.value })} placeholder="Exemple" className="p-3 border rounded-lg" /><input value={newWord.imageUrl} onChange={e => setNewWord({ ...newWord, imageUrl: e.target.value })} placeholder="Lien image" className="p-3 border rounded-lg" /><input value={newWord.videoUrl} onChange={e => setNewWord({ ...newWord, videoUrl: e.target.value })} placeholder="Lien vidéo YouTube/Facebook/TikTok" className="p-3 border rounded-lg" /><button onClick={saveWord} className="bg-emerald-600 text-white py-3 rounded-lg font-semibold"><Plus className="w-4 h-4 inline mr-1" /> Ajouter / modifier</button>
          {customWords.length > 0 && (
            <div className="mt-3 space-y-1.5 border-t pt-3">
              <p className="text-xs font-bold text-gray-500 uppercase">Mots personnalisés ({customWords.length})</p>
              {customWords.map(c => (
                <div key={c.word} className="flex items-center gap-2 bg-gray-50 border rounded-lg px-3 py-2">
                  <p className="text-sm font-semibold text-gray-800 flex-1 truncate">{c.word} <span className="text-xs text-gray-400">({c.family})</span></p>
                  <button onClick={() => deleteWord(c.word)} className="text-red-500 p-1.5" title="Supprimer ce mot"><Trash2 className="w-4 h-4" /></button>
                </div>
              ))}
            </div>
          )}
        </div>}</section>
        <div className="flex gap-2 overflow-x-auto pb-2 mb-4">{families.map(f => <button key={f} onClick={() => setFamily(f)} className={`whitespace-nowrap px-4 py-2 rounded-lg font-bold text-sm ${family === f ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 border'}`}>{f}</button>)}</div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm text-gray-500">{query ? `🔎 ${filtered.length} résultat${filtered.length > 1 ? 's' : ''} — ` : ''}{filtered.length} mot{filtered.length > 1 ? 's' : ''} {family === 'Toutes' ? '' : `· ${family}`}</p>
          <button
            onClick={() => printFlashcards(filtered.map(w => ({ title: w.word, subtitle: w.family, body: `${w.definition}${w.example ? ' Exemple : ' + w.example : ''}` })), { title: `Le dictionnaire — ${family === 'Toutes' ? 'tous les mots' : family}`, subtitle: 'Cartes à découper : l’élève lit le mot, donne la définition, puis vérifie au verso.' })}
            className="shrink-0 bg-gray-100 text-gray-700 px-3 py-2 rounded-lg text-sm font-semibold flex items-center gap-1.5"
            title="Imprimer les cartes des mots affichés"
          >
            <Printer className="w-4 h-4" /> <span className="hidden sm:inline">Imprimer les cartes</span>
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">{filtered.map(item => <button key={item.word} onClick={() => setSelected(item)} className="bg-white rounded-2xl shadow text-left overflow-hidden"><img src={imageUrl(item)} alt={item.word} className="w-full h-28 object-cover bg-gray-100" onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} /><div className="p-4"><div className="flex items-center gap-2"><BookMarked className="w-5 h-5 text-emerald-600" /><h2 className="font-black text-gray-900">{item.word}</h2></div><p className="text-xs text-emerald-700 mt-1">{item.family}</p><p className="text-gray-700 text-sm mt-2 line-clamp-3">{item.definition}</p></div></button>)}</div>
      </main>
      {selected && <KidWordModal word={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

function DailySpeakButton({ word }: { word: KidWord }) {
  const { speaking, speak, stop } = useTextToSpeech();
  return (
    <button
      onClick={() => (speaking ? stop() : speak(`${word.word}. ${word.definition} Exemple : ${word.example}`))}
      className={`p-2 rounded-full ${speaking ? 'bg-amber-950 text-amber-100' : 'bg-white/70 text-amber-900'}`}
      title={speaking ? 'Arrêter' : 'Écouter le mot'}
    >
      {speaking ? <Square className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
    </button>
  );
}

function speakTextSafe(text: string) {
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'fr-FR';
    u.rate = 0.95;
    window.speechSynthesis.speak(u);
  } catch { /* silencieux */ }
}

function KidWordModal({ word, onClose }: { word: KidWord; onClose: () => void }) {
  const { speaking, speak, stop } = useTextToSpeech();
  const online = typeof navigator === 'undefined' || navigator.onLine !== false;
  const embed = word.videoUrl ? getVideoEmbed(word.videoUrl) : `https://www.youtube-nocookie.com/embed/${videoId(word.word)}?rel=0&modestbranding=1&playsinline=1`;
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full overflow-hidden">
        <div className="relative">
          <img src={imageUrl(word)} alt={word.word} className="w-full h-48 object-cover bg-gray-100" />
          <button onClick={onClose} className="absolute top-3 right-3 bg-white/90 p-2 rounded-lg"><X className="w-6 h-6" /></button>
        </div>
        <div className="p-5">
          <p className="text-emerald-700 font-bold text-sm">{word.family}</p>
          <div className="flex items-center gap-3">
            <h2 className="text-3xl font-black text-gray-900">{word.word}</h2>
            {isSpeechSupported() && (
              <button onClick={() => (speaking ? stop() : speak(`${word.word}. ${word.definition} Exemple : ${word.example}`))} className={`p-2.5 rounded-full ${speaking ? 'bg-emerald-600 text-white' : 'bg-amber-100 text-amber-800'}`} title={speaking ? 'Arrêter la lecture' : 'Écouter'}>
                {speaking ? <Square className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
              </button>
            )}
          </div>
          <p className="text-lg text-gray-700 mt-3">{word.definition}</p>
          <p className="text-emerald-700 font-semibold mt-3">Exemple : {word.example}</p>
          {embed && online ? (
            <div className="mt-5 aspect-video bg-black rounded-xl overflow-hidden"><iframe src={embed} title={word.word} className="w-full h-full" allowFullScreen /></div>
          ) : embed ? (
            <div className="mt-5 bg-gray-50 border border-dashed border-gray-300 rounded-xl p-5 text-center text-gray-500 text-sm">📡 Vidéo en ligne mais vous êtes hors connexion pour le moment.</div>
          ) : null}
          <button onClick={onClose} className="mt-4 w-full bg-emerald-600 text-white py-3 rounded-xl font-bold">J’ai compris</button>
        </div>
      </div>
    </div>
  );
}
