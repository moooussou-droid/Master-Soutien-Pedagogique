import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Briefcase, ChevronLeft, ClipboardCopy, GraduationCap, Search, Target, UserRound } from 'lucide-react';
import { ClassData, getAllClasses, sortStudents } from '../utils/database';
import { buildOrientationRecommendations, loadOrientationExtras, OrientationRecommendation } from '../utils/orientation';

export default function OrientationScolaireScreen() {
  const navigate = useNavigate();
  const [classes, setClasses] = useState<ClassData[]>([]);
  const [classId, setClassId] = useState('');
  const [studentId, setStudentId] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    getAllClasses().then(data => {
      const sorted = [...data].sort((a, b) => a.name.localeCompare(b.name));
      setClasses(sorted);
      if (sorted[0]) setClassId(sorted[0].id);
    });
  }, []);

  const selectedClass = classes.find(c => c.id === classId);
  const students = useMemo(() => sortStudents(selectedClass?.students || []), [selectedClass]);

  useEffect(() => {
    if (students[0]) setStudentId(students[0].id);
    else setStudentId('');
  }, [classId, students.length]);

  const filteredStudents = students.filter(student => `${student.nom} ${student.prenoms}`.toLowerCase().includes(search.toLowerCase()));
  const student = students.find(s => s.id === studentId);
  const analysis = selectedClass && student ? buildOrientationRecommendations(selectedClass, student) : null;
  const extras = loadOrientationExtras();
  const relatedExtras = analysis
    ? extras.filter(extra => analysis.recommendations.some(rec => extra.domains.includes(rec.domain) || extra.series.toLowerCase().includes(rec.series.toLowerCase().split(',')[0] || '')))
    : [];

  async function copyReport() {
    if (!student || !analysis) return;
    const text = `Orientation scolaire - ${student.nom.toUpperCase()} ${student.prenoms}\n\nPerformances :\n${analysis.performances.map(p => `- ${p.subjectName}: ${p.score.toFixed(2)}/20`).join('\n')}\n\nRecommandations :\n${analysis.recommendations.map(r => `- ${r.title}\nSéries/Filières : ${r.series}\nMatières à renforcer : ${r.subjectsToStrengthen.join(', ')}\nDébouchés : ${r.careers.join(', ')}`).join('\n\n')}`;
    await navigator.clipboard?.writeText(text);
    alert('Conseil d’orientation copié.');
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 bg-white/20 rounded-lg"><ChevronLeft className="w-6 h-6" /></button>
          <div>
            <h1 className="font-bold text-lg">Orientation scolaire</h1>
            <p className="text-emerald-100 text-sm">Parcours futurs selon les performances de l’élève</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24 max-w-6xl mx-auto">
        <section className="bg-white rounded-2xl shadow p-4 mb-4">
          <h2 className="font-bold text-gray-900 mb-3">Choisir une classe et un élève</h2>
          <div className="grid gap-3 md:grid-cols-2">
            <select value={classId} onChange={e => setClassId(e.target.value)} className="w-full p-3 border rounded-lg">
              {classes.map(c => <option key={c.id} value={c.id}>{c.name} - {c.school}</option>)}
            </select>
            <div className="relative">
              <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher un élève..." className="w-full pl-10 pr-4 py-3 border rounded-lg" />
            </div>
          </div>
          <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
            {filteredStudents.map(s => (
              <button key={s.id} onClick={() => setStudentId(s.id)} className={`whitespace-nowrap rounded-lg px-3 py-2 text-sm font-semibold ${studentId === s.id ? 'bg-emerald-600 text-white' : 'bg-gray-100 text-gray-700'}`}>
                {s.nom.toUpperCase()} {s.prenoms}
              </button>
            ))}
          </div>
        </section>

        {!student || !analysis ? (
          <div className="bg-white rounded-xl shadow p-8 text-center">
            <UserRound className="w-14 h-14 text-gray-300 mx-auto mb-3" />
            <p className="font-semibold text-gray-700">Sélectionnez un élève ayant des notes.</p>
          </div>
        ) : (
          <>
            <section className="bg-white rounded-2xl shadow p-4 mb-4">
              <div className="flex items-center gap-3 mb-4">
                {student.photoUrl ? <img src={student.photoUrl} className="w-14 h-14 rounded-full object-cover border" /> : <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">{student.nom[0]}{student.prenoms?.[0] || ''}</div>}
                <div>
                  <h2 className="font-black text-gray-900">{student.nom.toUpperCase()} {student.prenoms}</h2>
                  <p className="text-gray-500 text-sm">Analyse des forces disciplinaires et pistes d’orientation</p>
                </div>
              </div>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analysis.performances.map(p => ({ name: p.subjectName, score: Number(p.score.toFixed(2)) }))} margin={{ top: 10, right: 10, left: -16, bottom: 60 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-25} textAnchor="end" interval={0} fontSize={10} />
                    <YAxis domain={[0, 20]} />
                    <Tooltip formatter={(value) => [`${value}/20`, 'Score']} />
                    <Bar dataKey="score" fill="#059669" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <button onClick={copyReport} className="w-full mt-3 bg-emerald-600 text-white py-3 rounded-xl font-semibold inline-flex items-center justify-center gap-2"><ClipboardCopy className="w-5 h-5" /> Copier le conseil d’orientation</button>
            </section>

            <section className="grid gap-4 md:grid-cols-2">
              {analysis.recommendations.map(rec => <RecommendationCard key={rec.title} rec={rec} />)}
            </section>

            {relatedExtras.length > 0 && (
              <section className="bg-white rounded-2xl shadow p-4 mt-4">
                <h2 className="font-bold text-gray-900 mb-3">Informations ajoutées par l’administration</h2>
                <div className="space-y-2">
                  {relatedExtras.map(extra => (
                    <div key={extra.id} className="border rounded-lg p-3">
                      <p className="font-bold text-gray-900">{extra.title}</p>
                      <p className="text-xs text-gray-500">Séries : {extra.series}</p>
                      <p className="text-sm text-gray-700 mt-1"><strong>Matières :</strong> {extra.subjects}</p>
                      <p className="text-sm text-gray-700"><strong>Études :</strong> {extra.studies}</p>
                      <p className="text-sm text-gray-700"><strong>Débouchés :</strong> {extra.careers}</p>
                      <p className="text-sm text-emerald-700 mt-1">{extra.advice}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </main>
    </div>
  );
}

function RecommendationCard({ rec }: { rec: OrientationRecommendation }) {
  const badge = rec.priority === 'forte'
    ? 'bg-emerald-100 text-emerald-700'
    : rec.priority === 'moyenne'
      ? 'bg-amber-100 text-amber-700'
      : 'bg-gray-100 text-gray-700';
  return (
    <div className="bg-white rounded-2xl shadow p-4">
      <div className="flex items-start justify-between gap-2 mb-3">
        <h2 className="font-black text-gray-900">{rec.title}</h2>
        <span className={`rounded px-2 py-1 text-xs font-bold ${badge}`}>{rec.priority}</span>
      </div>
      <p className="text-sm text-gray-600 mb-3">{rec.reason}</p>
      <InfoLine icon={GraduationCap} label="Séries / filières" value={rec.series} />
      <InfoLine icon={BookOpenIcon} label="Études" value={rec.studies.join(', ')} />
      <InfoLine icon={Target} label="Matières à renforcer" value={rec.subjectsToStrengthen.join(', ')} />
      <InfoLine icon={Briefcase} label="Débouchés" value={rec.careers.join(', ')} />
    </div>
  );
}

function BookOpenIcon(props: any) {
  return <GraduationCap {...props} />;
}

function InfoLine({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="mb-2 flex items-start gap-2 text-sm">
      <Icon className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
      <p><strong className="text-gray-800">{label} :</strong> <span className="text-gray-600">{value}</span></p>
    </div>
  );
}
