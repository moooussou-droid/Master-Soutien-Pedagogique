import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, FileText, FileSpreadsheet, Loader2, UserCheck } from 'lucide-react';
import { ClassData, getClass, sortStudents } from '../utils/database';
import {
  exportAttendanceExcel, exportAttendanceDocx,
  availableMonths, recordsForMonth,
} from '../utils/attendanceExport';

type AttendanceStatus = 'present' | 'absent_injustifiee' | 'absent_justifiee' | 'retard';

interface AttendanceEntry {
  studentId: string;
  status: AttendanceStatus;
  motif?: string;
}

interface AttendanceDay {
  id: string;
  classId: string;
  date: string;
  entries: AttendanceEntry[];
}

const STORAGE_KEY = 'msp_attendance_records';

function loadRecords(): AttendanceDay[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  } catch {
    return [];
  }
}

function saveRecords(records: AttendanceDay[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function today() {
  return new Date().toISOString().split('T')[0];
}

const STATUS_LABELS: Record<AttendanceStatus, string> = {
  present: 'Présent',
  absent_injustifiee: 'Abs. injustifiée',
  absent_justifiee: 'Abs. justifiée',
  retard: 'Retard',
};

export default function AttendanceScreen() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [classData, setClassData] = useState<ClassData | null>(null);
  const [date, setDate] = useState(today());
  const [records, setRecords] = useState<AttendanceDay[]>(loadRecords());
  const [reportMonth, setReportMonth] = useState<string>(() => new Date().toISOString().slice(0, 7));
  const [exporting, setExporting] = useState<'excel' | 'word' | null>(null);

  useEffect(() => {
    if (id) getClass(id).then(c => setClassData(c || null));
  }, [id]);

  const students = useMemo(() => sortStudents(classData?.students || []), [classData]);
  const current = records.find(r => r.classId === id && r.date === date);

  function getStatus(studentId: string): AttendanceStatus {
    return current?.entries.find(e => e.studentId === studentId)?.status || 'present';
  }

  function getMotif(studentId: string): string {
    return current?.entries.find(e => e.studentId === studentId)?.motif || '';
  }

  function updateEntry(studentId: string, status: AttendanceStatus, motif = getMotif(studentId)) {
    if (!id) return;
    let next = [...records];
    let record = next.find(r => r.classId === id && r.date === date);
    if (!record) {
      record = { id: `att-${Date.now()}`, classId: id, date, entries: [] };
      next.unshift(record);
    }
    const idx = record.entries.findIndex(e => e.studentId === studentId);
    const entry = { studentId, status, motif };
    if (idx >= 0) record.entries[idx] = entry;
    else record.entries.push(entry);
    setRecords(next);
    saveRecords(next);
  }

  function markAllPresent() {
    students.forEach(s => updateEntry(s.id, 'present', ''));
  }

  async function handleExportExcel() {
    if (!classData || !id) return;
    const days = recordsForMonth(records, id, reportMonth);
    if (days.length === 0) { alert('Aucun jour enregistré pour ce mois. Faites d\'abord l\'appel.'); return; }
    setExporting('excel');
    try {
      await exportAttendanceExcel(classData, days, reportMonth);
    } catch (e: any) {
      alert('Erreur lors de l\'export Excel : ' + (e?.message || e));
    } finally {
      setExporting(null);
    }
  }

  async function handleExportDocx() {
    if (!classData || !id) return;
    const days = recordsForMonth(records, id, reportMonth);
    if (days.length === 0) { alert('Aucun jour enregistré pour ce mois. Faites d\'abord l\'appel.'); return; }
    setExporting('word');
    try {
      await exportAttendanceDocx(classData, days, reportMonth);
    } catch (e: any) {
      alert('Erreur lors de l\'export Word : ' + (e?.message || e));
    } finally {
      setExporting(null);
    }
  }

  const monthRecords = records.filter(r => r.classId === id && r.date.startsWith(date.slice(0, 7)));
  const totalPossible = monthRecords.length * students.length;
  const totalPresent = monthRecords.reduce((sum, r) => sum + students.filter(s => {
    const entry = r.entries.find(e => e.studentId === s.id);
    return !entry || entry.status === 'present' || entry.status === 'retard';
  }).length, 0);
  const globalRate = totalPossible ? Math.round((totalPresent / totalPossible) * 100) : 0;

  if (!classData) return <div className="p-4 text-center">Chargement...</div>;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 bg-white/20 rounded-lg"><ChevronLeft className="w-6 h-6" /></button>
          <div>
            <h1 className="font-bold text-lg">Registre de Présence</h1>
            <p className="text-emerald-100 text-sm">{classData.name} • Appel quotidien</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24">
        <div className="bg-white rounded-xl shadow p-4 mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">Date de l'appel</label>
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full p-3 border border-gray-300 rounded-lg" />
          <button onClick={markAllPresent} className="w-full mt-3 bg-emerald-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
            <UserCheck className="w-5 h-5" /> Tout le monde présent
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-white rounded-xl shadow p-4 text-center">
            <p className="text-2xl font-bold text-emerald-600">{globalRate}%</p>
            <p className="text-gray-500 text-xs">Taux mensuel global</p>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center">
            <p className="text-2xl font-bold text-blue-600">{monthRecords.length}</p>
            <p className="text-gray-500 text-xs">Jours enregistrés</p>
          </div>
        </div>

        <div className="space-y-2">
          {students.map(student => {
            const status = getStatus(student.id);
            const photo = student.photoUrl;
            return (
              <div key={student.id} className="bg-white rounded-xl shadow p-3">
                <div className="flex items-center gap-3 mb-3">
                  {photo ? <img src={photo} alt="" className="w-11 h-11 rounded-full object-cover" /> : <div className="w-11 h-11 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">{student.nom[0]}{student.prenoms?.[0] || ''}</div>}
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-800 truncate">{student.nom.toUpperCase()} {student.prenoms}</p>
                    <p className="text-gray-400 text-xs">{STATUS_LABELS[status]}</p>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-1 mb-2">
                  {(['present', 'absent_injustifiee', 'absent_justifiee', 'retard'] as AttendanceStatus[]).map(s => (
                    <button key={s} onClick={() => updateEntry(student.id, s)} className={`text-[11px] py-2 rounded-lg ${status === s ? 'bg-emerald-600 text-white' : 'bg-gray-100 text-gray-600'}`}>{STATUS_LABELS[s]}</button>
                  ))}
                </div>
                {status !== 'present' && (
                  <input value={getMotif(student.id)} onChange={e => updateEntry(student.id, status, e.target.value)} placeholder="Motif (facultatif)" className="w-full p-2 border border-gray-300 rounded-lg text-sm" />
                )}
              </div>
            );
          })}
        </div>

        <MonthlyReport
          classData={classData}
          records={records}
          month={reportMonth}
          onMonthChange={setReportMonth}
          exporting={exporting}
          onExportExcel={handleExportExcel}
          onExportWord={handleExportDocx}
        />
      </main>
    </div>
  );
}

function MonthlyReport({
  classData, records, month, onMonthChange, exporting, onExportExcel, onExportWord,
}: {
  classData: ClassData;
  records: AttendanceDay[];
  month: string;
  onMonthChange: (m: string) => void;
  exporting: 'excel' | 'word' | null;
  onExportExcel: () => void;
  onExportWord: () => void;
}) {
  const students = sortStudents(classData.students);
  const months = availableMonths(records, classData.id);
  const monthDays = recordsForMonth(records, classData.id, month);
  const classRate = computeClassAttendanceLocal(monthDays, students.map(s => s.id));
  const absTotaux = monthDays.reduce((acc, d) => {
    d.entries.forEach(e => {
      if (e.status === 'absent_injustifiee' || e.status === 'absent_justifiee') acc.push(e);
    });
    return acc;
  }, [] as AttendanceEntry[]);

  function printReport() {
    window.print();
  }

  return (
    <div className="bg-white rounded-xl shadow p-4 mt-6">
      <div className="flex items-center justify-between mb-3 print:hidden">
        <h2 className="font-bold text-gray-800 flex items-center gap-2"><FileText className="w-5 h-5" /> PV mensuel</h2>
        <button onClick={printReport} className="bg-blue-50 text-blue-700 px-3 py-2 rounded-lg text-sm">Imprimer</button>
      </div>
      <p className="text-gray-500 text-sm mb-3">Document prêt pour circonscription scolaire, EducMaster et inspection.</p>

      {/* Choix du mois + exports */}
      <div className="space-y-2 mb-4 print:hidden">
        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1">Mois du rapport</label>
          <select
            value={month}
            onChange={e => onMonthChange(e.target.value)}
            className="w-full p-2.5 border border-gray-300 rounded-lg text-sm bg-white"
          >
            {months.length === 0 && <option value={month}>{month}</option>}
            {months.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
          {months.length === 0 && (
            <p className="text-xs text-amber-600 mt-1">ℹ️ Aucun appel enregistré : le rapport sera vide tant que vous n'aurez pas fait l'appel.</p>
          )}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onExportExcel}
            disabled={exporting !== null || monthDays.length === 0}
            className="bg-emerald-600 text-white py-2.5 rounded-lg font-semibold text-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
          >
            {exporting === 'excel' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
            Registre Excel
          </button>
          <button
            onClick={onExportWord}
            disabled={exporting !== null || monthDays.length === 0}
            className="bg-[#006b4f] text-white py-2.5 rounded-lg font-semibold text-sm flex items-center justify-center gap-1.5 disabled:opacity-50"
          >
            {exporting === 'word' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
            PV Word
          </button>
        </div>
        <p className="text-[11px] text-gray-400">💡 Excel = registre d'appel (jours × élèves, P/R/A/AB) + synthèse • Word = PV officiel imprimable pour la circonscription.</p>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="bg-emerald-50 rounded-xl p-3 text-center print:bg-transparent">
          <p className="text-xl font-bold text-emerald-700">{classRate.taux}%</p>
          <p className="text-gray-500 text-[11px]">Taux moyen classe</p>
        </div>
        <div className="bg-blue-50 rounded-xl p-3 text-center print:bg-transparent">
          <p className="text-xl font-bold text-blue-700">{monthDays.length}</p>
          <p className="text-gray-500 text-[11px]">Jours suivis</p>
        </div>
        <div className="bg-amber-50 rounded-xl p-3 text-center print:bg-transparent">
          <p className="text-xl font-bold text-amber-700">{absTotaux.length}</p>
          <p className="text-gray-500 text-[11px]">Absences</p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead><tr className="bg-gray-100"><th className="p-2 text-left">Élève</th><th className="p-2">Présent</th><th className="p-2">Retard</th><th className="p-2">Abs. just.</th><th className="p-2">Abs. injust.</th><th className="p-2">Taux</th></tr></thead>
          <tbody>
            {students.map(s => {
              const st = computeClassAttendanceLocal(monthDays, [s.id]);
              const details = st.details!;
              return (
                <tr key={s.id} className="border-t">
                  <td className="p-2">{s.nom} {s.prenoms}</td>
                  <td className="p-2 text-center">{details.present}</td>
                  <td className="p-2 text-center">{details.retard}</td>
                  <td className="p-2 text-center">{details.absJust}</td>
                  <td className="p-2 text-center">{details.absInjust}</td>
                  <td className="p-2 text-center font-semibold">{st.taux}%</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="text-[11px] text-gray-400 mt-2">Mois : {month} • Total absences : {absTotaux.length}</p>
    </div>
  );
}

/** Version locale (liaison avec les types d'attendanceExport) : taux + détails d'un élève. */
function computeClassAttendanceLocal(days: AttendanceDay[], studentIds: string[]) {
  if (days.length === 0 || studentIds.length === 0) return { taux: 0, details: null };
  let sum = 0;
  let details: { present: number; retard: number; absJust: number; absInjust: number } | null = null;
  for (const sid of studentIds) {
    let present = 0, retard = 0, absJust = 0, absInjust = 0;
    for (const d of days) {
      const e = d.entries.find(x => x.studentId === sid);
      const st = e ? e.status : 'present';
      if (st === 'present') present++;
      else if (st === 'retard') retard++;
      else if (st === 'absent_justifiee') absJust++;
      else absInjust++;
    }
    sum += Math.round(((present + retard) / days.length) * 100);
    details = { present, retard, absJust, absInjust };
  }
  return { taux: Math.round(sum / studentIds.length), details };
}