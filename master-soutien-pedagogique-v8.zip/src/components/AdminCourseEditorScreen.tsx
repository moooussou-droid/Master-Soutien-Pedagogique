import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ImageUp, Plus, Save, Trash2, X } from 'lucide-react';
import { CourseLesson, CourseOffer, getVideoEmbed, loadCourses, saveCourses } from '../utils/courseMarketplace';
import { getProgrammeCourses } from '../utils/programmeData';

function readImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Image impossible à lire'));
    reader.readAsDataURL(file);
  });
}

export default function AdminCourseEditorScreen() {
  const navigate = useNavigate();
  const [customCourses, setCustomCourses] = useState<CourseOffer[]>([]);
  const [selectedId, setSelectedId] = useState('');
  const [draft, setDraft] = useState<CourseOffer | null>(null);

  useEffect(() => {
    const courses = loadCourses();
    setCustomCourses(courses);
  }, []);

  const allCourses = useMemo(() => [...getProgrammeCourses(), ...customCourses], [customCourses]);

  function selectCourse(id: string) {
    setSelectedId(id);
    const found = allCourses.find(c => c.id === id);
    setDraft(found ? JSON.parse(JSON.stringify(found)) : null);
  }

  function updateLesson(index: number, patch: Partial<CourseLesson>) {
    if (!draft) return;
    setDraft({ ...draft, lessons: draft.lessons.map((lesson, i) => i === index ? { ...lesson, ...patch } : lesson) });
  }

  async function setLessonImage(index: number, file?: File) {
    if (!file) return;
    try {
      const imageUrl = await readImage(file);
      updateLesson(index, { imageUrl });
    } catch {
      alert('Impossible de lire cette image.');
    }
  }

  function saveDraft() {
    if (!draft) return;
    const existing = customCourses.some(c => c.id === draft.id);
    const updated = { ...draft, status: 'approved' as const };
    const next = existing
      ? customCourses.map(c => c.id === draft.id ? updated : c)
      : [{ ...updated, id: `${draft.id}-custom-${Date.now()}`, createdAt: Date.now() }, ...customCourses];
    setCustomCourses(next);
    saveCourses(next);
    alert('Cours enregistré et approuvé.');
  }

  if (!draft && allCourses.length > 0 && !selectedId) {
    // avoid setState in render loop by showing selection only
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-slate-900 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/admin-dashboard')} className="p-2 bg-white/10 rounded-lg"><ChevronLeft className="w-6 h-6" /></button>
          <div><h1 className="font-bold text-lg">Éditeur administrateur des cours</h1><p className="text-slate-300 text-sm">Modifier contenus, images et vidéos YouTube/Facebook/TikTok</p></div>
        </div>
      </header>
      <main className="p-4 pb-24 max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4">
        <aside className="bg-white rounded-2xl shadow p-4 h-fit">
          <h2 className="font-bold text-gray-900 mb-3">Cours disponibles</h2>
          <div className="space-y-2 max-h-[70vh] overflow-y-auto">
            {allCourses.map(course => <button key={course.id} onClick={() => selectCourse(course.id)} className={`w-full text-left p-3 rounded-lg text-sm ${selectedId === course.id ? 'bg-emerald-600 text-white' : 'bg-gray-50 text-gray-700'}`}><span className="font-bold block truncate">{course.title}</span><span className="text-xs opacity-80">{course.level}</span></button>)}
          </div>
        </aside>
        <section className="bg-white rounded-2xl shadow p-4">
          {!draft ? (
            <p className="text-gray-500 text-center py-20">Sélectionnez un cours à modifier.</p>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Input label="Titre du cours" value={draft.title} onChange={v => setDraft({ ...draft, title: v })} />
                <Input label="Niveau" value={draft.level} onChange={v => setDraft({ ...draft, level: v })} />
                <Input label="Auteur" value={draft.author} onChange={v => setDraft({ ...draft, author: v })} />
                <Input label="Prix" value={draft.price} onChange={v => setDraft({ ...draft, price: v })} />
              </div>
              <textarea value={draft.description} onChange={e => setDraft({ ...draft, description: e.target.value })} rows={3} className="w-full p-3 border rounded-lg text-sm" placeholder="Description" />
              <h2 className="font-bold text-gray-900">Leçons</h2>
              {draft.lessons.map((lesson, index) => (
                <div key={index} className="border rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between"><p className="font-bold text-gray-800">Leçon {index + 1}</p><button onClick={() => setDraft({ ...draft, lessons: draft.lessons.filter((_, i) => i !== index) })} className="text-red-500"><Trash2 className="w-5 h-5" /></button></div>
                  <Input label="Titre" value={lesson.title} onChange={v => updateLesson(index, { title: v })} />
                  <textarea value={lesson.content} onChange={e => updateLesson(index, { content: e.target.value })} rows={8} className="w-full p-3 border rounded-lg text-sm" />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Input label="Lien image (URL)" value={lesson.imageUrl || ''} onChange={v => updateLesson(index, { imageUrl: v })} />
                    <Input label="Vidéo YouTube / Facebook / TikTok" value={lesson.videoUrl || ''} onChange={v => updateLesson(index, { videoUrl: v })} />
                  </div>
                  <label className="border border-dashed rounded-lg p-3 flex items-center gap-2 cursor-pointer text-sm text-gray-600"><ImageUp className="w-5 h-5" /> Ajouter une image depuis l’appareil<input type="file" accept="image/*" onChange={e => setLessonImage(index, e.target.files?.[0])} className="hidden" /></label>
                  {lesson.imageUrl && <img src={lesson.imageUrl} alt="Aperçu" className="w-full h-40 object-cover rounded-lg" onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />}
                  {lesson.videoUrl && getVideoEmbed(lesson.videoUrl) && <iframe src={getVideoEmbed(lesson.videoUrl)} title={lesson.title} className="w-full aspect-video rounded-lg" allowFullScreen />}
                </div>
              ))}
              <button onClick={() => setDraft({ ...draft, lessons: [...draft.lessons, { title: `Leçon ${draft.lessons.length + 1}`, content: '', imageUrl: '', videoUrl: '' }] })} className="w-full bg-gray-100 py-3 rounded-xl font-semibold"><Plus className="w-5 h-5 inline mr-1" /> Ajouter une leçon</button>
              <div className="grid grid-cols-2 gap-2"><button onClick={() => setDraft(null)} className="bg-gray-100 py-3 rounded-xl font-semibold"><X className="w-5 h-5 inline mr-1" /> Annuler</button><button onClick={saveDraft} className="bg-emerald-600 text-white py-3 rounded-xl font-semibold"><Save className="w-5 h-5 inline mr-1" /> Enregistrer</button></div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function Input({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return <div><label className="block text-sm font-medium text-gray-700 mb-1">{label}</label><input value={value} onChange={e => onChange(e.target.value)} className="w-full p-3 border rounded-lg text-sm" /></div>;
}
