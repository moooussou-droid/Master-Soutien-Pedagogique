import { useNavigate } from 'react-router-dom';
import { Award, CheckCircle2, ChevronLeft, ShieldCheck } from 'lucide-react';

function decodePayload(): any | null {
  const params = new URLSearchParams(window.location.hash.split('?')[1] || window.location.search);
  const raw = params.get('data');
  if (!raw) return null;
  try {
    return JSON.parse(decodeURIComponent(atob(raw)));
  } catch {
    return null;
  }
}

export default function VerifyBulletinScreen() {
  const navigate = useNavigate();
  const data = decodePayload();
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 bg-white/20 rounded-lg"><ChevronLeft className="w-6 h-6" /></button>
          <div><h1 className="font-bold text-lg">Vérification d'authenticité</h1><p className="text-emerald-100 text-sm">Certificat officiel du bulletin</p></div>
        </div>
      </header>
      <main className="p-4 max-w-md mx-auto">
        {!data ? (
          <div className="bg-white rounded-xl shadow p-6 text-center">
            <Award className="w-14 h-14 text-gray-300 mx-auto mb-3" />
            <p className="font-bold text-gray-800">Code invalide</p>
            <p className="text-gray-500 text-sm">Impossible de lire les informations du bulletin.</p>
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow overflow-hidden">
            <div className="bg-emerald-600 text-white p-5 text-center">
              <ShieldCheck className="w-16 h-16 mx-auto mb-2" />
              <h2 className="font-bold text-xl">Bulletin authentifié</h2>
              <p className="text-emerald-100 text-sm">Certification EducMaster MEMP</p>
            </div>
            <div className="p-5 space-y-3">
              <Row label="Code" value={data.code} />
              <Row label="Matricule" value={data.matricule} />
              <Row label="Élève" value={data.nom} />
              <Row label="Classe" value={data.classe} />
              <Row label="Moyenne" value={`${data.moyenne}/20`} />
              <Row label="Rang" value={data.rang} />
              <Row label="Matières validées" value={data.validated} />
              <Row label="Décision" value={data.decision} />
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-start gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <p className="text-emerald-800 text-sm">Les informations du bulletin correspondent au sceau numérique généré par Master Soutien Pédagogique.</p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between border-b pb-2 text-sm"><span className="text-gray-500">{label}</span><span className="font-semibold text-gray-800 text-right">{value}</span></div>;
}