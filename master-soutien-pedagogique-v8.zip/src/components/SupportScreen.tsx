import { useNavigate } from 'react-router-dom';
import {
  ChevronLeft, MessageCircle, HelpCircle, Send, Lightbulb, Bug, Phone,
} from 'lucide-react';
import { openWhatsApp, WHATSAPP_DISPLAY } from '../utils/contact';

export default function SupportScreen() {
  const navigate = useNavigate();

  const actions = [
    {
      icon: HelpCircle,
      color: 'bg-blue-100 text-blue-600',
      title: 'Aide & Questions',
      desc: 'Besoin d\'aide pour utiliser l\'application ?',
      message: 'Bonjour, j\'ai besoin d\'aide avec Master Soutien Pédagogique.',
    },
    {
      icon: Lightbulb,
      color: 'bg-amber-100 text-amber-600',
      title: 'Suggérer une amélioration',
      desc: 'Proposez une nouvelle fonctionnalité',
      message: 'Bonjour, j\'aimerais suggérer une amélioration pour l\'application : ',
    },
    {
      icon: Bug,
      color: 'bg-red-100 text-red-600',
      title: 'Signaler un problème',
      desc: 'Un bug ou une erreur à corriger ?',
      message: 'Bonjour, je rencontre un problème avec l\'application : ',
    },
    {
      icon: Send,
      color: 'bg-emerald-100 text-emerald-600',
      title: 'Formation & Accompagnement',
      desc: 'Demandez une formation personnalisée',
      message: 'Bonjour, je souhaite une formation/accompagnement pédagogique.',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 bg-white/20 rounded-lg">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-lg font-bold">Support & Contact</h1>
            <p className="text-emerald-100 text-sm">Nous sommes là pour vous aider</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24">
        {/* Carte contact principale */}
        <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl p-5 text-white text-center mb-6">
          <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
            <MessageCircle className="w-9 h-9" />
          </div>
          <h2 className="font-bold text-lg">Contactez-nous sur WhatsApp</h2>
          <p className="text-white/90 text-sm mt-1 mb-4 flex items-center justify-center gap-2">
            <Phone className="w-4 h-4" />
            {WHATSAPP_DISPLAY}
          </p>
          <button
            onClick={() => openWhatsApp('Bonjour Master Soutien Pédagogique !')}
            className="bg-white text-green-600 font-semibold px-6 py-3 rounded-xl inline-flex items-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            Démarrer une conversation
          </button>
        </div>

        {/* Actions rapides */}
        <h3 className="font-bold text-gray-800 mb-3">Comment pouvons-nous aider ?</h3>
        <div className="space-y-3">
          {actions.map((a, i) => {
            const Icon = a.icon;
            return (
              <button
                key={i}
                onClick={() => openWhatsApp(a.message)}
                className="w-full bg-white rounded-xl shadow p-4 flex items-center gap-3 text-left"
              >
                <div className={`${a.color} p-3 rounded-full shrink-0`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-800">{a.title}</h4>
                  <p className="text-gray-500 text-sm">{a.desc}</p>
                </div>
                <MessageCircle className="w-5 h-5 text-green-500 shrink-0" />
              </button>
            );
          })}
        </div>

        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-4">
          <p className="text-blue-800 text-sm">
            💬 Toutes vos demandes sont traitées via WhatsApp au <strong>{WHATSAPP_DISPLAY}</strong>.
            N'hésitez pas à nous écrire pour toute question sur l'application, les notes,
            les bulletins ou l'accompagnement pédagogique.
          </p>
        </div>
      </main>
    </div>
  );
}
