import { useState } from 'react';
import { BookOpen, Check, KeyRound, MessageCircle, ShieldCheck, Sparkles, Trash2, User } from 'lucide-react';
import { verifyAccessCode } from '../utils/license';
import { verifyLicenseOnline, isServerLicensingEnabled } from '../utils/licenseServer';
import { saveActivation } from '../utils/userProfile';
import { openWhatsApp, WHATSAPP_DISPLAY } from '../utils/contact';

interface AdminContact {
  name: string;
  role: string;
  phone: string;
}

interface Props {
  onActivated: () => void;
  onOpenAdmin: () => void;
}

export default function AccessGate({ onActivated, onOpenAdmin }: Props) {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [checking, setChecking] = useState(false);

  function getAdminContacts(): AdminContact[] {
    try {
      const raw = localStorage.getItem('msp_admin_team');
      const team = raw ? JSON.parse(raw) : [];
      const admins = team
        .filter((member: any) => member?.active !== false && member?.phone)
        .slice(0, 3)
        .map((member: any, index: number) => ({
          name: member.name || `Administrateur ${index + 1}`,
          role: member.role || 'Admin',
          phone: member.phone,
        }));
      if (admins.length > 0) return admins;
    } catch {
      // ignore invalid admin list
    }
    return [{ name: 'Administrateur principal', role: 'ADMIN 1', phone: WHATSAPP_DISPLAY }];
  }

  async function handleActivate() {
    setError('');
    if (!name.trim()) { setError('Veuillez saisir votre nom complet.'); return; }
    if (!code.trim()) { setError('Veuillez saisir votre code d\'accès.'); return; }

    setChecking(true);
    try {
      const okLocal = await verifyAccessCode(name, code);
      if (!okLocal) {
        setError('Code incorrect pour ce nom. Vérifiez l\'orthographe exacte de votre nom et votre code.');
        return;
      }

      if (isServerLicensingEnabled()) {
        try {
          const result = await verifyLicenseOnline(name, code);
          if (result === 'revoked') { setError('Ce code a été désactivé. Contactez l\'administrateur.'); return; }
          if (result === 'notfound') { setError('Ce code n\'est pas reconnu par le serveur. Contactez l\'administrateur.'); return; }
          if (result === 'mismatch') { setError('Ce code ne correspond pas à ce nom.'); return; }
        } catch {
          // mode hors-ligne : validation locale acceptée
        }
      }

      saveActivation(name, code);
      onActivated();
    } catch {
      setError('Une erreur est survenue. Réessayez.');
    } finally {
      setChecking(false);
    }
  }

  function requestCodeFromAdmin(admin: { name: string; phone: string }) {
    const digits = admin.phone.replace(/\D/g, '');
    const msg = `Bonjour ${admin.name}, je souhaite obtenir mon code d'accès personnel pour utiliser Master Soutien Pédagogique.\n\nTarif : 999 FCFA / an\nNom complet : ${name || '...'}\nÉcole : ...\nCommune / Circonscription : ...\n\nMerci de m'indiquer les conditions d'activation.`;
    window.open(`https://wa.me/${digits}?text=${encodeURIComponent(msg)}`, '_blank', 'noopener,noreferrer');
  }

  function requestCode() {
    const msg = `Bonjour, je souhaite obtenir mon code d'accès personnel pour utiliser Master Soutien Pédagogique.\n\nTarif : 999 FCFA / an\nNom complet : ${name || '...'}\nÉcole : ...\nCommune / Circonscription : ...\n\nMerci.`;
    openWhatsApp(msg);
  }

  function resetLocalApp() {
    if (!confirm("Réinitialiser les données locales de l'application sur cet appareil ?")) return;
    localStorage.clear();
    indexedDB.deleteDatabase('NoteFacileBenin');
    indexedDB.deleteDatabase('MasterSoutienResources');
    window.location.reload();
  }

  const admins = getAdminContacts();

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#f7f3e8] text-slate-950">
      <div className="absolute inset-0 opacity-[0.22] [background-image:linear-gradient(135deg,#047857_1px,transparent_1px)] [background-size:28px_28px]" />
      <div className="absolute -left-20 top-0 h-72 w-72 rounded-full bg-emerald-200 blur-3xl" />
      <div className="absolute -right-24 bottom-0 h-80 w-80 rounded-full bg-amber-200 blur-3xl" />
      <main className="relative mx-auto flex min-h-screen max-w-5xl flex-col items-center px-5 py-10">
        <section className="w-full text-center">
          <div className="mx-auto mb-8 flex h-20 w-20 items-center justify-center rounded-3xl bg-[#006b4f] text-white shadow-xl">
            <BookOpen className="h-10 w-10" />
          </div>
          <h1 className="text-4xl font-black leading-tight sm:text-6xl">
            <span className="text-[#006b4f]">Master</span>{' '}
            <span className="text-[#d4a017]">Soutien</span>{' '}
            <span className="text-[#b91c1c]">Pédagogique</span>
          </h1>
          <div className="mx-auto mt-5 inline-flex items-center gap-3 rounded-full border border-emerald-200 bg-white/80 px-5 py-2 shadow-sm">
            <span className="h-2 w-2 rounded-full bg-[#006b4f]" />
            <span className="text-sm font-black uppercase tracking-wider text-slate-700">Accompagnement & Gestion de Classe - Bénin</span>
            <span className="h-2 w-2 rounded-full bg-[#d4a017]" />
          </div>
          <h2 className="mx-auto mt-10 max-w-3xl text-3xl font-black leading-tight text-slate-900 sm:text-4xl">
            La plateforme qui simplifie la <span className="text-[#006b4f]">gestion pédagogique</span>,
            les <span className="text-[#d4a017]">notes</span> et les <span className="text-[#b91c1c]">bulletins</span>
          </h2>
          <div className="mx-auto mt-8 max-w-2xl rounded-2xl border-2 border-[#006b4f]/20 bg-white/90 p-5 shadow-sm">
            <p className="text-lg font-extrabold text-slate-800">Notes, présences, fiches APC, calendrier scolaire, bulletins et ressources dans un même espace sécurisé.</p>
          </div>
        </section>

        <section className="mt-10 w-full max-w-2xl rounded-3xl border-2 border-[#006b4f]/20 bg-white p-5 shadow-xl">
          <div className="mb-4 rounded-2xl border border-amber-200 bg-[#fff8e1] p-4">
            <div className="flex items-start gap-3">
              <Sparkles className="mt-0.5 h-5 w-5 text-[#d4a017]" />
              <div>
                <p className="font-black uppercase text-slate-900">Accès Master Soutien Pédagogique</p>
                <p className="mt-1 text-sm font-medium text-slate-700">L'accès complet requiert un code d'activation personnel : <strong>999 FCFA / an</strong>. Vos saisies et données restent conservées sur cet appareil.</p>
              </div>
            </div>
          </div>

          <div className="mb-4 rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
            <div className="mb-3 flex items-start justify-between gap-2">
              <div>
                <p className="font-black uppercase text-emerald-950">Contactez un administrateur pour activer votre abonnement</p>
                <p className="mt-1 text-sm text-slate-700">Pour obtenir votre code d'accès, contactez l'un des administrateurs par WhatsApp.</p>
              </div>
              <span className="rounded-lg bg-[#006b4f] px-3 py-1 text-xs font-black text-white">999 FCFA / an</span>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              {admins.map((admin, index) => (
                <button
                  key={`${admin.phone}-${index}`}
                  onClick={() => requestCodeFromAdmin(admin)}
                  className="rounded-xl bg-[#006b4f] p-3 text-left text-white shadow inline-flex items-center justify-between gap-2"
                >
                  <span>
                    <span className="block text-[11px] font-bold uppercase text-emerald-100">{admin.role}</span>
                    <span className="font-black">{admin.name}</span>
                  </span>
                  <MessageCircle className="h-6 w-6 rounded-full bg-white/20 p-1" />
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border bg-slate-50 p-4">
            <p className="mb-3 font-black uppercase text-slate-800">Entrez votre code d'abonnement</p>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nom complet</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                  <input value={name} onChange={e => setName(e.target.value)} placeholder="Ex: KOFFI Jean" className="w-full rounded-lg border border-gray-300 py-3 pl-10 pr-4" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Code d'accès d'activation</label>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                  <input value={code} onChange={e => setCode(e.target.value.toUpperCase())} placeholder="CODE D'ACCÈS" className="w-full rounded-lg border border-gray-300 py-3 pl-10 pr-4 text-center font-mono tracking-widest" />
                </div>
              </div>
              {error && <p className="rounded-lg border border-red-200 bg-red-50 p-2 text-sm text-red-600">{error}</p>}
              <button onClick={handleActivate} disabled={checking} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#006b4f] py-4 font-black text-white disabled:opacity-50">
                <Check className="h-5 w-5" /> {checking ? 'Vérification...' : 'Activer'}
              </button>
              <button onClick={requestCode} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#d4a017] py-3 font-bold text-slate-950">
                <MessageCircle className="h-5 w-5" /> Demander un code via WhatsApp ({WHATSAPP_DISPLAY})
              </button>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap justify-center gap-3">
            <button onClick={resetLocalApp} className="rounded-full border border-red-200 px-5 py-2 text-sm font-bold text-red-500 inline-flex items-center gap-2">
              <Trash2 className="h-4 w-4" /> Réinitialiser l'application
            </button>
            <button onClick={onOpenAdmin} className="rounded-full border border-slate-200 px-5 py-2 text-sm font-bold text-slate-500 inline-flex items-center gap-2">
              <ShieldCheck className="h-4 w-4" /> Espace administrateur
            </button>
          </div>
        </section>
      </main>
    </div>
  );
}