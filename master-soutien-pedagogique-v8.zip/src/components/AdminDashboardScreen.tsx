import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ChevronLeft, KeyRound, LogOut, MessageCircle, Plus, ShieldCheck,
  Trash2, Users, Settings, FileText, Activity, Copy, RefreshCw,
} from 'lucide-react';
import { ADMIN_PASSWORD } from '../utils/adminConfig';
import { generateAccessCode } from '../utils/license';
import { openWhatsApp } from '../utils/contact';
import ResourceFiles from './ResourceFiles';
import { ResourceCategory } from '../utils/resourcesDB';
import { loadOrientationExtras, saveOrientationExtras, OrientationDomain, OrientationExtraInfo } from '../utils/orientation';
import { CourseOffer, loadCourses, saveCourses } from '../utils/courseMarketplace';

type AdminTab = 'resources' | 'team' | 'access' | 'orientation' | 'courses' | 'governance';
type AdminRole = 'Super Administrateur' | 'Responsable Ressources' | 'Responsable Annonces' | 'Modérateur' | 'Support';

interface AdminMember {
  id: string;
  name: string;
  role: AdminRole;
  phone: string;
  email: string;
  permissions: string[];
  active: boolean;
  createdAt: number;
}

interface GeneratedCredential {
  id: string;
  owner: string;
  type: 'admin' | 'user';
  value: string;
  createdAt: number;
}

const TEAM_KEY = 'msp_admin_team';
const ADMIN_SESSION_KEY = 'msp_admin_dashboard_session';
const ADMIN_PASSWORDS_KEY = 'msp_generated_admin_passwords';

const RESOURCE_CATEGORIES: { key: ResourceCategory; label: string; accent: 'emerald' | 'red' | 'amber' | 'blue' }[] = [
  { key: 'programmes', label: 'Programmes d’études', accent: 'emerald' },
  { key: 'videos', label: 'Vidéos des cours', accent: 'red' },
  { key: 'annonces', label: 'Annonces & Recrutement', accent: 'amber' },
  { key: 'publicites', label: 'Publicités', accent: 'blue' },
];

const ROLE_PERMISSIONS: Record<AdminRole, string[]> = {
  'Super Administrateur': ['Toutes les permissions', 'Ressources', 'Annonces', 'Publicités', 'Support', 'Équipe'],
  'Responsable Ressources': ['Programmes d’études', 'Vidéos', 'Fiches pédagogiques'],
  'Responsable Annonces': ['Annonces', 'Recrutement', 'Validation des opportunités'],
  'Modérateur': ['Vérification contenus', 'Signalements', 'Qualité pédagogique'],
  'Support': ['Assistance utilisateurs', 'WhatsApp', 'Formation'],
};

function loadTeam(): AdminMember[] {
  try {
    const raw = localStorage.getItem(TEAM_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore invalid data
  }
  return [
    {
      id: 'owner',
      name: 'Administrateur principal',
      role: 'Super Administrateur',
      phone: '+22963261382',
      email: '',
      permissions: ROLE_PERMISSIONS['Super Administrateur'],
      active: true,
      createdAt: Date.now(),
    },
  ];
}

function saveTeam(team: AdminMember[]) {
  localStorage.setItem(TEAM_KEY, JSON.stringify(team));
}

function loadCredentials(): GeneratedCredential[] {
  try {
    const raw = localStorage.getItem(ADMIN_PASSWORDS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore invalid data
  }
  return [];
}

function saveCredentials(items: GeneratedCredential[]) {
  localStorage.setItem(ADMIN_PASSWORDS_KEY, JSON.stringify(items));
}

function generateStrongPassword(prefix = 'MSP-ADMIN') {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  const values = new Uint32Array(16);
  crypto.getRandomValues(values);
  let out = '';
  for (const value of values) out += chars[value % chars.length];
  return `${prefix}-${out.slice(0, 4)}-${out.slice(4, 8)}-${out.slice(8, 12)}-${out.slice(12, 16)}`;
}

export default function AdminDashboardScreen() {
  const navigate = useNavigate();
  const [unlocked, setUnlocked] = useState(localStorage.getItem(ADMIN_SESSION_KEY) === 'true');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [tab, setTab] = useState<AdminTab>('resources');
  const [resourceCategory, setResourceCategory] = useState<ResourceCategory>('programmes');
  const [team, setTeam] = useState<AdminMember[]>([]);
  const [memberName, setMemberName] = useState('');
  const [memberRole, setMemberRole] = useState<AdminRole>('Responsable Ressources');
  const [memberPhone, setMemberPhone] = useState('');
  const [memberEmail, setMemberEmail] = useState('');
  const [credentials, setCredentials] = useState<GeneratedCredential[]>([]);
  const [credentialOwner, setCredentialOwner] = useState('');
  const [credentialType, setCredentialType] = useState<'admin' | 'user'>('admin');
  const [orientationExtras, setOrientationExtras] = useState<OrientationExtraInfo[]>([]);
  const [orientationTitle, setOrientationTitle] = useState('');
  const [orientationSeries, setOrientationSeries] = useState('');
  const [orientationDomain, setOrientationDomain] = useState<OrientationDomain>('scientifique');
  const [orientationSubjects, setOrientationSubjects] = useState('');
  const [orientationStudies, setOrientationStudies] = useState('');
  const [orientationCareers, setOrientationCareers] = useState('');
  const [orientationAdvice, setOrientationAdvice] = useState('');
  const [courses, setCourses] = useState<CourseOffer[]>([]);

  useEffect(() => {
    setTeam(loadTeam());
    setCredentials(loadCredentials());
    setOrientationExtras(loadOrientationExtras());
    setCourses(loadCourses());
  }, []);

  function login() {
    if (password === ADMIN_PASSWORD) {
      localStorage.setItem(ADMIN_SESSION_KEY, 'true');
      setUnlocked(true);
      setError('');
    } else {
      setError('Mot de passe administrateur incorrect.');
    }
  }

  function logout() {
    localStorage.removeItem(ADMIN_SESSION_KEY);
    setUnlocked(false);
    setPassword('');
  }

  function persistTeam(next: AdminMember[]) {
    setTeam(next);
    saveTeam(next);
  }

  function addMember() {
    if (!memberName.trim()) {
      alert('Saisissez le nom du membre.');
      return;
    }
    const member: AdminMember = {
      id: `admin-${Date.now()}`,
      name: memberName.trim(),
      role: memberRole,
      phone: memberPhone.trim(),
      email: memberEmail.trim(),
      permissions: ROLE_PERMISSIONS[memberRole],
      active: true,
      createdAt: Date.now(),
    };
    persistTeam([member, ...team]);
    setMemberName('');
    setMemberPhone('');
    setMemberEmail('');
  }

  function toggleMember(id: string) {
    persistTeam(team.map(m => m.id === id ? { ...m, active: !m.active } : m));
  }

  function deleteMember(id: string) {
    if (id === 'owner') return alert('Le compte administrateur principal ne peut pas être supprimé.');
    if (!confirm('Retirer ce membre de l’équipe d’administration ?')) return;
    persistTeam(team.filter(m => m.id !== id));
  }

  function inviteMember(member: AdminMember) {
    const msg = `Bonjour ${member.name},\nVous êtes ajouté(e) à l'équipe d'administration de Master Soutien Pédagogique.\nRôle : ${member.role}\nPermissions : ${member.permissions.join(', ')}\nMerci de contacter l'administrateur principal pour les consignes d'accès.`;
    openWhatsApp(msg);
  }

  function persistCredentials(next: GeneratedCredential[]) {
    setCredentials(next);
    saveCredentials(next);
  }

  async function generateCredential() {
    if (!credentialOwner.trim()) {
      alert('Saisissez le nom du titulaire.');
      return;
    }
    const value = credentialType === 'admin'
      ? generateStrongPassword('MSP-ADMIN')
      : await generateAccessCode(credentialOwner);
    const item: GeneratedCredential = {
      id: `cred-${Date.now()}`,
      owner: credentialOwner.trim(),
      type: credentialType,
      value,
      createdAt: Date.now(),
    };
    persistCredentials([item, ...credentials]);
  }

  async function copyCredential(value: string) {
    await navigator.clipboard?.writeText(value);
    alert('Copié.');
  }

  function persistOrientation(items: OrientationExtraInfo[]) {
    setOrientationExtras(items);
    saveOrientationExtras(items);
  }

  function addOrientationInfo() {
    if (!orientationTitle.trim()) return alert('Ajoutez un titre.');
    const item: OrientationExtraInfo = {
      id: `ori-extra-${Date.now()}`,
      title: orientationTitle.trim(),
      series: orientationSeries.trim(),
      domains: [orientationDomain],
      subjects: orientationSubjects.trim(),
      studies: orientationStudies.trim(),
      careers: orientationCareers.trim(),
      advice: orientationAdvice.trim(),
      createdAt: Date.now(),
    };
    persistOrientation([item, ...orientationExtras]);
    setOrientationTitle('');
    setOrientationSeries('');
    setOrientationSubjects('');
    setOrientationStudies('');
    setOrientationCareers('');
    setOrientationAdvice('');
  }

  function persistCourses(next: CourseOffer[]) {
    setCourses(next);
    saveCourses(next);
  }

  function setCourseStatus(id: string, status: CourseOffer['status']) {
    persistCourses(courses.map(course => course.id === id ? { ...course, status } : course));
  }

  if (!unlocked) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-5 w-full max-w-sm">
          <div className="text-center mb-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto mb-3">
              <ShieldCheck className="w-9 h-9" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">Espace Administrateur</h1>
            <p className="text-gray-500 text-sm">Gestion globale de l’application</p>
          </div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Mot de passe administrateur</label>
          <div className="relative mb-2">
            <KeyRound className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && login()}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg"
              placeholder="Mot de passe"
            />
          </div>
          {error && <p className="text-red-600 text-sm mb-2">{error}</p>}
          <button onClick={login} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold">Entrer</button>
          <button onClick={() => navigate('/')} className="w-full text-gray-500 text-sm mt-3">Retour à l’accueil</button>
        </div>
      </div>
    );
  }

  const activeMembers = team.filter(m => m.active).length;
  const selectedCategory = RESOURCE_CATEGORIES.find(c => c.key === resourceCategory) || RESOURCE_CATEGORIES[0];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-slate-900 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/')} className="p-2 bg-white/10 rounded-lg"><ChevronLeft className="w-6 h-6" /></button>
            <div>
              <h1 className="font-bold text-lg">Espace Administrateur</h1>
              <p className="text-slate-300 text-sm">Ressources, équipe et gouvernance de l’application</p>
            </div>
          </div>
          <button onClick={logout} className="bg-red-500/20 text-red-100 px-3 py-2 rounded-lg inline-flex items-center gap-2 text-sm font-semibold">
            <LogOut className="w-4 h-4" /> Quitter
          </button>
        </div>
      </header>

      <main className="p-4 pb-24 max-w-5xl mx-auto">
        <div className="grid grid-cols-3 gap-2 mb-4">
          <Stat icon={FileText} value={RESOURCE_CATEGORIES.length} label="Sections ressources" />
          <Stat icon={Users} value={team.length} label="Membres équipe" />
          <Stat icon={Activity} value={activeMembers} label="Actifs" />
        </div>

        <div className="grid grid-cols-6 gap-2 mb-4">
          <TabButton active={tab === 'resources'} onClick={() => setTab('resources')} icon={FileText} label="Ressources" />
          <TabButton active={tab === 'team'} onClick={() => setTab('team')} icon={Users} label="Équipe" />
          <TabButton active={tab === 'access'} onClick={() => setTab('access')} icon={KeyRound} label="Accès" />
          <TabButton active={tab === 'orientation'} onClick={() => setTab('orientation')} icon={ShieldCheck} label="Orientation" />
          <TabButton active={tab === 'courses'} onClick={() => setTab('courses')} icon={Activity} label="Cours" />
          <TabButton active={tab === 'governance'} onClick={() => setTab('governance')} icon={Settings} label="Gouvernance" />
        </div>

        {tab === 'resources' && (
          <section className="bg-white rounded-2xl shadow p-4">
            <h2 className="font-bold text-gray-900 text-lg mb-1">Gestion administrateur des ressources</h2>
            <p className="text-gray-500 text-sm mb-4">Ajoutez les contenus officiels visibles par les enseignants.</p>
            <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
              {RESOURCE_CATEGORIES.map(cat => (
                <button
                  key={cat.key}
                  onClick={() => setResourceCategory(cat.key)}
                  className={`whitespace-nowrap px-4 py-2 rounded-lg text-sm font-semibold ${resourceCategory === cat.key ? 'bg-emerald-600 text-white' : 'bg-gray-100 text-gray-600'}`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
            <ResourceFiles category={selectedCategory.key} accent={selectedCategory.accent} forceAdmin />
          </section>
        )}

        {tab === 'team' && (
          <section className="space-y-4">
            <div className="bg-white rounded-2xl shadow p-4">
              <h2 className="font-bold text-gray-900 text-lg mb-3">Ajouter un membre de l’équipe</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Input label="Nom" value={memberName} onChange={setMemberName} placeholder="Nom du membre" />
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Rôle</label>
                  <select value={memberRole} onChange={e => setMemberRole(e.target.value as AdminRole)} className="w-full p-3 border rounded-lg">
                    {Object.keys(ROLE_PERMISSIONS).map(role => <option key={role} value={role}>{role}</option>)}
                  </select>
                </div>
                <Input label="WhatsApp / Téléphone" value={memberPhone} onChange={setMemberPhone} placeholder="+229..." />
                <Input label="Email" value={memberEmail} onChange={setMemberEmail} placeholder="email@exemple.com" />
              </div>
              <button onClick={addMember} className="w-full mt-3 bg-emerald-600 text-white py-3 rounded-xl font-semibold inline-flex items-center justify-center gap-2">
                <Plus className="w-5 h-5" /> Ajouter à l’équipe
              </button>
            </div>

            <div className="space-y-2">
              {team.map(member => (
                <div key={member.id} className="bg-white rounded-xl shadow p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-bold text-gray-900">{member.name}</p>
                      <p className="text-sm text-emerald-700 font-semibold">{member.role}</p>
                      <p className="text-xs text-gray-500">{member.phone || 'Téléphone non renseigné'} {member.email ? `• ${member.email}` : ''}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded ${member.active ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>{member.active ? 'Actif' : 'Suspendu'}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-3">
                    {member.permissions.map(permission => <span key={permission} className="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded">{permission}</span>)}
                  </div>
                  <div className="grid grid-cols-3 gap-2 mt-3">
                    <button onClick={() => inviteMember(member)} className="bg-green-50 text-green-700 py-2 rounded-lg text-sm font-semibold inline-flex items-center justify-center gap-1"><MessageCircle className="w-4 h-4" /> Inviter</button>
                    <button onClick={() => toggleMember(member.id)} className="bg-amber-50 text-amber-700 py-2 rounded-lg text-sm font-semibold">{member.active ? 'Suspendre' : 'Activer'}</button>
                    <button onClick={() => deleteMember(member.id)} className="bg-red-50 text-red-600 py-2 rounded-lg text-sm font-semibold inline-flex items-center justify-center gap-1"><Trash2 className="w-4 h-4" /> Retirer</button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {tab === 'access' && (
          <section className="space-y-4">
            <div className="bg-white rounded-2xl shadow p-4">
              <h2 className="font-bold text-gray-900 text-lg mb-1">Générateur de mots de passe et codes</h2>
              <p className="text-gray-500 text-sm mb-4">
                Générez votre mot de passe administrateur, ceux des autres administrateurs ou les codes d’accès utilisateurs.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <Input label="Titulaire" value={credentialOwner} onChange={setCredentialOwner} placeholder="Nom complet" />
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                  <select value={credentialType} onChange={e => setCredentialType(e.target.value as 'admin' | 'user')} className="w-full p-3 border rounded-lg text-sm">
                    <option value="admin">Mot de passe administrateur</option>
                    <option value="user">Code utilisateur</option>
                  </select>
                </div>
                <button onClick={generateCredential} className="bg-emerald-600 text-white py-3 rounded-xl font-semibold self-end inline-flex items-center justify-center gap-2">
                  <RefreshCw className="w-5 h-5" /> Générer
                </button>
              </div>
              <div className="mt-4 bg-amber-50 border border-amber-200 rounded-xl p-3">
                <p className="text-amber-800 text-xs">
                  Important : un mot de passe administrateur généré ici doit être communiqué au membre concerné. Pour remplacer le mot de passe principal de l’application, modifiez aussi ADMIN_PASSWORD dans adminConfig.ts avant redéploiement.
                </p>
              </div>
            </div>

            <div className="space-y-2">
              {credentials.length === 0 ? (
                <div className="bg-white rounded-xl border border-dashed border-gray-300 p-6 text-center text-gray-500 text-sm">Aucun code généré.</div>
              ) : credentials.map(item => (
                <div key={item.id} className="bg-white rounded-xl shadow p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-bold text-gray-900">{item.owner}</p>
                      <p className="text-xs text-gray-500">{item.type === 'admin' ? 'Mot de passe administrateur' : 'Code utilisateur'}</p>
                      <p className="font-mono text-sm text-emerald-700 font-bold break-all mt-2">{item.value}</p>
                    </div>
                    <div className="flex gap-1">
                      <button onClick={() => copyCredential(item.value)} className="p-2 bg-blue-50 text-blue-700 rounded-lg" title="Copier"><Copy className="w-5 h-5" /></button>
                      <button onClick={() => persistCredentials(credentials.filter(c => c.id !== item.id))} className="p-2 bg-red-50 text-red-600 rounded-lg" title="Supprimer"><Trash2 className="w-5 h-5" /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {tab === 'orientation' && (
          <section className="space-y-4">
            <div className="bg-white rounded-2xl shadow p-4">
              <h2 className="font-bold text-gray-900 text-lg mb-1">Ajouter une information d’orientation</h2>
              <p className="text-gray-500 text-sm mb-4">Ces informations enrichissent la fonction Orientation scolaire visible par les enseignants.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Input label="Titre" value={orientationTitle} onChange={setOrientationTitle} placeholder="Ex: Nouveaux débouchés IA et cybersécurité" />
                <Input label="Séries concernées" value={orientationSeries} onChange={setOrientationSeries} placeholder="Ex: C, D, E, DT/IMI" />
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Domaine</label>
                  <select value={orientationDomain} onChange={e => setOrientationDomain(e.target.value as OrientationDomain)} className="w-full p-3 border rounded-lg text-sm">
                    <option value="scientifique">Scientifique</option>
                    <option value="litteraire">Littéraire</option>
                    <option value="economique">Économique</option>
                    <option value="technique">Technique</option>
                    <option value="social">Social</option>
                    <option value="culturel">Culturel</option>
                    <option value="general">Général</option>
                  </select>
                </div>
                <Input label="Matières à renforcer" value={orientationSubjects} onChange={setOrientationSubjects} placeholder="Mathématiques, PCT, Anglais..." />
                <Input label="Études possibles" value={orientationStudies} onChange={setOrientationStudies} placeholder="Génie logiciel, Data, IA..." />
                <Input label="Débouchés" value={orientationCareers} onChange={setOrientationCareers} placeholder="Développeur, analyste, ingénieur..." />
              </div>
              <div className="mt-3">
                <label className="block text-sm font-medium text-gray-700 mb-1">Conseil / commentaire</label>
                <textarea value={orientationAdvice} onChange={e => setOrientationAdvice(e.target.value)} rows={3} className="w-full p-3 border rounded-lg text-sm resize-none" />
              </div>
              <button onClick={addOrientationInfo} className="w-full mt-3 bg-emerald-600 text-white py-3 rounded-xl font-semibold">Ajouter l’information</button>
            </div>
            <div className="space-y-2">
              {orientationExtras.length === 0 ? <div className="bg-white rounded-xl border border-dashed border-gray-300 p-6 text-center text-gray-500 text-sm">Aucune information ajoutée.</div> : orientationExtras.map(item => (
                <div key={item.id} className="bg-white rounded-xl shadow p-4 flex items-start justify-between gap-3">
                  <div>
                    <p className="font-bold text-gray-900">{item.title}</p>
                    <p className="text-xs text-gray-500">Séries : {item.series} • Domaine : {item.domains.join(', ')}</p>
                    <p className="text-sm text-gray-700 mt-1">{item.advice}</p>
                  </div>
                  <button onClick={() => persistOrientation(orientationExtras.filter(x => x.id !== item.id))} className="p-2 bg-red-50 text-red-600 rounded-lg"><Trash2 className="w-5 h-5" /></button>
                </div>
              ))}
            </div>
          </section>
        )}

        {tab === 'courses' && (
          <section className="space-y-4">
            <div className="bg-white rounded-2xl shadow p-4">
              <h2 className="font-bold text-gray-900 text-lg mb-1">Approbation des cours en ligne</h2>
              <p className="text-gray-500 text-sm">Seuls les cours approuvés par l’administration sont visibles par les utilisateurs.</p>
              <Link to="/admin-cours" className="mt-3 inline-flex w-full items-center justify-center rounded-xl bg-emerald-600 py-3 font-semibold text-white">
                Modifier les contenus, images et vidéos des cours
              </Link>
            </div>
            {courses.length === 0 ? (
              <div className="bg-white rounded-xl border border-dashed border-gray-300 p-6 text-center text-gray-500 text-sm">Aucun cours proposé.</div>
            ) : courses.map(course => (
              <div key={course.id} className="bg-white rounded-xl shadow p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-bold text-gray-900">{course.title}</p>
                    <p className="text-xs text-gray-500">{course.author || 'Auteur non précisé'} • {course.level} • {course.type === 'gratuit' ? 'Gratuit' : `${course.price} FCFA`}</p>
                    <p className="text-sm text-gray-600 mt-2">{course.description}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded font-bold ${course.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : course.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>{course.status === 'approved' ? 'Approuvé' : course.status === 'rejected' ? 'Rejeté' : 'En attente'}</span>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-3">
                  <button onClick={() => setCourseStatus(course.id, 'approved')} className="bg-emerald-600 text-white py-2 rounded-lg font-semibold">Approuver</button>
                  <button onClick={() => setCourseStatus(course.id, 'rejected')} className="bg-red-50 text-red-600 py-2 rounded-lg font-semibold">Rejeter</button>
                  <button onClick={() => persistCourses(courses.filter(c => c.id !== course.id))} className="bg-gray-100 text-gray-700 py-2 rounded-lg font-semibold">Supprimer</button>
                </div>
              </div>
            ))}
          </section>
        )}

        {tab === 'governance' && (
          <section className="bg-white rounded-2xl shadow p-4 space-y-4">
            <h2 className="font-bold text-gray-900 text-lg">Règles de gouvernance</h2>
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
              <p className="font-semibold text-emerald-800">Ce que l’équipe d’administration dirige</p>
              <ul className="text-emerald-700 text-sm mt-2 list-disc list-inside space-y-1">
                <li>Validation et ajout des programmes d’études.</li>
                <li>Publication des vidéos pédagogiques utiles.</li>
                <li>Contrôle des annonces et opportunités de recrutement.</li>
                <li>Gestion des publicités et partenaires.</li>
                <li>Assistance aux utilisateurs et formation via WhatsApp.</li>
              </ul>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <p className="font-semibold text-amber-800">Recommandation</p>
              <p className="text-amber-700 text-sm mt-1">Nommez au moins un responsable pour les ressources, un responsable annonces/recrutement et un support utilisateur afin de répartir la charge.</p>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}

function Stat({ icon: Icon, value, label }: { icon: typeof Users; value: number; label: string }) {
  return (
    <div className="bg-white rounded-xl shadow p-3 text-center">
      <Icon className="w-5 h-5 mx-auto text-emerald-600 mb-1" />
      <p className="text-xl font-bold text-gray-900">{value}</p>
      <p className="text-xs text-gray-500">{label}</p>
    </div>
  );
}

function TabButton({ active, onClick, icon: Icon, label }: { active: boolean; onClick: () => void; icon: typeof Users; label: string }) {
  return (
    <button onClick={onClick} className={`rounded-xl p-3 text-sm font-semibold flex flex-col items-center gap-1 ${active ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 border'}`}>
      <Icon className="w-5 h-5" />
      {label}
    </button>
  );
}

function Input({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="w-full p-3 border rounded-lg text-sm" />
    </div>
  );
}