import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Clock, Sparkles } from 'lucide-react';

export default function ComingSoonScreen({ title }: { title: string }) {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 shadow sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 bg-white/20 rounded-lg">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="font-bold text-lg">{title}</h1>
            <p className="text-emerald-100 text-sm">Fonctionnalité en préparation</p>
          </div>
        </div>
      </header>

      <main className="p-5 flex items-center justify-center min-h-[70vh]">
        <div className="bg-white rounded-3xl shadow-xl p-6 max-w-md text-center border border-amber-200">
          <div className="mx-auto w-20 h-20 rounded-3xl bg-amber-100 text-amber-600 flex items-center justify-center mb-4">
            <Clock className="w-10 h-10" />
          </div>
          <p className="inline-flex items-center gap-2 bg-amber-50 text-amber-700 px-4 py-2 rounded-full font-black text-sm mb-4">
            <Sparkles className="w-4 h-4" /> A VENIR
          </p>
          <h2 className="text-2xl font-black text-gray-900 mb-2">{title}</h2>
          <p className="text-gray-600 text-sm">
            Cette section n’est pas encore disponible. Elle sera activée après finalisation du développement et validation pédagogique.
          </p>
          <button
            onClick={() => navigate('/')}
            className="mt-5 w-full bg-emerald-600 text-white py-3 rounded-xl font-bold"
          >
            Retour au tableau de bord
          </button>
        </div>
      </main>
    </div>
  );
}
