import { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { CheckCircle2, HelpCircle, X } from 'lucide-react';

interface GuideContent {
  id: string;
  title: string;
  intro: string;
  steps: string[];
  tip?: string;
}

const GUIDES: { match: (path: string) => boolean; content: GuideContent }[] = [
  {
    match: path => path === '/',
    content: {
      id: 'home-dashboard',
      title: 'Guide du tableau de bord enseignant',
      intro: 'Cet écran centralise vos classes, raccourcis et outils importants.',
      steps: [
        'Commencez par créer une classe ou ouvrir une classe existante.',
        'Utilisez les raccourcis du tableau de bord pour aller vite : Notes, Bulletins, Présences, Calendrier, etc.',
        'Sur chaque classe, vérifiez la progression de saisie avant d’exporter vers EducMaster.',
        'Faites régulièrement une sauvegarde ZIP ou JSON pour protéger vos données.',
      ],
      tip: 'Conseil : commencez toujours par importer ou ajouter les élèves avant la saisie des notes.',
    },
  },
  {
    match: path => path === '/class/new' || path.includes('/edit'),
    content: {
      id: 'class-form',
      title: 'Créer ou modifier une classe',
      intro: 'Cette section permet de préparer l’environnement de travail de la classe.',
      steps: [
        'Renseignez le nom de la classe et le nom de l’école.',
        'Choisissez Préscolaire, Primaire ou Secondaire.',
        'Au préscolaire et au primaire, renseignez la circonscription si elle existe.',
        'Au secondaire, choisissez le niveau et la série si nécessaire.',
        'Sélectionnez le type d’évaluation : Evaluation, Devoirs surveillés ou Interrogation écrite.',
      ],
      tip: 'Les matières sont générées automatiquement, mais vous pouvez ensuite les réorganiser dans la section Matières.',
    },
  },
  {
    match: path => path.includes('/students'),
    content: {
      id: 'students',
      title: 'Gestion des élèves',
      intro: 'Ajoutez, modifiez ou importez les élèves de la classe.',
      steps: [
        'Cliquez sur + pour ajouter un élève manuellement.',
        'Vous pouvez ajouter une photo, le poids et la taille pour le suivi santé.',
        'Utilisez Importer depuis Excel pour récupérer une liste existante.',
        'Si un fichier Excel contient déjà des notes, elles seront aussi détectées.',
        'Vérifiez les matricules avant de commencer les notes.',
      ],
      tip: 'Les matricules sont conservés en texte pour éviter la perte des zéros initiaux.',
    },
  },
  {
    match: path => path.includes('/subjects'),
    content: {
      id: 'subjects',
      title: 'Organisation des matières',
      intro: 'Cette section vous permet d’adapter l’ordre de saisie des matières.',
      steps: [
        'Modifiez le nom ou le barème si nécessaire.',
        'Utilisez les flèches pour placer les matières dans l’ordre qui vous arrange.',
        'Au primaire, gardez CM /18 et CP /2.',
        'Au secondaire, renseignez le coefficient de chaque matière.',
        'Cliquez sur Enregistrer avant de quitter.',
      ],
      tip: 'Même si vous changez l’ordre de saisie, l’export Excel respecte l’ordre normal EducMaster.',
    },
  },
  {
    match: path => path.includes('/profiles'),
    content: {
      id: 'profiles-entry',
      title: 'Saisie par profil d’élève',
      intro: 'Idéal pour saisir toutes les matières d’un élève sur une même fiche.',
      steps: [
        'Sélectionnez un élève dans la liste.',
        'Renseignez les notes matière par matière.',
        'Utilisez Absent si l’élève n’a pas composé dans une matière.',
        'Cliquez sur Enregistrer les notes.',
        'Passez à l’élève suivant avec le bouton Suivant.',
      ],
      tip: 'Cette méthode est conseillée quand vous travaillez élève par élève.',
    },
  },
  {
    match: path => path.includes('/entry'),
    content: {
      id: 'grade-entry',
      title: 'Saisie des notes par matière',
      intro: 'Cette section sert à saisir les notes d’une matière pour tous les élèves.',
      steps: [
        'Choisissez une matière.',
        'Touchez le champ CM ou CP à remplir.',
        'Utilisez le pavé numérique, y compris la virgule pour les notes décimales.',
        'Marquez Absent si nécessaire.',
        'Utilisez Suivant pour passer à l’élève suivant.',
      ],
      tip: 'Activez F2 ou Ctrl+K pour saisir rapidement au clavier.',
    },
  },
  {
    match: path => path.includes('/export'),
    content: {
      id: 'export-excel',
      title: 'Exporter vers Excel EducMaster',
      intro: 'Générez le fichier Excel final à importer sur educmaster.bj.',
      steps: [
        'Vérifiez le taux de complétion des notes.',
        'Assurez-vous que les élèves et les matières sont corrects.',
        'Cliquez sur Télécharger le fichier Excel.',
        'Sur téléphone, choisissez Enregistrer dans Fichiers si une fenêtre de partage apparaît.',
        'Importez ensuite le fichier sur educmaster.bj.',
      ],
      tip: 'L’application garde les matricules en texte et respecte les colonnes EducMaster.',
    },
  },
  {
    match: path => path.includes('/bulletins'),
    content: {
      id: 'bulletins',
      title: 'Bulletins scolaires',
      intro: 'Consultez, imprimez ou partagez les bulletins des élèves.',
      steps: [
        'Sélectionnez un élève dans la liste des bulletins.',
        'Vérifiez les notes, la moyenne, le rang et le seuil de réussite.',
        'Ajoutez le logo de l’école dans Mon espace si nécessaire.',
        'Utilisez Imprimer/PDF pour produire un bulletin papier.',
        'Le QR code permet de vérifier l’authenticité du bulletin.',
      ],
      tip: 'Au primaire, le seuil de réussite est atteint à partir de 6 matières validées.',
    },
  },
  {
    match: path => path.includes('/presences'),
    content: {
      id: 'attendance',
      title: 'Registre de présence',
      intro: 'Faites l’appel quotidien et suivez les absences.',
      steps: [
        'Choisissez la date de l’appel.',
        'Cliquez sur Tout le monde présent si toute la classe est là.',
        'Changez le statut d’un élève si nécessaire : absent, justifié, retard.',
        'Ajoutez un motif en cas d’absence ou retard.',
        'Consultez le PV mensuel pour l’inspection ou la circonscription.',
      ],
      tip: 'Utilisez ce module régulièrement pour obtenir un taux de fréquentation fiable.',
    },
  },
  {
    match: path => path.includes('/programme'),
    content: {
      id: 'class-programme',
      title: 'Programme d’études de la classe',
      intro: 'Ajoutez et consultez le programme officiel correspondant à cette classe.',
      steps: [
        'Les utilisateurs peuvent lire les documents déjà ajoutés.',
        'L’ajout et la suppression sont réservés aux administrateurs.',
        'Les formats acceptés sont PDF, DOC et DOCX.',
        'Cliquez sur Voir pour lire le document dans l’application.',
      ],
      tip: 'Le format PDF offre le meilleur affichage dans l’application.',
    },
  },
  {
    match: path => path.includes('/planification-annuelle'),
    content: {
      id: 'annual-planning',
      title: 'Planification annuelle des apprentissages',
      intro: 'Conservez la planification annuelle de chaque classe dans l’application.',
      steps: [
        'Choisissez la classe concernée.',
        'Ajoutez la planification annuelle en PDF, DOC ou DOCX si vous êtes administrateur.',
        'Les enseignants peuvent consulter le document intégré.',
        'Le document peut servir à préparer les séquences et évaluations.',
      ],
      tip: 'Ajoutez une planification claire et validée par l’équipe pédagogique.',
    },
  },
  {
    match: path => path === '/enrolement-eleves',
    content: {
      id: 'enrollment',
      title: 'Enrôlement intelligent des élèves',
      intro: 'Saisissez les informations administratives sans ouvrir Excel.',
      steps: [
        'Cliquez sur Nouvel élève.',
        'Renseignez nom, prénoms, classe, date et lieu de naissance.',
        'Ajoutez téléphone des parents, nationalité et NPI.',
        'Filtrez par classe pour vérifier les données.',
        'Cliquez sur Exporter Excel pour générer le fichier final.',
      ],
      tip: 'Le fichier exporté contient les onglets Maternelle 1, Maternelle 2, CI, CP, CE1, CE2, CM1 et CM2.',
    },
  },
  {
    match: path => path === '/calendrier-scolaire',
    content: {
      id: 'calendar',
      title: 'Calendrier scolaire',
      intro: 'Centralisez les dates importantes de l’année scolaire.',
      steps: [
        'Ajoutez les dates d’examens, congés, conseils et activités.',
        'Importez un calendrier existant en PDF, DOCX, XLSX, CSV ou TXT.',
        'Activez les notifications pour les rappels.',
        'Exportez en CSV ou imprimez en PDF si besoin.',
      ],
      tip: 'Les fichiers importés sont aussi conservés comme ressources du calendrier.',
    },
  },
  {
    match: path => path === '/grands-rendez-vous',
    content: {
      id: 'events',
      title: 'Grands rendez-vous et activités',
      intro: 'Planifiez concours, réunions APE, formations et événements scolaires.',
      steps: [
        'Cliquez sur Programmer un Rendez-vous.',
        'Renseignez date, heure, lieu, organisateur et description.',
        'Choisissez Public, Privé ou Sur invitation.',
        'Partagez l’invitation par WhatsApp.',
        'Suivez le décompte J- avant l’événement.',
      ],
      tip: 'Vous pouvez importer un programme d’activités et laisser l’application détecter les dates.',
    },
  },
  {
    match: path => path === '/correspondance',
    content: {
      id: 'correspondence',
      title: 'Carnet de correspondance',
      intro: 'Générez rapidement des avis aux parents.',
      steps: [
        'Choisissez un modèle de message.',
        'Renseignez le parent, l’élève, la classe et la date.',
        'Vérifiez l’aperçu et le coupon réponse.',
        'Copiez, imprimez ou sauvegardez le message.',
      ],
      tip: 'Les modèles respectent les usages scolaires courants.',
    },
  },
  {
    match: path => path === '/boite-outils',
    content: {
      id: 'toolkit',
      title: 'Boîte à outils enseignant',
      intro: 'Des outils simples pour gagner du temps en classe.',
      steps: [
        'Utilisez Groupes pour former des équipes de travail.',
        'Utilisez Notes pour convertir un barème vers /20.',
        'Utilisez Appréciations pour copier rapidement des commentaires.',
        'Utilisez Matériel pour suivre les fournitures.',
        'Utilisez Âge pour calculer l’âge scolaire d’un élève.',
      ],
      tip: 'Cette section aide à résoudre des problèmes pratiques du quotidien.',
    },
  },
  {
    match: path => path === '/orientation-scolaire' || path === '/orientation-post-bac',
    content: {
      id: 'orientation',
      title: 'Orientation scolaire et universitaire',
      intro: 'Aidez les élèves à choisir un parcours selon leurs performances et leurs aspirations.',
      steps: [
        'Sélectionnez l’élève ou la série du BAC concernée.',
        'Analysez les matières fortes et les domaines dominants.',
        'Consultez les filières possibles et métiers associés.',
        'Copiez la synthèse pour la partager avec l’élève ou ses parents.',
      ],
      tip: 'L’orientation doit combiner résultats, motivation, contexte familial et possibilités réelles de formation.',
    },
  },
  {
    match: path => path === '/settings' || path === '/cloud' || path === '/profile',
    content: {
      id: 'settings-profile-cloud',
      title: 'Paramètres, profil et sauvegardes',
      intro: 'Configurez l’application et protégez vos données.',
      steps: [
        'Dans Profil, ajoutez votre nom, école et logo.',
        'Dans Paramètres, sauvegardez régulièrement vos données.',
        'Activez le cloud chiffré si vous voulez transférer vers un autre appareil.',
        'Gardez une copie JSON ou ZIP en lieu sûr.',
      ],
      tip: 'La sauvegarde est indispensable avant tout changement de téléphone.',
    },
  },
];

function getGuide(path: string): GuideContent | null {
  return GUIDES.find(item => item.match(path))?.content ?? null;
}

export default function SectionGuide() {
  const location = useLocation();
  const guide = useMemo(() => getGuide(location.pathname), [location.pathname]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!guide) return;
    const hidden = localStorage.getItem(`msp_guide_hidden_${guide.id}`) === 'true';
    setOpen(!hidden);
  }, [guide?.id, location.pathname]);

  if (!guide || !open) return null;

  function hideForever() {
    if (!guide) return;
    localStorage.setItem(`msp_guide_hidden_${guide.id}`, 'true');
    setOpen(false);
  }

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[88vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white shadow-2xl">
        <div className="bg-emerald-600 p-4 text-white">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="rounded-xl bg-white/20 p-2">
                <HelpCircle className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wide text-emerald-100">Guide rapide</p>
                <h2 className="text-lg font-bold">{guide.title}</h2>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="rounded-lg bg-white/20 p-2">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        <div className="p-4">
          <p className="mb-4 text-sm text-gray-600">{guide.intro}</p>
          <div className="space-y-2">
            {guide.steps.map((step, index) => (
              <div key={step} className="flex items-start gap-3 rounded-lg bg-emerald-50 p-3">
                <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
                <p className="text-sm text-gray-700"><strong>{index + 1}.</strong> {step}</p>
              </div>
            ))}
          </div>
          {guide.tip && (
            <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3">
              <p className="text-sm text-amber-800"><strong>Astuce :</strong> {guide.tip}</p>
            </div>
          )}
          <div className="mt-5 grid grid-cols-2 gap-2">
            <button onClick={hideForever} className="rounded-xl bg-gray-100 px-3 py-3 text-sm font-semibold text-gray-700">Ne plus afficher</button>
            <button onClick={() => setOpen(false)} className="rounded-xl bg-emerald-600 px-3 py-3 text-sm font-semibold text-white">J’ai compris</button>
          </div>
        </div>
      </div>
    </div>
  );
}
