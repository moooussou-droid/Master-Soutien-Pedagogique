import { AISettings, getAISettings } from './aiLessonGenerator';
import { illustrate } from './svgIllustration';

export type ConceptAIProvider = 'local' | 'openai' | 'copilot' | 'anthropic' | 'gemini';

export interface ConceptExplanation {
  provider: ConceptAIProvider;
  title: string;
  text: string;
  simpleSummary: string;
  imageUrl: string;
  videoUrls: string[];
}

export interface ConceptInput {
  notion: string;
  discipline: string;
  level: string;
  currentContent: string;
}

const providerLabel: Record<ConceptAIProvider, string> = {
  local: 'Assistant intégré',
  openai: 'ChatGPT',
  copilot: 'Microsoft Copilot',
  anthropic: 'Claude Anthropic',
  gemini: 'Google AI Studio (Gemini)',
};

function imageQuery(input: ConceptInput) {
  const q = `${input.discipline} ${input.notion} school education africa`;
  return illustrate(q, input.notion);
}

function videoFor(input: ConceptInput) {
  const text = `${input.notion} ${input.discipline}`.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (text.includes('feux') || text.includes('rue') || text.includes('route') || text.includes('circulation')) return ['https://www.youtube.com/watch?v=PSsNGIY2zOo'];
  if (text.includes('math') || text.includes('addition') || text.includes('soustraction') || text.includes('fraction')) return ['https://www.youtube.com/watch?v=4O8X7xG6dpA'];
  if (text.includes('lecture') || text.includes('phrase') || text.includes('verbe') || text.includes('francais')) return ['https://www.youtube.com/watch?v=VeSUzYblKio'];
  if (text.includes('science') || text.includes('corps') || text.includes('plante') || text.includes('eau') || text.includes('svt')) return ['https://www.youtube.com/watch?v=tZ4lCI6Pyoo'];
  if (text.includes('sport') || text.includes('eps') || text.includes('course') || text.includes('saut')) return ['https://www.youtube.com/watch?v=rdLfnajz3wg'];
  return ['https://www.youtube.com/watch?v=KCGamQMZ7Nk'];
}

function buildPrompt(input: ConceptInput) {
  return `Tu es un professeur expert, pédagogue et clair pour les élèves africains francophones.

Explique la notion suivante directement à l'élève, sans expliquer comment l'enseignant doit enseigner.

Notion : ${input.notion}
Discipline : ${input.discipline}
Niveau : ${input.level}
Contenu déjà disponible : ${input.currentContent.slice(0, 5000)}

Produis une réponse en français simple avec :
1. Explication détaillée de la notion.
2. Fonction ou rôle de la notion.
3. Points importants à retenir.
4. Exemples proches du vécu de l'élève.
5. Résumé simple pour petit écolier.
6. Deux petits exercices de vérification.

Retourne uniquement un JSON valide :
{"title":"...","text":"...","simpleSummary":"..."}`;
}

function parseAIText(text: string, input: ConceptInput, provider: ConceptAIProvider): ConceptExplanation {
  const cleaned = text.replace(/```json|```/g, '').trim();
  try {
    const data = JSON.parse(cleaned);
    return {
      provider,
      title: data.title || input.notion,
      text: data.text || cleaned,
      simpleSummary: data.simpleSummary || data.resume || '',
      imageUrl: imageQuery(input),
      videoUrls: videoFor(input),
    };
  } catch {
    return {
      provider,
      title: input.notion,
      text: cleaned || localExplanation(input).text,
      simpleSummary: localExplanation(input).simpleSummary,
      imageUrl: imageQuery(input),
      videoUrls: videoFor(input),
    };
  }
}

function localExplanation(input: ConceptInput): ConceptExplanation {
  const base = input.currentContent || `${input.notion} est une notion importante du programme.`;
  return {
    provider: 'local',
    title: input.notion,
    text: `Explication de la notion\n${base}\n\nCe qu'il faut comprendre\nCette notion aide l'élève à mieux comprendre ${input.discipline}. Elle doit être reliée à des exemples simples de la vie quotidienne, de l'école ou du milieu de l'enfant.\n\nPoints importants\n- Comprendre le sens de la notion.\n- Savoir reconnaître la notion dans une situation.\n- Donner un exemple concret.\n- Utiliser correctement la notion dans un exercice.\n\nExemples\nL'élève peut utiliser cette notion dans une phrase, un calcul, une observation, un schéma ou une activité selon la discipline.\n\nPetits exercices\n1. Explique avec tes propres mots : ${input.notion}.\n2. Donne un exemple de ${input.notion} dans ta vie de tous les jours.`,
    simpleSummary: `${input.notion} est une notion à comprendre, expliquer avec un exemple et utiliser correctement dans une activité.`,
    imageUrl: imageQuery(input),
    videoUrls: videoFor(input),
  };
}

async function generateWithGemini(settings: AISettings, input: ConceptInput) {
  if (!settings.geminiKey) return localExplanation(input);
  const model = settings.geminiModel || 'gemini-2.5-flash';
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': settings.geminiKey },
    body: JSON.stringify({ contents: [{ parts: [{ text: buildPrompt(input) }] }] }),
  });
  if (!res.ok) return localExplanation(input);
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text || '').join('\n') || '';
  return parseAIText(text, input, 'gemini');
}

async function generateWithOpenAI(settings: AISettings, input: ConceptInput) {
  if (!settings.openaiKey) return localExplanation(input);
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${settings.openaiKey}` },
    body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: buildPrompt(input) }], temperature: 0.35 }),
  });
  if (!res.ok) return localExplanation(input);
  const data = await res.json();
  return parseAIText(data?.choices?.[0]?.message?.content || '', input, 'openai');
}

async function generateWithAnthropic(settings: AISettings, input: ConceptInput) {
  if (!settings.anthropicKey) return localExplanation(input);
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': settings.anthropicKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: 'claude-3-5-sonnet-latest', max_tokens: 2500, messages: [{ role: 'user', content: buildPrompt(input) }] }),
  });
  if (!res.ok) return localExplanation(input);
  const data = await res.json();
  return parseAIText(data?.content?.map((p: any) => p.text || '').join('\n') || '', input, 'anthropic');
}

async function generateWithCopilot(settings: AISettings, input: ConceptInput) {
  if (!settings.copilotEndpoint || !settings.copilotKey) return localExplanation(input);
  const separator = settings.copilotEndpoint.includes('?') ? '&' : '?';
  const res = await fetch(`${settings.copilotEndpoint}${separator}api-version=2024-02-15-preview`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'api-key': settings.copilotKey },
    body: JSON.stringify({ messages: [{ role: 'user', content: buildPrompt(input) }], temperature: 0.35 }),
  });
  if (!res.ok) return localExplanation(input);
  const data = await res.json();
  return parseAIText(data?.choices?.[0]?.message?.content || '', input, 'copilot');
}

export async function explainConceptWithAI(provider: ConceptAIProvider, input: ConceptInput): Promise<ConceptExplanation> {
  const settings = getAISettings();
  if (provider === 'gemini') return generateWithGemini(settings, input);
  if (provider === 'openai') return generateWithOpenAI(settings, input);
  if (provider === 'anthropic') return generateWithAnthropic(settings, input);
  if (provider === 'copilot') return generateWithCopilot(settings, input);
  return localExplanation(input);
}

export function getProviderLabel(provider: ConceptAIProvider) {
  return providerLabel[provider];
}
