import { ClassData, Student } from './database';

export type OrientationDomain = 'litteraire' | 'scientifique' | 'economique' | 'technique' | 'social' | 'culturel' | 'general';

export interface OrientationExtraInfo {
  id: string;
  title: string;
  series: string;
  domains: OrientationDomain[];
  subjects: string;
  studies: string;
  careers: string;
  advice: string;
  createdAt: number;
}

export interface SubjectPerformance {
  subjectName: string;
  score: number;
  domain: OrientationDomain;
}

export interface OrientationRecommendation {
  domain: OrientationDomain;
  title: string;
  series: string;
  studies: string[];
  careers: string[];
  subjectsToStrengthen: string[];
  reason: string;
  priority: 'forte' | 'moyenne' | 'exploratoire';
}

export const ORIENTATION_EXTRA_KEY = 'msp_orientation_extra_info';

export function loadOrientationExtras(): OrientationExtraInfo[] {
  try {
    const raw = localStorage.getItem(ORIENTATION_EXTRA_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore invalid local data
  }
  return [];
}

export function saveOrientationExtras(items: OrientationExtraInfo[]) {
  localStorage.setItem(ORIENTATION_EXTRA_KEY, JSON.stringify(items));
}

export function subjectDomain(subjectName: string): OrientationDomain {
  const s = subjectName.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (s.includes('math')) return 'scientifique';
  if (s.includes('pct') || s.includes('phys') || s.includes('chim') || s.includes('svt') || s.includes('science') || s.includes('est')) return 'scientifique';
  if (s.includes('franc') || s.includes('lecture') || s.includes('dictee') || s.includes('expression') || s.includes('communication') || s.includes('lang') || s.includes('anglais') || s.includes('allemand') || s.includes('espagnol') || s.includes('lv')) return 'litteraire';
  if (s.includes('histoire') || s.includes('geo') || s.includes('philo') || s.includes('socio') || s.includes('conduite')) return 'social';
  if (s.includes('economie') || s.includes('gestion') || s.includes('commerce')) return 'economique';
  if (s.includes('techno') || s.includes('informatique') || s.includes('mecanique') || s.includes('electric')) return 'technique';
  if (s.includes('art') || s.includes('dessin') || s.includes('musique') || s.includes('culture')) return 'culturel';
  return 'general';
}

export function getStudentPerformances(classData: ClassData, student: Student): SubjectPerformance[] {
  return classData.subjects
    .map(subject => {
      const note = classData.notes.find(n => n.studentId === student.id && n.subjectId === subject.id && !n.absent);
      if (!note || note.noteObtenue === null) return null;
      const max = subject.noteObtenueMax + subject.notePerfectionnementMax || 20;
      const raw = (note.noteObtenue ?? 0) + (note.notePerfectionnement ?? 0);
      const score = max === 20 ? raw : (raw / max) * 20;
      return { subjectName: subject.name, score, domain: subjectDomain(subject.name) };
    })
    .filter(Boolean) as SubjectPerformance[];
}

function average(values: number[]) {
  return values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
}

export function buildOrientationRecommendations(
  classData: ClassData,
  student: Student
): { performances: SubjectPerformance[]; recommendations: OrientationRecommendation[]; domainScores: Record<string, number> } {
  const performances = getStudentPerformances(classData, student);
  const domainScores: Record<string, number> = {};
  const domains: OrientationDomain[] = ['litteraire', 'scientifique', 'economique', 'technique', 'social', 'culturel', 'general'];
  for (const domain of domains) {
    domainScores[domain] = average(performances.filter(p => p.domain === domain).map(p => p.score));
  }

  const recs: OrientationRecommendation[] = [];
  const push = (rec: Omit<OrientationRecommendation, 'priority'>, score: number) => {
    recs.push({
      ...rec,
      priority: score >= 14 ? 'forte' : score >= 10 ? 'moyenne' : 'exploratoire',
    });
  };

  const sci = Math.max(domainScores.scientifique || 0, average(performances.filter(p => ['Mathématiques', 'Math', 'PCT', 'SVT'].some(k => p.subjectName.includes(k))).map(p => p.score)));
  if (sci >= 10) push({
    domain: 'scientifique',
    title: 'Parcours scientifiques, santé, ingénierie et informatique',
    series: 'BAC C, D, E ou filières scientifiques/techniques',
    studies: ['Médecine', 'Pharmacie', 'Génie civil', 'Génie informatique', 'Intelligence artificielle', 'Agronomie', 'Environnement', 'Statistique'],
    careers: ['Médecin', 'Ingénieur', 'Développeur', 'Data analyst', 'Agronome', 'Technicien supérieur', 'Chercheur'],
    subjectsToStrengthen: ['Mathématiques', 'PCT/SPCT', 'SVT', 'Français', 'Anglais'],
    reason: 'L’élève montre un potentiel dans les matières scientifiques ou logico-mathématiques.',
  }, sci);

  const lit = Math.max(domainScores.litteraire || 0, domainScores.social || 0);
  if (lit >= 10) push({
    domain: 'litteraire',
    title: 'Parcours lettres, langues, droit, communication et sciences humaines',
    series: 'BAC A1/A2 ou filières littéraires et sociales',
    studies: ['Lettres modernes', 'Langues', 'Droit', 'Communication', 'Journalisme', 'Sciences de l’éducation', 'Sociologie', 'Psychologie', 'Administration'],
    careers: ['Enseignant', 'Juriste', 'Journaliste', 'Traducteur', 'Chargé de communication', 'Administrateur', 'Agent social'],
    subjectsToStrengthen: ['Français', 'Philosophie', 'Histoire-Géographie', 'Langues', 'Culture générale'],
    reason: 'Les résultats en langues, lecture, français ou sciences humaines indiquent des aptitudes littéraires/sociales.',
  }, lit);

  const eco = domainScores.economique || 0;
  if (eco >= 8 || performances.some(p => p.subjectName.toLowerCase().includes('economie'))) push({
    domain: 'economique',
    title: 'Parcours économie, gestion, finance et commerce',
    series: 'BAC B, G2, G3 ou filières gestion/commerce',
    studies: ['Économie', 'Finance-Comptabilité', 'Banque', 'Assurance', 'Marketing', 'Management', 'Ressources humaines', 'Commerce international'],
    careers: ['Comptable', 'Auditeur', 'Banquier', 'Commercial', 'Responsable marketing', 'Gestionnaire RH', 'Entrepreneur'],
    subjectsToStrengthen: ['Économie', 'Mathématiques', 'Étude de cas', 'Français', 'Anglais'],
    reason: 'Le profil peut être orienté vers la gestion et les métiers économiques si les bases sont consolidées.',
  }, Math.max(eco, 10));

  const tech = domainScores.technique || 0;
  if (tech >= 8) push({
    domain: 'technique',
    title: 'Parcours techniques, industriels et professionnels',
    series: 'BAC E, F, DT ou filières techniques',
    studies: ['Maintenance', 'Électricité', 'Mécanique', 'BTP', 'Informatique', 'Télécommunications', 'Génie industriel'],
    careers: ['Technicien', 'Assistant ingénieur', 'Conducteur de travaux', 'Technicien maintenance', 'Développeur web', 'Technicien réseaux'],
    subjectsToStrengthen: ['Mathématiques appliquées', 'Technologie', 'PCT', 'Français', 'Anglais'],
    reason: 'Les aptitudes pratiques et techniques peuvent être valorisées dans un parcours professionnel ou technologique.',
  }, Math.max(tech, 10));

  if (recs.length === 0) {
    recs.push({
      domain: 'general',
      title: 'Orientation à consolider',
      series: 'À déterminer après renforcement des bases',
      studies: ['Parcours général à préciser', 'Formation professionnelle', 'Soutien/remédiation avant choix définitif'],
      careers: ['À explorer avec l’élève et les parents'],
      subjectsToStrengthen: ['Français', 'Mathématiques', 'Méthodologie', 'Assiduité', 'Lecture'],
      reason: 'Les résultats actuels ne permettent pas encore de dégager une dominante fiable.',
      priority: 'exploratoire',
    });
  }

  const priorityWeight = { forte: 0, moyenne: 1, exploratoire: 2 } as const;
  return { performances, recommendations: recs.sort((a, b) => priorityWeight[a.priority] - priorityWeight[b.priority]), domainScores };
}
