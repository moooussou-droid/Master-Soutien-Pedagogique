export function calculateBMI(weightKg?: number | string, heightCm?: number | string): number | null {
  const weight = typeof weightKg === 'string' ? parseFloat(weightKg) : weightKg;
  const height = typeof heightCm === 'string' ? parseFloat(heightCm) : heightCm;
  if (!weight || !height || height <= 0) return null;
  const meters = height / 100;
  return weight / (meters * meters);
}

export function bmiLabel(bmi: number | null): string {
  if (bmi === null) return 'IMC non calculé';
  if (bmi < 18.5) return 'Surveillance : maigreur possible';
  if (bmi < 25) return 'Corpulence normale';
  if (bmi < 30) return 'Surveillance : surpoids possible';
  return 'Surveillance : obésité possible';
}
