/**
 * Export des fiches pédagogiques générées :
 * - Impression / PDF (fenêtre d'impression propre)
 * - Téléchargement Word (.docx) — généré localement avec JSZip (aucune lib externe)
 */
import JSZip from 'jszip';
import { GeneratedLessonPlan } from './aiLessonGenerator';

function esc(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** Construit un document Word minimal mais 100 % valide. (exporté pour les tests) */
export function buildDocxXml(plan: GeneratedLessonPlan): string {
  const para = (text: string, bold = false, size = 22, spacing = 120) => {
    const textXml = esc(String(text));
    const b = bold ? '<w:b/>' : '';
    return `<w:p><w:pPr><w:spacing w:after="${spacing}"/></w:pPr><w:r><w:rPr>${b}<w:sz w:val="${size}"/></w:rPr><w:t xml:space="preserve">${textXml}</w:t></w:r></w:p>`;
  };
  const section = (titre: string, contenu: string) =>
    para(titre, true, 24, 240) + contenu.split('\n').map((l) => para(l.trim(), false, 22)).join('');

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body>
${para('FICHE PÉDAGOGIQUE — Master Soutien Pédagogique', true, 30, 300)}
${para(`${plan.classe} • ${plan.matiere} • ${plan.duree}`, false, 22)}
${section('Titre', plan.titre)}
${section('Compétence', plan.competence)}
${section('Objectif', plan.objectif)}
${section('Matériel', plan.materiel)}
${section('Déroulement', plan.deroulement)}
${section('Évaluation', plan.evaluation)}
</w:body>
</w:document>`;
}

/** Génère et télécharge un fichier .docx de la fiche. */
export async function downloadFicheDocx(plan: GeneratedLessonPlan, filename?: string): Promise<void> {
  const zip = new JSZip();
  zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`);
  zip.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`);
  zip.file('word/document.xml', buildDocxXml(plan));

  const blob = await zip.generateAsync({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  const safe = (plan.titre || 'fiche').replace(/[^a-zA-Z0-9àâäéèêëîïôöùûüç -]/g, '').replace(/\s+/g, '_').slice(0, 60);
  const name = filename || `fiche_${safe}_${plan.classe || ''}.docx`.replace(/\s+/g, '_');

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.rel = 'noopener';
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    try {
      document.body.removeChild(link);
    } catch { /* déjà retiré */ }
    URL.revokeObjectURL(url);
  }, 4000);
}

/** Ouvre une fenêtre d'impression propre (imprimer ou enregistrer en PDF). */
export function printFiche(plan: GeneratedLessonPlan): void {
  const h = (t: string, c: string) => `<h2>${esc(t)}</h2><div class="c">${esc(c).replace(/\n/g, '<br/>')}</div>`;
  const html = `<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8"><title>${esc(plan.titre)}</title>
<style>
  @page { margin: 14mm; }
  body { font-family: Georgia, 'Times New Roman', serif; color: #111; margin: 0; }
  .head { text-align: center; border-bottom: 2px solid #006b4f; padding-bottom: 8px; margin-bottom: 14px; }
  .head h1 { font-size: 18px; color: #006b4f; margin: 0 0 4px; }
  .head p { margin: 0; font-size: 12px; color: #333; }
  h2 { font-size: 13px; color: #006b4f; margin: 12px 0 4px; text-transform: uppercase; letter-spacing: .5px; }
  .c { font-size: 12.5px; line-height: 1.5; }
  .foot { margin-top: 20px; font-size: 10px; color: #777; text-align: center; border-top: 1px solid #ccc; padding-top: 6px; }
</style></head>
<body>
<div class="head">
  <h1>FICHE PÉDAGOGIQUE</h1>
  <p>${esc(plan.classe)} • ${esc(plan.matiere)} • Durée : ${esc(plan.duree)}</p>
</div>
${h('Titre', plan.titre)}
${h('Compétence', plan.competence)}
${h('Objectif', plan.objectif)}
${h('Matériel', plan.materiel)}
${h('Déroulement', plan.deroulement)}
${h('Évaluation', plan.evaluation)}
<div class="foot">Générée avec Master Soutien Pédagogique — aide à l'impression : choisissez « Enregistrer en PDF » pour obtenir un fichier PDF.</div>
<script>window.onload = function(){ window.print(); };</script>
</body></html>`;

  const win = window.open('', '_blank', 'width=900,height=700');
  if (!win) {
    alert('Autorisez les fenêtres pop-up pour imprimer la fiche.');
    return;
  }
  win.document.open();
  win.document.write(html);
  win.document.close();
}
