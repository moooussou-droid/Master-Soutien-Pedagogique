import ExcelJS from 'exceljs';
import { Student, Subject, generateId } from './database';

/**
 * Génère un modèle Excel vierge avec les colonnes Matricule, Nom, Prénoms
 * que l'enseignant peut remplir puis réimporter.
 */
export async function generateStudentTemplate(): Promise<Blob> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Élèves');

  worksheet.getCell('A1').value = 'Matricule';
  worksheet.getCell('B1').value = 'Nom';
  worksheet.getCell('C1').value = 'Prénoms';

  // Style de l'en-tête
  ['A1', 'B1', 'C1'].forEach(ref => {
    const cell = worksheet.getCell(ref);
    cell.font = { bold: true, size: 11 };
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFD1FAE5' },
    };
    cell.border = {
      top: { style: 'thin' },
      bottom: { style: 'thin' },
      left: { style: 'thin' },
      right: { style: 'thin' },
    };
  });

  // Exemples
  const examples = [
    ['117042400', 'AMADOU', 'Tamou'],
    ['218042401', 'ASSOUMA', 'Assana'],
    ['117042308', 'AWALI', 'Moutiou'],
  ];
  examples.forEach((row, i) => {
    const rowNum = i + 2;
    const mat = worksheet.getCell(`A${rowNum}`);
    mat.value = row[0];
    mat.numFmt = '@';
    worksheet.getCell(`B${rowNum}`).value = row[1];
    worksheet.getCell(`C${rowNum}`).value = row[2];
  });

  worksheet.getColumn(1).width = 18;
  worksheet.getColumn(1).numFmt = '@';
  worksheet.getColumn(2).width = 22;
  worksheet.getColumn(3).width = 25;

  const buffer = await workbook.xlsx.writeBuffer();
  return new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
}

/** Note lue dans le fichier, associée à un élève (par son id généré) et à un nom de matière. */
export interface ParsedNote {
  studentId: string; // id généré de l'élève importé
  subjectName: string; // nom brut de la matière dans le fichier
  subjectId?: string; // id de la matière de la classe correspondante (si trouvée)
  noteObtenue: number | null;
  notePerfectionnement: number | null;
  absent: boolean;
}

export interface ImportResult {
  students: Student[];
  errors: string[];
  totalRows: number;
  importedRows: number;
  // Notes détectées dans le fichier (si présentes)
  parsedNotes: ParsedNote[];
  detectedSubjects: string[]; // noms de matières détectés dans le fichier
  notesCount: number; // nombre de valeurs de notes détectées
}

/**
 * Normalise une chaîne pour comparaison (minuscules, sans accents, sans espaces)
 */
function normalize(str: string): string {
  return str
    .toString()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // enlève les accents
    .replace(/[^a-z0-9]/g, ''); // enlève espaces et ponctuation
}

/**
 * Convertit une valeur de cellule ExcelJS en chaîne de texte propre.
 * Gère les nombres, chaînes, cellules riches, formules, etc.
 */
function cellToString(value: ExcelJS.CellValue): string {
  if (value === null || value === undefined) return '';
  
  // Nombre
  if (typeof value === 'number') {
    return value.toString();
  }
  
  // Chaîne simple
  if (typeof value === 'string') {
    return value.trim();
  }
  
  // Objet (texte riche, formule, hyperlink, date...)
  if (typeof value === 'object') {
    const obj = value as any;
    // Texte riche
    if (Array.isArray(obj.richText)) {
      return obj.richText.map((rt: any) => rt.text).join('').trim();
    }
    // Formule avec résultat
    if (obj.result !== undefined && obj.result !== null) {
      return obj.result.toString().trim();
    }
    // Hyperlink
    if (obj.text !== undefined) {
      return obj.text.toString().trim();
    }
    // Date
    if (value instanceof Date) {
      return value.toString();
    }
  }
  
  return value.toString().trim();
}

/**
 * Importe une liste d'élèves (et leurs notes si présentes) depuis un fichier Excel.
 * Détecte automatiquement les colonnes Matricule, Nom, Prénoms
 * même dans le format EducMaster (2 lignes d'en-tête, données dès la ligne 3).
 * Si des colonnes de matières avec des notes sont détectées, elles sont lues et
 * associées aux matières de la classe (paramètre `subjects`).
 */
export async function importStudentsFromExcel(
  file: File,
  subjects: Subject[] = []
): Promise<ImportResult> {
  const result: ImportResult = {
    students: [],
    errors: [],
    totalRows: 0,
    importedRows: 0,
    parsedNotes: [],
    detectedSubjects: [],
    notesCount: 0,
  };

  const workbook = new ExcelJS.Workbook();
  const arrayBuffer = await file.arrayBuffer();
  await workbook.xlsx.load(arrayBuffer);

  const worksheet = workbook.worksheets[0];
  if (!worksheet) {
    result.errors.push('Aucune feuille de calcul trouvée dans le fichier.');
    return result;
  }

  // Étape 1 : trouver la ligne d'en-tête et les indices de colonnes
  let matriculeCol = -1;
  let nomCol = -1;
  let prenomsCol = -1;
  let headerRowNumber = -1;

  // On scanne les 5 premières lignes pour trouver les en-têtes
  const maxHeaderScan = Math.min(5, worksheet.rowCount);
  for (let rowNum = 1; rowNum <= maxHeaderScan; rowNum++) {
    const row = worksheet.getRow(rowNum);
    let foundInThisRow = 0;

    row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
      const text = normalize(cellToString(cell.value));
      if (!text) return;

      if ((text === 'matricule' || text.includes('matricule')) && matriculeCol === -1) {
        matriculeCol = colNumber;
        foundInThisRow++;
      } else if ((text === 'nom' || text === 'noms') && nomCol === -1) {
        nomCol = colNumber;
        foundInThisRow++;
      } else if ((text === 'prenoms' || text === 'prenom') && prenomsCol === -1) {
        prenomsCol = colNumber;
        foundInThisRow++;
      }
    });

    if (foundInThisRow > 0 && headerRowNumber === -1) {
      headerRowNumber = rowNum;
    }
  }

  // Si aucun en-tête détecté, on suppose le format standard : A=Matricule, B=Nom, C=Prénoms
  if (matriculeCol === -1 && nomCol === -1 && prenomsCol === -1) {
    matriculeCol = 1;
    nomCol = 2;
    prenomsCol = 3;
    headerRowNumber = 1;
    result.errors.push(
      'En-têtes non détectés : lecture par défaut des colonnes A (Matricule), B (Nom), C (Prénoms).'
    );
  } else {
    // Compléter les colonnes manquantes avec des positions par défaut logiques
    if (matriculeCol === -1) matriculeCol = 1;
    if (nomCol === -1) nomCol = 2;
    if (prenomsCol === -1) prenomsCol = 3;
  }

  // Étape 2 : déterminer la première ligne de données.
  // Dans le format EducMaster, la ligne 2 contient "Note obtenue / Note perfectionnement".
  // Les vraies données commencent donc après. On saute les lignes d'en-tête connues.
  let firstDataRow = headerRowNumber + 1;

  // Vérifier si la ligne suivante est une seconde ligne d'en-tête (contient "note obtenue" etc.)
  const nextRow = worksheet.getRow(firstDataRow);
  let looksLikeSubHeader = false;
  const isObtHeader = (text: string) =>
    text.includes('noteobtenue') ||
    text.includes('criteresminimaux') ||
    text === 'cm' ||
    text === 'note';

  const isPerfHeader = (text: string) =>
    text.includes('perfectionnement') ||
    text.includes('noteperfect') ||
    text === 'cp';

  nextRow.eachCell({ includeEmpty: false }, (cell) => {
    const text = normalize(cellToString(cell.value));
    if (isObtHeader(text) || isPerfHeader(text)) {
      looksLikeSubHeader = true;
    }
  });
  if (looksLikeSubHeader) {
    firstDataRow++;
  }

  // Étape 2bis : détecter les colonnes de matières (pour importer les notes)
  interface SubjectColumn {
    name: string;
    matchedSubject?: Subject;
    obtenueCol: number;
    perfCol: number | null;
  }
  const subjectColumns: SubjectColumn[] = [];

  const headerRow = worksheet.getRow(headerRowNumber);
  const subHeaderRow = looksLikeSubHeader ? worksheet.getRow(headerRowNumber + 1) : null;

  // Récupère les positions des noms de matières dans la ligne d'en-tête (après Prénoms).
  // Important : dans certains fichiers exportés, ExcelJS peut répéter le nom d'une
  // matière dans les cellules fusionnées (ex. D1 et E1 = "Dictée"). On collapse donc
  // les doublons consécutifs pour garder un seul groupe de colonnes par matière.
  const subjectHeaders: { name: string; col: number }[] = [];
  let previousHeaderNorm = '';
  headerRow.eachCell({ includeEmpty: false }, (cell, colNumber) => {
    if (colNumber <= prenomsCol) return;
    const raw = cellToString(cell.value).trim();
    if (!raw) return;
    const n = normalize(raw);
    // Exclure les en-têtes génériques (sous-colonnes)
    if (isObtHeader(n) || isPerfHeader(n) ||
        n === 'coefficient' || n === 'coef' || n === 'totalobtenu' || n === 'totalpossible' ||
        n === 'note' || n === 'total') {
      return;
    }
    if (n === previousHeaderNorm) return;
    previousHeaderNorm = n;
    subjectHeaders.push({ name: raw, col: colNumber });
  });

  // Fonction de correspondance d'une matière du fichier avec une matière de la classe
  function matchSubject(fileName: string): Subject | undefined {
    const target = normalize(fileName);
    // Correspondance exacte d'abord
    let found = subjects.find(s => normalize(s.name) === target);
    if (found) return found;
    // Correspondance partielle (l'un contient l'autre)
    found = subjects.find(s => {
      const sn = normalize(s.name);
      return sn.length > 2 && (sn.includes(target) || target.includes(sn));
    });
    return found;
  }

  // Pour chaque matière détectée, déterminer les colonnes obtenue / perfectionnement
  for (let i = 0; i < subjectHeaders.length; i++) {
    const { name, col } = subjectHeaders[i];
    const nextCol = i + 1 < subjectHeaders.length ? subjectHeaders[i + 1].col : worksheet.columnCount + 1;
    const span = nextCol - col; // nombre de colonnes pour cette matière

    let obtenueCol = col;
    let perfCol: number | null = span >= 2 ? col + 1 : null;

    // Si une sous-ligne d'en-tête existe, l'utiliser pour repérer les colonnes précisément
    if (subHeaderRow) {
      for (let c = col; c < nextCol; c++) {
        const sub = normalize(cellToString(subHeaderRow.getCell(c).value));
        if (isObtHeader(sub)) obtenueCol = c;
        else if (isPerfHeader(sub)) perfCol = c;
      }
    }

    subjectColumns.push({
      name,
      matchedSubject: matchSubject(name),
      obtenueCol,
      perfCol,
    });
  }

  result.detectedSubjects = subjectColumns.map(sc => sc.name);

  // Lit une valeur de note : nombre, ou "ABS"/"absent" -> absent
  function readNoteValue(rowObj: ExcelJS.Row, colNumber: number): { value: number | null; absent: boolean } {
    const raw = cellToString(rowObj.getCell(colNumber).value).trim();
    if (!raw) return { value: null, absent: false };
    const n = normalize(raw);
    if (n === 'abs' || n === 'absent') return { value: null, absent: true };
    const num = parseFloat(raw.replace(',', '.'));
    if (isNaN(num)) return { value: null, absent: false };
    return { value: num, absent: false };
  }

  // Étape 3 : lire les données élèves
  const seenMatricules = new Set<string>();

  for (let rowNum = firstDataRow; rowNum <= worksheet.rowCount; rowNum++) {
    const row = worksheet.getRow(rowNum);

    const matricule = cellToString(row.getCell(matriculeCol).value)
      .replace(/^'+/, '') // enlève l'apostrophe de forçage texte
      .trim();
    const nom = cellToString(row.getCell(nomCol).value).trim();
    const prenoms = cellToString(row.getCell(prenomsCol).value).trim();

    // Ignorer les lignes complètement vides
    if (!matricule && !nom && !prenoms) {
      continue;
    }

    result.totalRows++;

    // Validation : au moins un nom requis
    if (!nom && !prenoms) {
      result.errors.push(`Ligne ${rowNum} ignorée : nom et prénoms manquants.`);
      continue;
    }

    // Éviter les doublons de matricule dans le même import
    if (matricule && seenMatricules.has(matricule)) {
      result.errors.push(`Ligne ${rowNum} ignorée : matricule "${matricule}" en double.`);
      continue;
    }
    if (matricule) seenMatricules.add(matricule);

    const studentId = generateId();
    result.students.push({
      id: studentId,
      matricule: matricule || `SANS-MAT-${result.students.length + 1}`,
      nom: nom.toUpperCase(),
      prenoms: prenoms,
      createdAt: Date.now() + result.students.length, // ordre stable
    });
    result.importedRows++;

    // Lire les notes de cet élève pour chaque matière détectée
    for (const sc of subjectColumns) {
      const obt = readNoteValue(row, sc.obtenueCol);
      const perf = sc.perfCol !== null ? readNoteValue(row, sc.perfCol) : { value: null, absent: false };

      const absent = obt.absent || perf.absent;
      const hasValue = obt.value !== null || perf.value !== null || absent;
      if (!hasValue) continue; // aucune note pour cette matière

      result.parsedNotes.push({
        studentId,
        subjectName: sc.name,
        subjectId: sc.matchedSubject?.id,
        noteObtenue: obt.value,
        notePerfectionnement: perf.value,
        absent,
      });
      result.notesCount++;
    }
  }

  if (result.students.length === 0 && result.totalRows === 0) {
    result.errors.push('Aucun élève trouvé dans le fichier. Vérifiez le format.');
  }

  return result;
}
