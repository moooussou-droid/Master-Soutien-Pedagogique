/**
 * Synchronisation cloud chiffrée de bout en bout.
 *
 * Modèle de confidentialité :
 * - L'utilisateur choisit un "Code de synchronisation" (identifiant public unique)
 *   et un "Mot de passe secret" (jamais envoyé au serveur).
 * - Toutes les données sont chiffrées localement avec le mot de passe secret,
 *   puis envoyées au serveur qui ne voit qu'un blob illisible.
 * - Pour restaurer sur un autre appareil : même code + même mot de passe secret.
 */

import { SUPABASE_URL, SUPABASE_ANON_KEY, isCloudConfigured } from './cloudConfig';
import { encryptData, decryptData } from './crypto';
import { exportAllData, importAllData } from './database';

export interface CloudSettings {
  enabled: boolean;
  syncCode: string;
  // Le mot de passe secret n'est JAMAIS stocké en clair de façon permanente.
  // Il est gardé en mémoire pendant la session, et optionnellement en local
  // (choix de l'utilisateur) pour éviter de le retaper.
  rememberPassphrase: boolean;
}

const SETTINGS_KEY = 'msp_cloud_settings';
const PASS_KEY = 'msp_cloud_pass';
const LAST_SYNC_KEY = 'msp_cloud_last_sync';

export function getCloudSettings(): CloudSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return { enabled: false, syncCode: '', rememberPassphrase: false };
}

export function saveCloudSettings(settings: CloudSettings): void {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export function getStoredPassphrase(): string {
  try {
    return localStorage.getItem(PASS_KEY) || '';
  } catch {
    return '';
  }
}

export function setStoredPassphrase(pass: string, remember: boolean): void {
  if (remember) {
    localStorage.setItem(PASS_KEY, pass);
  } else {
    localStorage.removeItem(PASS_KEY);
  }
}

export function clearCloudSession(): void {
  localStorage.removeItem(PASS_KEY);
}

export function getLastSync(): string {
  try {
    return localStorage.getItem(LAST_SYNC_KEY) || '';
  } catch {
    return '';
  }
}

function setLastSync(iso: string): void {
  localStorage.setItem(LAST_SYNC_KEY, iso);
}

function headers() {
  return {
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
  };
}

/**
 * Envoie (sauvegarde) toutes les données chiffrées vers le cloud.
 */
export async function pushToCloud(syncCode: string, passphrase: string): Promise<void> {
  if (!isCloudConfigured()) {
    throw new Error('CLOUD_NON_CONFIGURE');
  }
  const json = await exportAllData();
  const encrypted = await encryptData(json, passphrase);

  const body = [{
    sync_code: syncCode,
    data: encrypted,
    updated_at: new Date().toISOString(),
  }];

  const res = await fetch(`${SUPABASE_URL}/rest/v1/backups`, {
    method: 'POST',
    headers: {
      ...headers(),
      'Prefer': 'resolution=merge-duplicates,return=minimal',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Erreur d'envoi (${res.status}) : ${txt}`);
  }

  setLastSync(new Date().toISOString());
}

/**
 * Récupère et déchiffre les données depuis le cloud, puis les importe localement.
 * Retourne false si aucune sauvegarde n'existe pour ce code.
 */
export async function pullFromCloud(syncCode: string, passphrase: string): Promise<boolean> {
  if (!isCloudConfigured()) {
    throw new Error('CLOUD_NON_CONFIGURE');
  }

  const url = `${SUPABASE_URL}/rest/v1/backups?sync_code=eq.${encodeURIComponent(syncCode)}&select=data,updated_at`;
  const res = await fetch(url, { headers: headers() });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Erreur de récupération (${res.status}) : ${txt}`);
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    return false; // aucune sauvegarde pour ce code
  }

  const encrypted = rows[0].data as string;

  let json: string;
  try {
    json = await decryptData(encrypted, passphrase);
  } catch {
    throw new Error('MOT_DE_PASSE_INCORRECT');
  }

  await importAllData(json);
  setLastSync(new Date().toISOString());
  return true;
}

/** Génère un code de synchronisation lisible et unique. */
export function generateSyncCode(): string {
  const part = () => Math.random().toString(36).substring(2, 6).toUpperCase();
  return `MSP-${part()}-${part()}`;
}
