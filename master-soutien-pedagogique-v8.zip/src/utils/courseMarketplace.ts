export interface CourseLesson {
  title: string;
  content: string;
  videoUrl?: string;
  imageUrl?: string;
}

export interface CourseOffer {
  id: string;
  title: string;
  author: string;
  level: string;
  description: string;
  price: string;
  type: 'gratuit' | 'payant';
  link: string;
  lessons: CourseLesson[];
  status: 'pending' | 'approved' | 'rejected';
  createdAt: number;
}

export const COURSE_KEY = 'msp_marketplace_courses';

export function loadCourses(): CourseOffer[] {
  try {
    return JSON.parse(localStorage.getItem(COURSE_KEY) || '[]');
  } catch {
    return [];
  }
}

export function saveCourses(courses: CourseOffer[]) {
  localStorage.setItem(COURSE_KEY, JSON.stringify(courses));
}

export function getVideoEmbed(url: string) {
  if (!url) return '';
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([\w-]{11})/);
  if (match) return `https://www.youtube-nocookie.com/embed/${match[1]}?rel=0&modestbranding=1&playsinline=1`;

  // Facebook : plugin vidéo intégré
  if (url.includes('facebook.com') || url.includes('fb.watch')) {
    return `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}&show_text=false&width=720`;
  }

  // TikTok : oEmbed / embed direct simple. Certains liens peuvent être bloqués par TikTok.
  const tikTokMatch = url.match(/tiktok\.com\/@[^/]+\/video\/(\d+)/);
  if (tikTokMatch) return `https://www.tiktok.com/embed/v2/${tikTokMatch[1]}`;

  return '';
}

export const getYouTubeEmbed = getVideoEmbed;
