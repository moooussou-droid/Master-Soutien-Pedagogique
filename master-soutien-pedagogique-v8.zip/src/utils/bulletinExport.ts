/**
 * Export GROUPÉ des bulletins — toute la classe en un seul fichier :
 * - Excel (.xlsx) : tableau récapitulatif (notes, moyennes, rangs, mentions) + synthèse
 * - Word (.docx) : un bulletin officiel par élève, avec saut de page entre chaque
 */
import ExcelJS from 'exceljs';
import JSZip from 'jszip';
import { ClassData, isSecondaire } from './database';
import { StudentBulletin } from './bulletin';

/* ------------------------------------------------------------------ */
/* Word (.docx)                                                       */
/* ------------------------------------------------------------------ */

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Formatte une date AAAA-MM-JJ en JJ/MM/AAAA. */
function dateFr(iso?: string): string {
  if (!iso) return '—';
  const p = iso.split('-');
  return p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : iso;
}

function cell(text: string, bold = false, size = 18, center = false): string {
  const t = esc(String(text));
  const b = bold ? '<w:b/>' : '';
  const c = center ? '<w:jc w:val="center"/>' : '';
  return `<w:tc><w:tcPr><w:tcMar><w:top w:w="40" w:type="dxa"/><w:bottom w:w="40" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:jc w:val="left"/>${c}</w:pPr><w:r><w:rPr>${b}<w:sz w:val="${size}"/></w:rPr><w:t xml:space="preserve">${t}</w:t></w:r></w:p></w:tc>`;
}

function heading(text: string, size = 20): string {
  return `<w:p><w:pPr><w:spacing w:before="120" w:after="60"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="${size}"/></w:rPr><w:t xml:space="preserve">${esc(text)}</w:t></w:r></w:p>`;
}

function line(text: string, size = 18): string {
  return `<w:p><w:pPr><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:sz w:val="${size}"/></w:rPr><w:t xml:space="preserve">${esc(text)}</w:t></w:r></w:p>`;
}

function pageBreak(): string {
  return `<w:p><w:r><w:br w:type="page"/></w:r></w:p>`;
}

function bulletinXml(classData: ClassData, b: StudentBulletin): string {
  const secondaire = isSecondaire(classData);
  const row = (label: string, value: string) =>
    `<w:tr><w:tc><w:tcPr><w:tcW w:w="3200" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="18"/></w:rPr><w:t xml:space="preserve">${esc(label)}</w:t></w:r></w:p></w:tc>` +
    `<w:tc><w:tcPr><w:tcW w:w="5000" w:type="dxa"/></w:tcPr><w:p><w:r><w:sz w:val="18"/><w:t xml:space="preserve">${esc(value)}</w:t></w:r></w:p></w:tc></w:tr>`;

  let notesRows = '';
  const headerCells = secondaire
    ? '<w:tr>' + [cell('Matière', true, 18, true), cell('Note /20', true, 18, true), cell('Coef', true, 18, true), cell('Total', true, 18, true)].join('') + '</w:tr>'
    : '<w:tr>' + [cell('Matière', true, 18, true), cell('Note /20', true, 18, true)].join('') + '</w:tr>';

  for (const r of b.results) {
    const val = r.absent ? 'ABS' : r.total !== null ? r.total.toFixed(2) : '—';
    const cells = secondaire
      ? cell(r.subject.name, false, 18) + cell(val, false, 18, true) + cell(String(r.coefficient), false, 18, true) + cell(r.totalObtenu !== null ? r.totalObtenu.toFixed(2) : '—', false, 18, true)
      : cell(r.subject.name, false, 18) + cell(val, false, 18, true);
    notesRows += `<w:tr>${cells}</w:tr>`;
  }

  return `
${heading('RÉPUBLIQUE DU BÉNIN', 18)}
${line(classData.school || 'École', 20)}
${line(`Classe : ${classData.name} • ${classData.schoolYear} • ${classData.sequence}`, 18)}
${line(`Effectif : ${b.effectif} élèves`, 16)}
${heading('BULLETIN DE NOTES', 24)}
${row('Nom & Prénoms', `${b.student.nom.toUpperCase()} ${b.student.prenoms}`)}
${row('Matricule', b.student.matricule || '—')}
${row('Sexe', b.student.sexe === 'M' ? 'Masculin (M)' : b.student.sexe === 'F' ? 'Féminin (F)' : '—')}
${row('Date de naissance', dateFr(b.student.dateNaissance))}
${row('Niveau', classData.serie ? `${classData.level} ${classData.serie}` : classData.level)}
${heading('RÉSULTATS PAR MATIÈRE', 20)}
<w:tbl><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4"/><w:left w:val="single" w:sz="4"/><w:bottom w:val="single" w:sz="4"/><w:right w:val="single" w:sz="4"/></w:tblBorders></w:tblPr>${headerCells}${notesRows}</w:tbl>
${heading(`MOYENNE GÉNÉRALE : ${b.moyenne !== null ? b.moyenne.toFixed(2) : '—'} / 20`, 22)}
${line(`Rang : ${b.rang > 0 ? b.rang + 'ᵉ sur ' + b.effectif : '—'}   •   Mention : ${b.mention}`, 18)}
${line(`Appréciation : ${b.appreciation}`, 18)}
${heading('SIGNATURES', 20)}
${line('Le Directeur / La Directrice                    L\'Enseignant(e)                    Les Parents', 16)}`;
}

export async function exportBulletinsDocx(classData: ClassData, bulletins: StudentBulletin[], filename?: string): Promise<void> {
  const zip = new JSZip();
  zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`);
  zip.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`);

  const body = bulletins
    .map((b, i) => (i > 0 ? pageBreak() : '') + bulletinXml(classData, b))
    .join('');

  zip.file('word/document.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body>${body}
<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/></w:sectPr>
</w:body>
</w:document>`);

  const blob = await zip.generateAsync({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  const safe = classData.school.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
  const cls = classData.name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
  const name = filename || `bulletins_${safe}_${cls}_${classData.sequence.replace(/\s+/g, '')}.docx`.replace(/_+/g, '_');

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.rel = 'noopener';
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    try { document.body.removeChild(link); } catch { /* déjà retiré */ }
    URL.revokeObjectURL(url);
  }, 4000);
}

/* ------------------------------------------------------------------ */
/* Excel (.xlsx)                                                      */
/* ------------------------------------------------------------------ */

export async function exportBulletinsExcel(
  classData: ClassData,
  bulletins: StudentBulletin[],
  filename?: string
): Promise<void> {
  const workbook = new ExcelJS.Workbook();
  const ws = workbook.addWorksheet('Bulletins');

  // En-têtes : N°, Matricule, Nom, Prénoms, Sexe, Naissance + 1 colonne par matière + Moyenne, Rang, Mention, Décision
  const subjects = [...classData.subjects].sort((a, b) => a.order - b.order);
  const headers = ['N°', 'Matricule', 'Nom', 'Prénoms', 'Sexe', 'Naissance', ...subjects.map(s => s.name + ' /20'), 'Moyenne /20', 'Rang', 'Mention', 'Décision'];
  const headerRow = ws.addRow(headers);
  headerRow.eachCell((cell) => {
    cell.font = { bold: true, size: 10, name: 'Arial' };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF006B4F' } };
    cell.font = { bold: true, size: 10, name: 'Arial', color: { argb: 'FFFFFFFF' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
  });

  bulletins.forEach((b, index) => {
    const row = ws.addRow([
      index + 1,
      b.student.matricule || '',
      (b.student.nom || '').toUpperCase(),
      b.student.prenoms || '',
      b.student.sexe === 'M' ? 'M' : b.student.sexe === 'F' ? 'F' : '',
      dateFr(b.student.dateNaissance),
      ...subjects.map((s) => {
        const r = b.results.find((x) => x.subject.id === s.id);
        if (!r || r.absent) return 'ABS';
        return r.total !== null ? Number(r.total.toFixed(2)) : '';
      }),
      b.moyenne !== null ? Number(b.moyenne.toFixed(2)) : null,
      b.rang > 0 ? b.rang : null,
      b.mention || '',
      b.moyenne !== null && b.moyenne >= 10 ? 'Admis(e)' : b.moyenne !== null ? 'Ajourné(e)' : '',
    ]);
    row.eachCell((cell, colNumber) => {
      cell.font = { size: 10, name: 'Arial' };
      cell.alignment = { horizontal: colNumber === 1 || colNumber === 2 ? 'center' : colNumber >= 7 ? 'center' : 'left', vertical: 'middle' };
      cell.border = { top: { style: 'thin' }, bottom: { style: 'thin' }, left: { style: 'thin' }, right: { style: 'thin' } };
    });
    // Matricule en texte (zéros initiaux préservés)
    const matCell = row.getCell(2);
    matCell.numFmt = '@';
  });

  ws.columns.forEach((col, i) => { col.width = i === 3 ? 28 : i === 2 ? 12 : 14; });

  // Feuille Synthèse
  const ws2 = workbook.addWorksheet('Synthèse');
  const stats = computeStats(bulletins);
  const rows2: [string, string | number][] = [
    ['SYNTHÈSE DE CLASSE', ''],
    ['École', classData.school || '—'],
    ['Classe', classData.name],
    ['Année scolaire', classData.schoolYear],
    ['Séquence / Trimestre', classData.sequence],
    ['Effectif total', stats.effectif],
    ['Élèves notés', stats.noted],
    ['Moyenne de classe /20', stats.moyenneClasse !== null ? Number(stats.moyenneClasse.toFixed(2)) : '—'],
    ['Taux de réussite (%)', stats.tauxReussite !== null ? Number(stats.tauxReussite.toFixed(1)) : '—'],
    ['Admis (moyenne ≥ 10)', stats.admis],
    ['Ajournés', stats.ajournes],
    ['Moyenne la plus forte', stats.plusForte !== null ? Number(stats.plusForte.toFixed(2)) : '—'],
    ['Moyenne la plus faible', stats.plusFaible !== null ? Number(stats.plusFaible.toFixed(2)) : '—'],
    ['', ''],
    ['Mentions', ''],
    ['Excellent (≥ 18)', stats.mentions.Excellent],
    ['Très Bien (16-17.99)', stats.mentions['Très Bien']],
    ['Bien (14-15.99)', stats.mentions.Bien],
    ['Assez Bien (12-13.99)', stats.mentions['Assez Bien']],
    ['Passable (10-11.99)', stats.mentions.Passable],
    ['Insuffisant (8-9.99)', stats.mentions.Insuffisant],
    ['Faible (< 8)', stats.mentions.Faible],
  ];
  rows2.forEach(([label, value]) => {
    const row = ws2.addRow([label, value]);
    row.eachCell((cell, col) => {
      cell.font = { size: 11, name: 'Arial', bold: col === 1 && ['SYNTHÈSE DE CLASSE', 'Mentions'].includes(label) };
      if (!['SYNTHÈSE DE CLASSE', 'Mentions'].includes(label)) {
        cell.border = { top: { style: 'hair' }, bottom: { style: 'hair' } };
      }
    });
  });
  ws2.columns = [{ width: 40 }, { width: 16 }];
  ws2.getCell('A1').font = { bold: true, size: 14, color: { argb: 'FF006B4F' } };

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const safe = classData.school.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
  const cls = classData.name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
  const name = filename || `bulletins_recap_${safe}_${cls}_${classData.sequence.replace(/\s+/g, '')}.xlsx`.replace(/_+/g, '_');

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.rel = 'noopener';
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    try { document.body.removeChild(link); } catch { /* déjà retiré */ }
    URL.revokeObjectURL(url);
  }, 4000);
}

function computeStats(bulletins: StudentBulletin[]) {
  const withMoy = bulletins.filter((b) => b.moyenne !== null);
  const effectif = bulletins.length;
  const noted = withMoy.length;
  const moyenneClasse = noted > 0 ? withMoy.reduce((s, b) => s + (b.moyenne ?? 0), 0) / noted : null;
  const admis = withMoy.filter((b) => (b.moyenne ?? 0) >= 10).length;
  const ajournes = noted - admis;
  const tauxReussite = noted > 0 ? (admis / noted) * 100 : null;
  const plusForte = noted > 0 ? Math.max(...withMoy.map((b) => b.moyenne ?? 0)) : null;
  const plusFaible = noted > 0 ? Math.min(...withMoy.map((b) => b.moyenne ?? 0)) : null;
  const mentions: Record<string, number> = {
    Excellent: 0, 'Très Bien': 0, Bien: 0, 'Assez Bien': 0, Passable: 0, Insuffisant: 0, Faible: 0,
  };
  withMoy.forEach((b) => { if (b.mention && mentions[b.mention] !== undefined) mentions[b.mention]++; });
  return { effectif, noted, moyenneClasse, admis, ajournes, tauxReussite, plusForte, plusFaible, mentions };
}
