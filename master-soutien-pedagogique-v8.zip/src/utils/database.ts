import { openDB, DBSchema, IDBPDatabase } from 'idb';

export interface Student {
  id: string;
  matricule: string;
  nom: string;
  prenoms: string;
  sexe?: 'M' | 'F';
  dateNaissance?: string; // format AAAA-MM-JJ
  photoUrl?: string;
  weightKg?: number;
  heightCm?: number;
  createdAt: number;
}

export interface Subject {
  id: string;
  name: string;
  noteObtenueMax: number; // Primaire: Critères minimaux (CM) /18 — Secondaire: Note obtenue /20
  notePerfectionnementMax: number; // Primaire: Note de perfectionnement (CP) /2 — Secondaire: 0 (non utilisé)
  coefficient?: number; // Secondaire uniquement : coefficient de la matière (défaut 1)
  order: number;
}

export interface Note {
  id: string;
  studentId: string;
  subjectId: string;
  noteObtenue: number | null;
  notePerfectionnement: number | null;
  absent: boolean;
  updatedAt: number;
}

export type EducationType = 'prescolaire' | 'primaire' | 'secondaire';

export type PrescolaireLevel = 'Maternelle 1' | 'Maternelle 2';
export type PrimaryLevel = 'CI' | 'CP' | 'CE1' | 'CE2' | 'CM1' | 'CM2';
export type SecondaryLevel = '6ème' | '5ème' | '4ème' | '3ème' | '2nde' | '1ère' | 'Tle';
export type SecondarySerie = 'A1' | 'A2' | 'B' | 'C' | 'D';

export interface ClassData {
  id: string;
  name: string;
  school: string;
  circonscription?: string;
  level: string; // Primaire: CI..CM2 — Secondaire: 6ème..Tle
  educationType?: EducationType; // défaut 'primaire' (compatibilité anciennes classes)
  serie?: SecondarySerie; // Secondaire second cycle uniquement
  schoolYear: string;
  sequence: string;
  students: Student[];
  subjects: Subject[];
  notes: Note[];
  createdAt: number;
  updatedAt: number;
}

interface NoteFacileDB extends DBSchema {
  classes: {
    key: string;
    value: ClassData;
  };
}

let db: IDBPDatabase<NoteFacileDB> | null = null;

export async function getDB(): Promise<IDBPDatabase<NoteFacileDB>> {
  if (db) return db;
  
  db = await openDB<NoteFacileDB>('NoteFacileBenin', 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('classes')) {
        db.createObjectStore('classes', { keyPath: 'id' });
      }
    },
  });
  
  return db;
}

export async function getAllClasses(): Promise<ClassData[]> {
  const database = await getDB();
  return database.getAll('classes');
}

export async function getClass(id: string): Promise<ClassData | undefined> {
  const database = await getDB();
  return database.get('classes', id);
}

export async function saveClass(classData: ClassData): Promise<void> {
  const database = await getDB();
  classData.updatedAt = Date.now();
  await database.put('classes', classData);
}

export async function deleteClass(id: string): Promise<void> {
  const database = await getDB();
  await database.delete('classes', id);
}

export async function exportAllData(): Promise<string> {
  const database = await getDB();
  const classes = await database.getAll('classes');
  return JSON.stringify({
    version: 2,
    exportDate: new Date().toISOString(),
    classes,
    extraLocalData: exportExtraLocalData(),
  }, null, 2);
}

export async function importAllData(jsonData: string): Promise<void> {
  const database = await getDB();
  const data = JSON.parse(jsonData);
  
  if (!data.classes || !Array.isArray(data.classes)) {
    throw new Error('Format de fichier invalide');
  }
  
  for (const classData of data.classes) {
    await database.put('classes', classData);
  }

  if (data.extraLocalData && typeof data.extraLocalData === 'object') {
    importExtraLocalData(data.extraLocalData);
  }
}

export async function clearAllData(): Promise<void> {
  const database = await getDB();
  const tx = database.transaction('classes', 'readwrite');
  await tx.objectStore('classes').clear();
  await tx.done;
  clearExtraLocalData();
}

const EXTRA_BACKUP_KEYS = [
  'msp_pedagogical_tools',
  'msp_fiches_pedagogiques',
  'msp_fiches_planning',
  'msp_fiches_emploi_temps',
  'msp_attendance_records',
  'msp_correspondence_notes',
  'msp_school_calendar_events',
  'msp_activity_events',
  'msp_admin_documents',
  'msp_admin_tasks',
  'msp_teacher_toolkit_inventory',
  'msp_enrollment_records',
  'msp_marketplace_courses',
  'msp_profile',
];

function exportExtraLocalData(): Record<string, string> {
  const data: Record<string, string> = {};
  for (const key of EXTRA_BACKUP_KEYS) {
    const value = localStorage.getItem(key);
    if (value !== null) data[key] = value;
  }
  return data;
}

function importExtraLocalData(data: Record<string, string>): void {
  for (const key of EXTRA_BACKUP_KEYS) {
    if (typeof data[key] === 'string') localStorage.setItem(key, data[key]);
  }
}

function clearExtraLocalData(): void {
  for (const key of EXTRA_BACKUP_KEYS) localStorage.removeItem(key);
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Trie les élèves par ordre alphabétique du NOM, puis des Prénoms.
 * Respecte l'ordre alphabétique français (accents gérés) et ignore la casse,
 * afin d'être identique à l'ordre du fichier modèle EducMaster.
 */
/** Indique si une classe relève de l'enseignement secondaire. */
export function isSecondaire(classData: ClassData): boolean {
  return classData.educationType === 'secondaire';
}

export function sortStudents(students: Student[]): Student[] {
  const collator = new Intl.Collator('fr', { sensitivity: 'base', numeric: true });
  return [...students].sort((a, b) => {
    const byNom = collator.compare(a.nom || '', b.nom || '');
    if (byNom !== 0) return byNom;
    return collator.compare(a.prenoms || '', b.prenoms || '');
  });
}

export function getDefaultSubjectsForLevel(_level: string): Subject[] {
  // Noms conformes EXACTEMENT au modèle officiel EducMaster (Notes - CE1)
  const baseSubjects: Omit<Subject, 'id' | 'order'>[] = [
    { name: 'Dictée', noteObtenueMax: 18, notePerfectionnementMax: 2 },
    { name: 'Math', noteObtenueMax: 18, notePerfectionnementMax: 2 },
    { name: 'Expresion écrite', noteObtenueMax: 18, notePerfectionnementMax: 2 },
    { name: 'Compréhension de l\'écrit', noteObtenueMax: 18, notePerfectionnementMax: 2 },
    { name: 'EST', noteObtenueMax: 18, notePerfectionnementMax: 2 },
    { name: 'ES', noteObtenueMax: 18, notePerfectionnementMax: 2 },
    { name: 'EA (Oral)', noteObtenueMax: 18, notePerfectionnementMax: 2 },
    { name: 'EA (Déssin/Couture)', noteObtenueMax: 18, notePerfectionnementMax: 2 },
    { name: 'EPS', noteObtenueMax: 18, notePerfectionnementMax: 2 },
  ];
  
  return baseSubjects.map((subject, index) => ({
    ...subject,
    id: generateId(),
    order: index,
  }));
}

/**
 * Matières par défaut pour l'enseignement SECONDAIRE.
 * Système : Note obtenue /20, Coefficient (modifiable), Total obtenu, Total possible.
 * Le coefficient par défaut est 1 (l'enseignant le modifie selon la matière/série).
 */
export function getDefaultSubjectsForSecondary(
  level: SecondaryLevel,
  serie?: SecondarySerie
): Subject[] {
  let names: string[];

  const isSecondCycle = level === '2nde' || level === '1ère' || level === 'Tle';

  if (!isSecondCycle) {
    // Premier cycle : 6ème, 5ème, 4ème, 3ème
    names = [
      'Communication écrite',
      'Lecture',
      'Mathématiques',
      'PCT',
      'Allemand ou Espagnol',
      'Histoire-Géographie',
      'Anglais',
      'SVT',
      'EPS',
      'Conduite',
    ];
  } else if (serie === 'C' || serie === 'D') {
    // Séries scientifiques C et D
    names = [
      'Français',
      'Mathématiques',
      'PCT',
      'Histoire-Géographie',
      'Anglais',
      'Philosophie',
      'SVT',
      'EPS',
      'Conduite',
    ];
  } else {
    // Séries littéraires A1, A2 et B
    names = [
      'Français',
      'Mathématiques',
      'LV1',
      'Histoire-Géographie',
      'LV2',
      'SVT',
      'Philosophie',
      'EPS',
      'Conduite',
    ];
    // La série B ajoute l'Économie
    if (serie === 'B') {
      names.splice(names.indexOf('Philosophie'), 0, 'Economie');
    }
  }

  return names.map((name, index) => ({
    id: generateId(),
    name,
    noteObtenueMax: 20, // Note obtenue sur 20
    notePerfectionnementMax: 0, // non utilisé au secondaire
    coefficient: 1, // modifiable par l'enseignant
    order: index,
  }));
}

/**
 * Matières / domaines d'activités par défaut pour le PRÉSCOLAIRE
 * (Maternelle 1 et Maternelle 2).
 * L'évaluation au préscolaire se fait par appréciation (Acquis / En cours / Non acquis),
 * mais pour rester cohérent avec l'application on garde une note obtenue /10
 * simple, sans perfectionnement. Modifiable par l'enseignant.
 */
export function getDefaultSubjectsForPrescolaire(_level: string): Subject[] {
  const domaines: string[] = [
    'Langage et communication',
    'Activités mathématiques (pré-maths)',
    'Motricité (globale et fine)',
    'Activités artistiques (dessin, chant)',
    'Éveil et découverte du monde',
    'Vie sociale et autonomie',
    'Jeux éducatifs',
  ];

  return domaines.map((name, index) => ({
    id: generateId(),
    name,
    noteObtenueMax: 10, // note simple sur 10
    notePerfectionnementMax: 0, // non utilisé au préscolaire
    order: index,
  }));
}
