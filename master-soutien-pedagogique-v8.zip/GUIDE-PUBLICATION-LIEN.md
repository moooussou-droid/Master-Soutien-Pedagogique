# 🔗 Master Soutien Pédagogique — Obtenir le lien de l'application

Votre application est **construite et prête** dans le dossier `dist/`.
Pour obtenir un **lien partageable** (ex. `https://master-soutien.netlify.app`), suivez l'une de ces méthodes gratuites. C'est rapide (2 à 5 minutes).

---

## ✅ Méthode 1 — Netlify Drop (LA PLUS RAPIDE, sans compte)

1. Ouvrez ce lien sur votre ordinateur : **https://app.netlify.com/drop**
2. **Glissez-déposez le dossier `dist/`** dans la zone indiquée
3. Netlify génère immédiatement un lien du type :
   `https://nom-aleatoire-12345.netlify.app`
4. (Optionnel) Créez un compte gratuit pour **renommer** le lien en
   `https://master-soutien-pedagogique.netlify.app`
5. **Partagez ce lien** par WhatsApp à tous les enseignants ! 🎉

> 💡 Chaque enseignant ouvre le lien puis fait « Ajouter à l'écran d'accueil » pour l'installer comme une application.

---

## ✅ Méthode 2 — Vercel (recommandée pour un lien permanent)

1. Créez un compte gratuit sur **https://vercel.com**
2. Cliquez sur **Add New → Project**
3. Importez le projet (ou glissez le dossier `dist/`)
4. Vercel vous donne un lien du type
   `https://master-soutien-pedagogique.vercel.app`

> C'est le même service que celui utilisé par l'application MasterNotePro d'origine.

---

## ✅ Méthode 3 — GitHub Pages

1. Créez un dépôt sur **https://github.com**
2. Envoyez-y le contenu du dossier `dist/`
3. Activez **Settings → Pages → Deploy from branch**
4. Votre lien : `https://votre-nom.github.io/master-soutien/`

---

## 📱 Méthode 4 — Créer un APK Android (fichier installable)

Pour distribuer un vrai fichier `.apk` :

1. Publiez d'abord l'app en ligne (Méthode 1 ou 2) pour obtenir un lien `https`
2. Allez sur **https://www.pwabuilder.com**
3. Collez votre lien → **Build My PWA** → **Android** → téléchargez l'APK
4. Partagez le fichier `.apk` par WhatsApp

---

## 📦 Rappel : où est l'application ?

- Dossier **`dist/`** → contient toute l'application
- Fichier principal : **`dist/index.html`** (tout est intégré dedans)

## 📞 Contact intégré

Toute l'application dirige vers votre WhatsApp unique :
**+229 63 26 13 82**
(Support, annonces, publicités, partage de bulletins…)

---

**Master Soutien Pédagogique** — Notes, bulletins & accompagnement 🇧🇯
