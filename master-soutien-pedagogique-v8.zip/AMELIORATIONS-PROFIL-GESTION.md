# Améliorations — Profil, Admin, Réglages & Gestion de classe

**Version livrée : v7 — Master Soutien Pédagogique** · Suite de tests : **172/172** · Build de production : ✅

Cette version regroupe **6 améliorations** issues de vos demandes sur deux modules :
« Profil, Admin & Réglages » et « Gestion de classe ».

---

## 1. Profil enrichi — circonscription & commune 📍

### Ce qui a changé
- Le profil enseignant comporte maintenant **2 nouveaux champs** : **Circonscription pédagogique** et **Commune**.
- Ces informations sont **reprises automatiquement** partout où l'établissement doit apparaître :

| Document | Reprise |
|---|---|
| 🎓 **Bulletins de notes** | « Circonscription pédagogique de … » (si la classe n'a pas sa propre valeur) |
| ✉️ **Courriers aux parents (Word)** | Nouvelle ligne officielle « Commune : … » sous la circonscription |
| 📋 **PV de conseil / présences (Word)** | Circonscription reprise du profil en secours |
| 📝 **Fiche élève** | inchangée (école + logo) |

### Comment l'utiliser
1. Menu **Profil** → renseignez **Circonscription** et **Commune**.
2. Rien d'autre à faire : les bulletins, courriers et PV l'utilisent automatiquement.

---

## 2. Réglages — téléchargement mobile corrigé + carte « Stockage & Cloud » 📦

### Bug corrigé : téléchargements interrompus sur Android
Certains navigateurs mobiles (surtout **Android**) annulaient le téléchargement de la sauvegarde parce que l'adresse temporaire du fichier (`URL.createObjectURL`) était libérée **immédiatement** après le clic. L'adresse est désormais libérée **4 secondes après** le téléchargement, le temps que le navigateur finisse de récupérer le fichier.

### Nouvelle carte « Stockage & Cloud » dans Réglages
Un nouvel écran affiche en un coup d'œil l'état de vos données :

- 📚 **Nombre de classes** enregistrées sur l'appareil
- 💾 **Taille du stockage local** (Ko) et la part du **quota navigateur** utilisée (`navigator.storage.estimate`)
- ☁️ **Statut du cloud** : disponible à la sauvegarde automatique ou non
- 🕐 **Dernière synchronisation** réussie avec le serveur

---

## 3. Admin — journal local des codes générés 🔑

### Ce qui a changé
- Chaque **code d'accès généré** est maintenant consigné dans un **journal local** de l'appareil (`msp_admin_codes_log`, 100 dernières entrées maximum).
- **Fonctionne même sans internet** : la trace reste consultable si le cloud est hors service.

### Interface Admin
- Liste des derniers codes : **nom**, **code**, **date** de génération.
- Bouton **📋 copier** le code (presse-papiers) et **💬 WhatsApp** pour envoyer le code au parent/enseignant en un clic.
- Bouton **Tout effacer** pour vider le journal.
- La **révocation à distance** n'est possible que lorsque la validation serveur est active (rappel affiché sous le journal).

---

## 4. Boîte à outils — calculatrice de moyenne pondérée Σ

### Ce qui a changé
Nouvel **onglet « Moyenne »** dans la Boîte à outils enseignant.

- Saisissez autant de lignes que voulu : **matière · note · barème · coefficient**.
- **Barèmes variés acceptés** : la calculatrice ramène chaque note sur **/20** (ex. 8/10 = 16/20), puis applique le **coefficient**.
- Alternative décimales avec **virgule** : « 12,5 » fonctionne.
- Les lignes vides ou invalides (coefficient 0) sont ignorées automatiquement.
- Résultat en direct : **moyenne pondérée /20** + **mention officielle** (Excellent, Très Bien, Bien, Assez Bien, Passable, Insuffisant, Faible).

**Exemple** : 15/20 (coef 2) + 10/20 (coef 1) → **13.33/20 — Assez Bien**.

---

## 5. Enrôlement — tableau de bord filles / garçons 👧👦

### Ce qui a changé
En haut de l'écran d'enrôlement, un **tableau de bord** affiche désormais :

- 🔢 **Total des élèves enrôlés**
- 👧 **Nombre de filles** (sexe « F »)
- 👦 **Nombre de garçons** (sexe « M »)

Le champ **Sexe** étant déjà collecté à l'inscription et exporté (Excel/CSV), les compteurs se mettent à jour **instantanément** et restent **cohérents** avec les statistiques de la classe.

---

## 6. Documents de classe — Télécharger & Imprimer 🖨️

### Ce qui a changé
La **visionneuse de documents** (programme, planification…) propose maintenant deux boutons :

- ⬇️ **Télécharger** : enregistre le document sur l'appareil avec son **nom d'origine** (`.pdf`, `.docx`…). Petit rappel du correctif n°2 : l'URL est libérée après un délai, donc le téléchargement fonctionne aussi sur **Android**.
- 🖨️ **Imprimer** :
  - **PDF** → ouverture dans le navigateur, avec impression automatique (bouton ou Ctrl+P possible).
  - **Document texte extrait** (DOCX converti) → impression **mise en page propre** (papier sans marges parasites).

---

## Fichiers modifiés

| Fichier | Modification |
|---|---|
| `src/utils/userProfile.ts` | + `circonscription`, `commune` |
| `src/components/ProfileScreen.tsx` | champs Circonscription / Commune |
| `src/components/BulletinsScreen.tsx` | fallback circonscription du profil |
| `src/components/CorrespondenceScreen.tsx` | passe circonscription/commune au Word |
| `src/utils/correspondenceExport.ts` | + `commune`, ligne « Commune : … » |
| `src/utils/attendanceExport.ts` | fallback circonscription du profil (PV) |
| `src/App.tsx` | téléchargement mobile + carte Stockage & Cloud |
| `src/components/AdminScreen.tsx` | journal local des codes générés |
| `src/components/TeacherToolkitScreen.tsx` | **+ onglet Moyenne (pondérée)** |
| `src/utils/average.ts` | **+ calcul moyenne pondérée** |
| `src/components/EnrollmentScreen.tsx` | **+ stats filles/garçons/total** |
| `src/components/ClassDocumentsScreen.tsx` | **+ Télécharger / Imprimer** |
| `tests/audit.ts` | **+ sections 17, 18, 19** (37 nouveaux tests) |
| `public/sw.js` | cache → **v10** |

---

*Toutes les fonctions existantes restent inchangées : rien n'a été réécrit, uniquement enrichi. Les tests précédents (135) passent toujours, 37 nouveaux tests ont été ajoutés.*
