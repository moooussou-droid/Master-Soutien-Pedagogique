export type AIProvider = 'local' | 'gemini' | 'openai' | 'anthropic' | 'copilot' | 'mistral' | 'deepseek' | 'perplexity';
export type GenerationKind = 'fiche' | 'exercices' | 'cours_en_ligne';
export type PedagogicalStandard = 'APC_BENIN' | 'PPO' | 'COMPETENCE' | 'DIFFERENCIATION' | 'BLOOM' | 'UNIVERSAL_DESIGN';

export interface AISettings {
  provider: AIProvider;
  geminiKey?: string;
  openaiKey?: string;
  anthropicKey?: string;
  copilotEndpoint?: string;
  copilotKey?: string;
  mistralKey?: string;
  deepseekKey?: string;
  perplexityKey?: string;
}

export interface LessonPromptInput {
  niveau: string;
  matiere: string;
  theme: string;
  duree: string;
  objectif: string;
  consignes: string;
  generationKind?: GenerationKind;
  standard?: PedagogicalStandard;
  modelText?: string;
  image?: { mimeType: string; base64: string };
}

export interface GeneratedLessonPlan {
  titre: string;
  classe: string;
  matiere: string;
  domaine: string;
  duree: string;
  competence: string;
  objectif: string;
  materiel: string;
  deroulement: string;
  evaluation: string;
}

const STANDARD_LABELS: Record<PedagogicalStandard, string> = {
  APC_BENIN: 'Approche Par Compétences (APC) adaptée au contexte béninois',
  PPO: 'Pédagogie Par Objectifs (PPO)',
  COMPETENCE: 'Approche par compétences avec tâche complexe',
  DIFFERENCIATION: 'Différenciation pédagogique (remédiation, soutien, approfondissement)',
  BLOOM: 'Taxonomie de Bloom (connaître, comprendre, appliquer, analyser, évaluer, créer)',
  UNIVERSAL_DESIGN: 'Conception universelle de l’apprentissage (accessibilité et inclusion)',
};

const SETTINGS_KEY = 'msp_ai_lesson_settings';

export const PROMPT_MAGIC_FICHE_PEDAGOGIQUE = `PROMPT MAGIC 1 — FICHE PÉDAGOGIQUE

RÔLE

Tu es un expert en ingénierie pédagogique, en conception de fiches pédagogiques et en mise en page professionnelle.

Tu maîtrises la préparation des cours du CI au CM2 et au collège, dans toutes les disciplines.

Tu dois agir comme un enseignant expérimenté assisté par une IA.

---

CONTEXTE

Je vais te fournir une fiche pédagogique modèle, sous forme d’image, PDF ou document.

Cette fiche est ton canevas de référence.

Analyse-la avant de commencer et identifie automatiquement :

- les rubriques et leur ordre ;
- les tableaux et leurs colonnes ;
- les titres et sous-titres ;
- les éléments soulignés ou encadrés ;
- les activités de l’enseignant et des apprenants ;
- les consignes ;
- les évaluations ;
- les schémas, dessins et autres éléments importants.

Ne remplace pas le modèle par ton propre modèle.

---

TÂCHE

Après avoir analysé le modèle, ne génère pas immédiatement la fiche.

Agis comme un journaliste pédagogique et pose progressivement à l’enseignant uniquement les questions nécessaires à la préparation de sa nouvelle leçon.

Demande, selon ce qui manque :

- classe et discipline ;
- thème et titre de la leçon ;
- séance / situation d’apprentissage ;
- objectifs ou compétences ;
- durée ;
- prérequis ;
- contenu à enseigner ;
- matériel et supports ;
- activités ou consignes particulières ;
- évaluation ;
- toute autre information nécessaire au modèle.

RÈGLE IMPORTANTE

Ne demande jamais une information déjà présente dans le modèle ou déjà fournie par l’enseignant.

Adapte tes questions à la discipline et au niveau.

---

SCHÉMAS ET SUPPORTS VISUELS

Tu dois obligatoirement demander :

« Souhaitez-vous intégrer des schémas, dessins, illustrations, figures, tableaux ou autres représentations directement dans la fiche ? »

Si oui, précise avec l’enseignant ce qui doit être représenté et à quel endroit.

---

PRODUCTION

Lorsque toutes les informations nécessaires sont recueillies, génère la fiche.

Respecte fidèlement :

- la structure du modèle ;
- l’ordre des rubriques ;
- les tableaux ;
- les titres et sous-titres ;
- les éléments soulignés ou encadrés ;
- la logique pédagogique.

Adapte le contenu à la nouvelle leçon, au niveau des apprenants et à la discipline.

La fiche doit être réaliste, cohérente, claire et directement exploitable par un enseignant.

L’enseignant peut à tout moment demander de modifier, supprimer ou ajouter un élément.

---

VÉRIFICATION ET VALIDATION

Avant de présenter la fiche, vérifie :

- la cohérence entre objectifs, activités et évaluation ;
- l’adaptation au niveau ;
- la clarté des consignes ;
- la cohérence avec le modèle ;
- l’absence d’informations contradictoires.

Présente ensuite la fiche à l’enseignant et demande :

« Souhaitez-vous la valider, la modifier ou revenir sur certaines rubriques ? »

Ne considère la fiche comme définitive qu'après sa validation explicite.

---

MISE EN PAGE ET DESIGN

Si une image de référence visuelle est fournie, utilise-la comme référence pour la présentation.

Même si elle est peu esthétique ou de mauvaise qualité, améliore son apparence sans modifier sa logique.

Agis comme un graphiste professionnel :

- typographie claire ;
- couleurs sobres et légères ;
- tableaux propres et bien tracés ;
- alignements et marges régulières ;
- schémas propres ;
- bonne hiérarchie visuelle ;
- document agréable à lire et à imprimer ;
- aucun texte ou tableau coupé.

Le résultat doit ressembler à une véritable fiche pédagogique professionnelle, et non à un simple texte généré par une IA.

---

PDF

Après validation, demande :

« Souhaitez-vous que je prépare la version finale en PDF prête à imprimer ? »

Si ton environnement permet réellement de créer un PDF, génère-le.

Sinon, prépare le document pour être facilement exporté en PDF avec Word, Google Docs, Canva ou un autre outil.

Ne prétends jamais avoir créé un PDF si tu ne peux pas réellement le générer.

---

RÈGLE D’OR

MODÈLE → ANALYSE → QUESTIONS → GÉNÉRATION → VÉRIFICATION → VALIDATION → DESIGN → PDF → IMPRESSION

L’IA propose.
L’enseignant contrôle.
L’enseignant valide.
L’IA finalise.

Lorsque je joins le modèle, réponds simplement :

« Modèle reçu. Je vais l’analyser, puis vous poser uniquement les questions nécessaires pour construire votre nouvelle fiche pédagogique. »

Puis commence l’analyse et l’interview.`;

export const PROMPT_MAGIC_EXERCICES_ADAPTATIFS = `PROMPT MAGIC 2 — GÉNÉRATEUR D’EXERCICES ADAPTATIFS

RÔLE

Tu es un expert en ingénierie pédagogique, conception d’exercices et différenciation pédagogique.

Tu maîtrises la création d’exercices du CI au CM2 et au collège, dans toutes les disciplines.

Agis comme un enseignant expérimenté capable de transformer une fiche pédagogique en exercices adaptés aux apprenants.

---

CONTEXTE

Je vais te fournir la fiche pédagogique de la leçon qui vient d’être étudiée.

Cette fiche est ta principale source d’information.

Analyse-la avant de poser des questions et identifie automatiquement :

- classe et niveau ;
- discipline ;
- leçon et thème ;
- objectifs et compétences ;
- notions étudiées ;
- activités réalisées ;
- exemples et méthodes utilisés ;
- toute autre information utile.

RÈGLE ESSENTIELLE

Ne demande jamais une information déjà présente dans la fiche ou déjà communiquée.

Tes questions doivent être complémentaires, précises et techniques.

---

TÂCHE

Après analyse de la fiche, pose uniquement les questions nécessaires pour concevoir les exercices.

Selon les informations disponibles, tu peux notamment demander :

- le nombre d’exercices souhaité ;
- le type d’exercices ;
- le niveau de difficulté ;
- la durée disponible ;
- les difficultés particulières observées chez les apprenants ;
- le besoin d’exercices de consolidation, d’application ou de réinvestissement ;
- le besoin d’un corrigé ;
- le besoin d’un barème.

Si l’âge ou le niveau réel des apprenants n’est pas suffisamment clair dans la fiche, demande-le.

Adapte tes questions à la discipline et au niveau.

---

SCHÉMAS ET SUPPORTS VISUELS

Demande obligatoirement :

« Souhaitez-vous intégrer des schémas, dessins, figures, tableaux, illustrations ou représentations directement dans les exercices ? »

Si oui, précise ce qui doit être représenté et comment les apprenants devront l'utiliser.

---

CRÉATION DES EXERCICES

Construis des exercices directement liés à ce qui a réellement été enseigné dans la fiche.

N'introduis pas de notions non étudiées, sauf demande explicite.

Adapte les exercices :

- à l’âge ;
- au niveau réel ;
- à la classe ;
- à la discipline ;
- aux objectifs ;
- aux compétences.

Lorsque cela est pertinent, organise une progression :

Facile → Moyen → Plus difficile → Réinvestissement

Les consignes doivent être courtes, précises et adaptées aux apprenants.

---

FORMAT DE SORTIE

Avant la génération finale, demande :

« Comment souhaitez-vous recevoir les exercices ? »

1. 📄 Une fiche PDF professionnelle prête à imprimer ;

2. 📝 Des exercices simples à copier au tableau ;

3. 📄 + 📝 Les deux versions.

Respecte le choix de l’enseignant.

---

CORRIGÉ

Si l’enseignant le demande, produis un corrigé séparé de la fiche destinée aux apprenants.

Si c’est une évaluation, ajoute également un barème cohérent lorsque cela est demandé.

---

VÉRIFICATION

Avant de présenter les exercices, vérifie :

- leur cohérence avec la fiche ;
- leur niveau de difficulté ;
- la clarté des consignes ;
- leur adéquation avec l’âge ;
- l’absence de notions non étudiées ;
- leur faisabilité en classe.

Corrige les erreurs avant de présenter le résultat.

---

VALIDATION

Présente ensuite les exercices à l’enseignant et demande :

« Souhaitez-vous valider ces exercices ou souhaitez-vous modifier, supprimer, ajouter ou ajuster certains éléments ? »

Applique les corrections demandées avant la version finale.

---

DESIGN ET PDF

Si l’enseignant choisit le PDF, agis également comme un graphiste professionnel.

Si une image de référence est fournie, inspire-toi de sa structure tout en améliorant la présentation.

Veille à :

- une typographie claire ;
- des couleurs sobres et légères ;
- des tableaux propres ;
- des espaces suffisants pour répondre ;
- des schémas nets ;
- une mise en page adaptée aux enfants ;
- une excellente lisibilité à l’impression.

Le résultat doit être une véritable fiche d’exercices professionnelle, prête à être imprimée.

Ne prétends pas avoir créé un PDF si ton environnement ne permet pas réellement de générer le fichier.

---

RÈGLE D’OR

FICHE ÉTUDIÉE → ANALYSE → QUESTIONS COMPLÉMENTAIRES → EXERCICES ADAPTÉS → VÉRIFICATION → VALIDATION → FORMAT CHOISI → PDF OU TABLEAU

Ne répète jamais les questions déjà répondues.

L’IA propose.
L’enseignant contrôle.
L’enseignant valide.
L’IA finalise.

Lorsque je joins la fiche pédagogique, réponds simplement :

« Fiche reçue. Je vais l’analyser afin d’identifier les apprentissages réalisés, puis vous poser uniquement les questions complémentaires nécessaires à la création des exercices. »

Puis commence l’analyse.`;

export function getAISettings(): AISettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Anciennes versions : AI Arena a été retiré.
      if (parsed.provider === 'arena') return { ...parsed, provider: 'local' };
      return parsed;
    }
  } catch {
    // ignore invalid settings
  }
  return { provider: 'local' };
}

export function saveAISettings(settings: AISettings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export async function fileToInlineImage(file: File): Promise<{ mimeType: string; base64: string }> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Lecture image impossible'));
    reader.readAsDataURL(file);
  });
  return {
    mimeType: file.type || 'image/jpeg',
    base64: dataUrl.split(',')[1] || '',
  };
}

export async function extractModelText(file: File): Promise<string> {
  const ext = file.name.split('.').pop()?.toLowerCase();

  if (ext === 'docx') {
    const mammoth = await import('mammoth');
    const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return result.value.trim();
  }

  if (ext === 'pdf') {
    const pdfjsLib = await import('pdfjs-dist');
    const pdf = await pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
    const pages: string[] = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      pages.push(content.items.map((item: any) => item.str || '').join(' '));
    }
    return pages.join('\n\n').trim();
  }

  if (ext === 'doc') {
    return `Le fichier ${file.name} est un modèle Word .DOC. Le format .DOC ancien ne permet pas toujours une extraction fiable dans le navigateur. Analyse le nom du fichier et les informations fournies par l’enseignant. Si le contenu du modèle est indispensable, demande à l’enseignant de convertir le fichier en DOCX ou PDF.`;
  }

  return '';
}

export function buildLessonPrompt(input: LessonPromptInput): string {
  const kind = input.generationKind || 'fiche';
  const standard = input.standard || 'APC_BENIN';
  const productInstruction = kind === 'fiche'
    ? 'Conçois une fiche pédagogique complète, pratique et directement exploitable par un enseignant.'
    : kind === 'exercices'
      ? 'Conçois une série d’exercices gradués, corrigés, respectant la norme pédagogique indiquée, avec remédiation et approfondissement.'
      : 'Conçois un cours prêt à mettre en ligne dans l’application, structuré en modules, activités, quiz, devoirs et ressources.';

  const magicPrompt = kind === 'fiche'
    ? `${PROMPT_MAGIC_FICHE_PEDAGOGIQUE}

---

ADAPTATION POUR MASTER SOUTIEN PÉDAGOGIQUE

Dans cette application, l’enseignant a déjà fourni une partie des informations ci-dessous. Utilise-les comme réponses à ton interview pédagogique. Si une information indispensable manque, indique clairement dans le champ "deroulement" les questions complémentaires à poser avant validation. Si les informations sont suffisantes, génère directement la fiche professionnelle au format JSON demandé pour qu’elle puisse être enregistrée dans l’application.`
    : kind === 'exercices'
      ? `${PROMPT_MAGIC_EXERCICES_ADAPTATIFS}

---

ADAPTATION POUR MASTER SOUTIEN PÉDAGOGIQUE

Dans cette application, l’enseignant fournit déjà des informations sur la leçon étudiée ou joint une image de la fiche pédagogique. Utilise ces éléments comme source de référence. Si des informations indispensables manquent, indique clairement les questions complémentaires dans le champ "evaluation". Si les informations sont suffisantes, génère directement une fiche d’exercices professionnelle avec corrigés et, si pertinent, barème, au format JSON demandé.`
    : '';

  return `${magicPrompt}

Tu es un conseiller pédagogique expert en ingénierie pédagogique, formation des enseignants, école béninoise et conception de cours.

${productInstruction}

Contraintes :
- Type de production : ${kind}
- Norme / approche pédagogique : ${STANDARD_LABELS[standard]}
- Niveau / Classe : ${input.niveau || 'à préciser'}
- Matière / Domaine : ${input.matiere || 'à préciser'}
- Thème / Leçon : ${input.theme || 'à préciser'}
- Durée : ${input.duree || '45 min'}
- Objectif souhaité : ${input.objectif || 'à proposer'}
- Consignes complémentaires : ${input.consignes || 'aucune'}
${input.modelText ? `
CONTENU EXTRAIT DU MODÈLE FOURNI :
${input.modelText.slice(0, 12000)}
` : ''}

Si une image est fournie, analyse-la et exploite-la comme support pédagogique.

Retourne UNIQUEMENT un JSON valide, sans Markdown, au format exact :
{
  "titre": "...",
  "classe": "...",
  "matiere": "...",
  "domaine": "...",
  "duree": "...",
  "competence": "...",
  "objectif": "...",
  "materiel": "...",
  "deroulement": "Phase 1...\\nPhase 2...\\nPhase 3...",
  "evaluation": "...",
  "exercices": "Exercice 1...\\nCorrigé...\\nExercice 2...",
  "coursEnLigne": "Module 1...\\nActivité...\\nQuiz...\\nDevoir...",
  "remediation": "...",
  "approfondissement": "..."
}`;
}

function parseGeneratedPlan(text: string, fallback: LessonPromptInput): GeneratedLessonPlan {
  const cleaned = text.replace(/```json|```/g, '').trim();
  try {
    const json = JSON.parse(cleaned);
    return {
      titre: json.titre || fallback.theme || 'Fiche pédagogique',
      classe: json.classe || fallback.niveau,
      matiere: json.matiere || fallback.matiere,
      domaine: json.domaine || fallback.theme,
      duree: json.duree || fallback.duree || '45 min',
      competence: json.competence || '',
      objectif: json.objectif || fallback.objectif || '',
      materiel: json.materiel || '',
      deroulement: json.deroulement || cleaned,
      evaluation: [json.evaluation, json.exercices && `Exercices et corrigés:\n${json.exercices}`, json.coursEnLigne && `Cours en ligne:\n${json.coursEnLigne}`, json.remediation && `Remédiation:\n${json.remediation}`, json.approfondissement && `Approfondissement:\n${json.approfondissement}`].filter(Boolean).join('\n\n'),
    };
  } catch {
    return {
      titre: fallback.theme || 'Fiche pédagogique générée',
      classe: fallback.niveau,
      matiere: fallback.matiere,
      domaine: fallback.theme,
      duree: fallback.duree || '45 min',
      competence: '',
      objectif: fallback.objectif,
      materiel: '',
      deroulement: cleaned,
      evaluation: '',
    };
  }
}

async function generateWithGemini(settings: AISettings, input: LessonPromptInput) {
  if (!settings.geminiKey) throw new Error('Clé API Gemini manquante.');
  const parts: any[] = [{ text: buildLessonPrompt(input) }];
  if (input.image) {
    parts.unshift({ inline_data: { mime_type: input.image.mimeType, data: input.image.base64 } });
  }
  const res = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-goog-api-key': settings.geminiKey,
    },
    body: JSON.stringify({ contents: [{ parts }] }),
  });
  if (!res.ok) throw new Error(`Gemini indisponible (${res.status}).`);
  const data = await res.json();
  return data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text || '').join('\n') || '';
}

async function generateWithOpenAI(settings: AISettings, input: LessonPromptInput) {
  if (!settings.openaiKey) throw new Error('Clé API ChatGPT / OpenAI manquante.');
  const content: any[] = [{ type: 'text', text: buildLessonPrompt(input) }];
  if (input.image) content.push({ type: 'image_url', image_url: { url: `data:${input.image.mimeType};base64,${input.image.base64}` } });
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${settings.openaiKey}` },
    body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content }], temperature: 0.4 }),
  });
  if (!res.ok) throw new Error(`ChatGPT indisponible (${res.status}).`);
  const data = await res.json();
  return data?.choices?.[0]?.message?.content || '';
}

async function generateWithOpenAICompatible(
  apiKey: string | undefined,
  endpoint: string,
  model: string,
  label: string,
  input: LessonPromptInput
) {
  if (!apiKey) throw new Error(`Clé API ${label} manquante.`);
  const content: any[] = [{ type: 'text', text: buildLessonPrompt(input) }];
  if (input.image) content.push({ type: 'image_url', image_url: { url: `data:${input.image.mimeType};base64,${input.image.base64}` } });
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model, messages: [{ role: 'user', content }], temperature: 0.35 }),
  });
  if (!res.ok) throw new Error(`${label} indisponible (${res.status}).`);
  const data = await res.json();
  return data?.choices?.[0]?.message?.content || '';
}

async function generateWithCopilot(settings: AISettings, input: LessonPromptInput) {
  if (!settings.copilotEndpoint || !settings.copilotKey) {
    throw new Error('Endpoint ou clé Microsoft Copilot/Azure OpenAI manquant.');
  }
  const content: any[] = [{ type: 'text', text: buildLessonPrompt(input) }];
  if (input.image) content.push({ type: 'image_url', image_url: { url: `data:${input.image.mimeType};base64,${input.image.base64}` } });
  const separator = settings.copilotEndpoint.includes('?') ? '&' : '?';
  const url = `${settings.copilotEndpoint}${separator}api-version=2024-02-15-preview`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'api-key': settings.copilotKey },
    body: JSON.stringify({ messages: [{ role: 'user', content }], temperature: 0.35 }),
  });
  if (!res.ok) throw new Error(`Microsoft Copilot/Azure OpenAI indisponible (${res.status}).`);
  const data = await res.json();
  return data?.choices?.[0]?.message?.content || '';
}

async function generateWithAnthropic(settings: AISettings, input: LessonPromptInput) {
  if (!settings.anthropicKey) throw new Error('Clé API Claude / Anthropic manquante.');
  const content: any[] = [{ type: 'text', text: buildLessonPrompt(input) }];
  if (input.image) content.unshift({ type: 'image', source: { type: 'base64', media_type: input.image.mimeType, data: input.image.base64 } });
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': settings.anthropicKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({ model: 'claude-3-5-sonnet-latest', max_tokens: 3000, messages: [{ role: 'user', content }] }),
  });
  if (!res.ok) throw new Error(`Claude indisponible (${res.status}).`);
  const data = await res.json();
  return data?.content?.map((p: any) => p.text || '').join('\n') || '';
}

function generateWithLocal(input: LessonPromptInput): GeneratedLessonPlan {
  const kind = input.generationKind || 'fiche';
  const niveau = input.niveau || 'Classe à préciser';
  const matiere = input.matiere || 'Matière à préciser';
  const theme = input.theme || 'Leçon à préciser';
  const duree = input.duree || '45 min';
  const objectif = input.objectif || `Amener les apprenants à maîtriser la notion : ${theme}.`;
  const support = input.modelText
    ? 'Le modèle fourni a été pris en compte comme canevas de référence.'
    : input.image
      ? 'L’image fournie est utilisée comme support d’observation et de questionnement.'
      : 'Tableau, ardoises, cahiers, manuel, objets concrets disponibles en classe.';

  if (kind === 'exercices') {
    return {
      titre: `Exercices adaptés : ${theme}`,
      classe: niveau,
      matiere,
      domaine: theme,
      duree,
      competence: `Réinvestir les acquis de la leçon : ${theme}.`,
      objectif,
      materiel: support,
      deroulement: `Organisation proposée :\n1. Rappel rapide de la notion étudiée.\n2. Exercices faciles pour vérifier les prérequis.\n3. Exercices moyens d’application.\n4. Exercice de réinvestissement.\n5. Correction collective et remédiation ciblée.`,
      evaluation: `Exercices et corrigés :\n\nExercice 1 (Facile) : Réponds à 5 questions simples sur ${theme}.\nCorrigé : Vérifier que chaque réponse reprend la règle ou la notion étudiée.\n\nExercice 2 (Moyen) : Résous 3 situations d’application liées à ${theme}.\nCorrigé : Les réponses doivent respecter la démarche vue en classe.\n\nExercice 3 (Plus difficile) : Propose une solution à une situation-problème en expliquant les étapes.\nCorrigé : La justification doit être cohérente et complète.\n\nBarème suggéré : 20 points répartis selon exactitude, démarche, présentation et justification.\n\nRemédiation : Reprendre les erreurs fréquentes, refaire un exemple guidé, puis proposer un exercice analogue.`,
    };
  }

  if (kind === 'cours_en_ligne') {
    return {
      titre: `Cours en ligne : ${theme}`,
      classe: niveau,
      matiere,
      domaine: theme,
      duree,
      competence: `Comprendre et appliquer la notion : ${theme}.`,
      objectif,
      materiel: `${support}\nSupport numérique : texte, image, courte vidéo ou activité interactive.`,
      deroulement: `Module 1 : Situation de départ et observation.\nModule 2 : Explication progressive de la notion.\nModule 3 : Exemples guidés.\nModule 4 : Activité d’application.\nModule 5 : Quiz de vérification.\nModule 6 : Devoir de réinvestissement.`,
      evaluation: `Quiz : 5 questions courtes.\nDevoir : produire une réponse ou résoudre une situation liée à ${theme}.\nCritères : exactitude, méthode, clarté, présentation.`,
    };
  }

  return {
    titre: `Fiche pédagogique : ${theme}`,
    classe: niveau,
    matiere,
    domaine: theme,
    duree,
    competence: `Développer chez l’apprenant la capacité à comprendre et appliquer ${theme}.`,
    objectif,
    materiel: support,
    deroulement: `1. Mise en situation : présenter une situation-problème liée à ${theme}.\n2. Recherche individuelle ou en groupe : les apprenants proposent des réponses.\n3. Mise en commun : discussion, comparaison des stratégies et correction.\n4. Structuration : l’enseignant formalise la règle ou la méthode.\n5. Application : exercices gradués et accompagnement des élèves en difficulté.\n6. Synthèse : rappel des points essentiels par les apprenants.`,
    evaluation: `Évaluation formative :\n- Question orale de vérification.\n- Exercice individuel court.\n- Correction immédiate.\n\nCritères de réussite : l’apprenant explique la démarche, applique correctement la règle et présente clairement sa réponse.`,
  };
}

export async function generateLessonPlan(settings: AISettings, input: LessonPromptInput): Promise<GeneratedLessonPlan> {
  let text = '';
  if (settings.provider === 'local') return generateWithLocal(input);
  if (settings.provider === 'gemini') text = await generateWithGemini(settings, input);
  else if (settings.provider === 'openai') text = await generateWithOpenAI(settings, input);
  else if (settings.provider === 'anthropic') text = await generateWithAnthropic(settings, input);
  else if (settings.provider === 'copilot') text = await generateWithCopilot(settings, input);
  else if (settings.provider === 'mistral') text = await generateWithOpenAICompatible(settings.mistralKey, 'https://api.mistral.ai/v1/chat/completions', 'mistral-large-latest', 'Mistral', input);
  else if (settings.provider === 'deepseek') text = await generateWithOpenAICompatible(settings.deepseekKey, 'https://api.deepseek.com/chat/completions', 'deepseek-chat', 'DeepSeek', input);
  else if (settings.provider === 'perplexity') text = await generateWithOpenAICompatible(settings.perplexityKey, 'https://api.perplexity.ai/chat/completions', 'sonar', 'Perplexity', input);
  else return generateWithLocal(input);
  return parseGeneratedPlan(text, input);
}
