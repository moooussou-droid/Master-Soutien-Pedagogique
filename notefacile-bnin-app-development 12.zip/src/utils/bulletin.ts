import { ClassData, Student, Subject, Note, sortStudents, isSecondaire } from './database';

export interface SubjectResult {
  subject: Subject;
  cm: number | null; // Primaire: Critères minimaux — Secondaire: note obtenue /20
  cp: number | null; // Primaire: Note de perfectionnement — Secondaire: null
  total: number | null; // Note /20 (primaire: CM+CP ; secondaire: note obtenue)
  coefficient: number; // Secondaire
  totalObtenu: number | null; // Secondaire: note × coef
  totalPossible: number; // Secondaire: 20 × coef
  absent: boolean;
}

export interface StudentBulletin {
  student: Student;
  results: SubjectResult[];
  moyenne: number | null; // moyenne générale /20
  totalPoints: number; // Secondaire: somme des totaux obtenus
  totalPossible: number; // Secondaire: somme des totaux possibles
  totalCoef: number;
  rang: number;
  mention: string;
  appreciation: string;
  effectif: number;
}

/** Note totale d'une matière pour un élève (CM + CP), ramenée sur 20. */
function subjectTotal(note: Note | undefined, subject: Subject): number | null {
  if (!note || note.absent) return null;
  if (note.noteObtenue === null && note.notePerfectionnement === null) return null;
  const cm = note.noteObtenue ?? 0;
  const cp = note.notePerfectionnement ?? 0;
  const raw = cm + cp;
  const max = subject.noteObtenueMax + subject.notePerfectionnementMax;
  if (max === 0) return null;
  // Ramener sur 20 si le total des maxima diffère de 20
  return max === 20 ? raw : (raw / max) * 20;
}

/** Mention selon la moyenne /20 (barème béninois usuel). */
export function getMention(moyenne: number | null): string {
  if (moyenne === null) return '—';
  if (moyenne >= 18) return 'Excellent';
  if (moyenne >= 16) return 'Très Bien';
  if (moyenne >= 14) return 'Bien';
  if (moyenne >= 12) return 'Assez Bien';
  if (moyenne >= 10) return 'Passable';
  if (moyenne >= 8) return 'Insuffisant';
  return 'Faible';
}

/** Appréciation textuelle automatique. */
export function getAppreciation(moyenne: number | null): string {
  if (moyenne === null) return 'Aucune note enregistrée.';
  if (moyenne >= 18) return 'Résultats exceptionnels. Félicitations, continue ainsi !';
  if (moyenne >= 16) return 'Très bon travail. Élève sérieux et appliqué.';
  if (moyenne >= 14) return 'Bon travail. Poursuis tes efforts.';
  if (moyenne >= 12) return 'Travail satisfaisant. Peut mieux faire.';
  if (moyenne >= 10) return 'Résultats moyens. Des efforts sont nécessaires.';
  if (moyenne >= 8) return 'Résultats insuffisants. Doit travailler davantage.';
  return 'Résultats faibles. Un accompagnement soutenu est recommandé.';
}

/** Calcule les bulletins de tous les élèves avec rang. */
export function computeBulletins(classData: ClassData): StudentBulletin[] {
  const subjects = [...classData.subjects].sort((a, b) => a.order - b.order);
  const secondaire = isSecondaire(classData);

  // Étape 1 : calcul des moyennes de chaque élève
  const partial = classData.students.map((student) => {
    const results: SubjectResult[] = subjects.map((subject) => {
      const note = classData.notes.find(
        (n) => n.studentId === student.id && n.subjectId === subject.id
      );
      const coefficient = subject.coefficient ?? 1;
      const total = subjectTotal(note, subject); // note /20
      const totalObtenu = total !== null ? total * coefficient : null;
      const totalPossible = 20 * coefficient;
      return {
        subject,
        cm: note?.absent ? null : note?.noteObtenue ?? null,
        cp: note?.absent ? null : note?.notePerfectionnement ?? null,
        total,
        coefficient,
        totalObtenu,
        totalPossible,
        absent: note?.absent ?? false,
      };
    });

    const notedResults = results.filter((r) => r.total !== null);

    let moyenne: number | null;
    let totalPoints: number;
    let totalPossible: number;
    let totalCoef: number;

    if (secondaire) {
      // Moyenne pondérée par les coefficients
      totalPoints = notedResults.reduce((sum, r) => sum + (r.totalObtenu ?? 0), 0);
      totalPossible = notedResults.reduce((sum, r) => sum + r.totalPossible, 0);
      totalCoef = notedResults.reduce((sum, r) => sum + r.coefficient, 0);
      moyenne = totalCoef > 0 ? totalPoints / totalCoef : null;
    } else {
      // Primaire : moyenne arithmétique simple
      totalPoints = notedResults.reduce((sum, r) => sum + (r.total ?? 0), 0);
      totalPossible = notedResults.length * 20;
      totalCoef = notedResults.length;
      moyenne = totalCoef > 0 ? totalPoints / totalCoef : null;
    }

    return { student, results, moyenne, totalPoints, totalPossible, totalCoef };
  });

  // Étape 2 : classement (rang) sur la moyenne, décroissant
  const ranked = [...partial]
    .filter((p) => p.moyenne !== null)
    .sort((a, b) => (b.moyenne ?? 0) - (a.moyenne ?? 0));

  const rangMap = new Map<string, number>();
  ranked.forEach((p, index) => {
    // Gestion des ex-aequo
    if (index > 0 && ranked[index - 1].moyenne === p.moyenne) {
      rangMap.set(p.student.id, rangMap.get(ranked[index - 1].student.id)!);
    } else {
      rangMap.set(p.student.id, index + 1);
    }
  });

  const effectif = classData.students.length;

  // Étape 3 : bulletins triés par ordre alphabétique (comme le modèle)
  const sorted = sortStudents(classData.students);
  return sorted.map((student) => {
    const p = partial.find((x) => x.student.id === student.id)!;
    return {
      ...p,
      rang: rangMap.get(student.id) ?? 0,
      mention: getMention(p.moyenne),
      appreciation: getAppreciation(p.moyenne),
      effectif,
    };
  });
}

/** Statistiques globales de la classe. */
export function computeClassStats(bulletins: StudentBulletin[]) {
  const withMoyenne = bulletins.filter((b) => b.moyenne !== null);
  const count = withMoyenne.length;
  const moyenneClasse =
    count > 0 ? withMoyenne.reduce((s, b) => s + (b.moyenne ?? 0), 0) / count : null;
  const admis = withMoyenne.filter((b) => (b.moyenne ?? 0) >= 10).length;
  const tauxReussite = count > 0 ? (admis / count) * 100 : 0;
  const plusForte = count > 0 ? Math.max(...withMoyenne.map((b) => b.moyenne ?? 0)) : null;
  const plusFaible = count > 0 ? Math.min(...withMoyenne.map((b) => b.moyenne ?? 0)) : null;

  return { moyenneClasse, admis, count, tauxReussite, plusForte, plusFaible };
}
