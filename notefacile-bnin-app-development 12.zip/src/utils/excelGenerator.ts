import ExcelJS from 'exceljs';
import { ClassData, Subject, sortStudents } from './database';

const OFFICIAL_SUBJECT_ORDER = [
  'Dictée',
  'Math',
  'Mathématiques',
  'Expresion écrite',
  'Expression écrite',
  'Compréhension de l\'écrit',
  'EST',
  'ES',
  'EA (Oral)',
  'EA (Déssin/Couture)',
  'EA (Dessin/Couture)',
  'EPS',
  'Communication écrite',
  'Lecture',
  'PCT',
  'Allemand ou Espagnol',
  'Histoire-Géographie',
  'Anglais',
  'SVT',
  'Philosophie',
  'LV1',
  'LV2',
  'Economie',
  'Conduite',
  'Français',
];

function normalizeSubjectName(name: string) {
  return name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
}

function sortSubjectsForEducMaster(subjects: Subject[]) {
  return [...subjects].sort((a, b) => {
    const ai = OFFICIAL_SUBJECT_ORDER.findIndex(name => normalizeSubjectName(name) === normalizeSubjectName(a.name));
    const bi = OFFICIAL_SUBJECT_ORDER.findIndex(name => normalizeSubjectName(name) === normalizeSubjectName(b.name));
    const ar = ai === -1 ? 999 + a.order : ai;
    const br = bi === -1 ? 999 + b.order : bi;
    return ar - br;
  });
}

export async function generateEducMasterExcel(classData: ClassData): Promise<{ blob: Blob; filename: string }> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Notes');

  // Export toujours dans l'ordre officiel exigé par EducMaster, même si l'enseignant
  // a réorganisé les matières pour faciliter sa saisie dans l'application.
  const subjects: Subject[] = sortSubjectsForEducMaster(classData.subjects);

  // Calculate total columns: Matricule + Nom + Prénoms + (2 columns per subject)
  const baseColumns = 3;
  const subjectColumns = subjects.length * 2;
  const totalColumns = baseColumns + subjectColumns;

  // Create header row 1 with merged cells
  worksheet.mergeCells('A1:A2');
  worksheet.mergeCells('B1:B2');
  worksheet.mergeCells('C1:C2');

  worksheet.getCell('A1').value = 'Matricule';
  worksheet.getCell('B1').value = 'Nom';
  worksheet.getCell('C1').value = 'Prénoms';

  let currentCol = 4; // Start at column D (4th column)
  const colLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  for (const subject of subjects) {
    const colLetter1 = colLetters[currentCol - 1];
    const colLetter2 = colLetters[currentCol];
    
    // Merge cells for subject name
    worksheet.mergeCells(`${colLetter1}1:${colLetter2}1`);
    worksheet.getCell(`${colLetter1}1`).value = subject.name;
    
    // Sub-headers
    worksheet.getCell(`${colLetter1}2`).value = 'Note obtenue';
    worksheet.getCell(`${colLetter2}2`).value = 'Note perfectionnement';
    
    currentCol += 2;
  }

  // Style the headers
  const headerStyle: Partial<ExcelJS.Style> = {
    font: { bold: true, size: 11, name: 'Arial' },
    alignment: { horizontal: 'center', vertical: 'middle', wrapText: true },
    border: {
      top: { style: 'thin' },
      bottom: { style: 'thin' },
      left: { style: 'thin' },
      right: { style: 'thin' },
    },
    fill: {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' },
    },
  };

  // Apply header style to all header cells
  for (let row = 1; row <= 2; row++) {
    for (let col = 1; col <= totalColumns; col++) {
      const cell = worksheet.getCell(row, col);
      cell.style = headerStyle;
    }
  }

  // Trie les élèves par ordre alphabétique du nom (identique au modèle EducMaster)
  const sortedStudents = sortStudents(classData.students);

  sortedStudents.forEach((student, index) => {
    const rowNum = index + 3; // Start at row 3 (after 2 header rows)
    
    // Matricule en TEXTE pour préserver les zéros initiaux (comme le modèle EducMaster)
    const matriculeCell = worksheet.getCell(`A${rowNum}`);
    matriculeCell.value = student.matricule;
    matriculeCell.numFmt = '@'; // format texte forcé
    
    worksheet.getCell(`B${rowNum}`).value = student.nom.toUpperCase();
    worksheet.getCell(`C${rowNum}`).value = student.prenoms;

    // Add notes for each subject
    let colIndex = 4;
    for (const subject of subjects) {
      const note = classData.notes.find(
        n => n.studentId === student.id && n.subjectId === subject.id
      );

      const noteObtenueCell = worksheet.getCell(rowNum, colIndex);
      const notePerfCell = worksheet.getCell(rowNum, colIndex + 1);

      if (note?.absent) {
        noteObtenueCell.value = 'ABS';
        notePerfCell.value = 'ABS';
      } else if (note) {
        noteObtenueCell.value = note.noteObtenue ?? '';
        notePerfCell.value = note.notePerfectionnement ?? '';
      }

      colIndex += 2;
    }
  });

  // Apply borders and styling to data rows
  const dataStyle: Partial<ExcelJS.Style> = {
    font: { size: 10, name: 'Arial' },
    alignment: { horizontal: 'center', vertical: 'middle' },
    border: {
      top: { style: 'thin' },
      bottom: { style: 'thin' },
      left: { style: 'thin' },
      right: { style: 'thin' },
    },
  };

  const totalRows = sortedStudents.length + 2;
  for (let row = 3; row <= totalRows; row++) {
    for (let col = 1; col <= totalColumns; col++) {
      const cell = worksheet.getCell(row, col);
      cell.style = dataStyle;
    }
  }

  // Set column widths
  worksheet.getColumn(1).width = 15; // Matricule
  worksheet.getColumn(1).numFmt = '@'; // colonne Matricule en texte
  worksheet.getColumn(2).width = 20; // Nom
  worksheet.getColumn(3).width = 25; // Prénoms
  
  for (let i = 4; i <= totalColumns; i++) {
    worksheet.getColumn(i).width = 14;
  }

  // Generate filename
  const now = new Date();
  const timestamp = now.toISOString().replace(/[-:T.]/g, '').slice(0, 14);
  const year = now.getFullYear();
  const schoolSafe = classData.school.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
  const classSafe = classData.name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
  
  const filename = `${timestamp}_model-importation-note_${year}-epp-${schoolSafe}-${classSafe}.xlsx`;

  // Generate buffer
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });

  return { blob, filename };
}

/**
 * Télécharge (ou partage) le fichier Excel de façon fiable sur mobile ET ordinateur.
 * - Sur mobile : privilégie l'API de partage native (enregistrer dans Fichiers,
 *   envoyer via WhatsApp/Drive/email...).
 * - Partout : repli sur un téléchargement classique robuste (URL libérée avec délai).
 * Retourne une info sur la méthode utilisée.
 */
export async function downloadExcel(
  blob: Blob,
  filename: string
): Promise<'shared' | 'downloaded' | 'cancelled'> {
  // 1) Essayer l'API de partage native (idéale sur téléphone)
  try {
    const file = new File([blob], filename, {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });

    const nav = navigator as Navigator & {
      canShare?: (data: { files: File[] }) => boolean;
      share?: (data: { files: File[]; title?: string; text?: string }) => Promise<void>;
    };

    if (nav.share && nav.canShare && nav.canShare({ files: [file] })) {
      try {
        await nav.share({
          files: [file],
          title: 'Notes EducMaster',
          text: 'Fichier de notes à importer sur educmaster.bj',
        });
        return 'shared';
      } catch (shareErr) {
        // L'utilisateur a annulé le partage : on ne bascule PAS en téléchargement
        if ((shareErr as Error)?.name === 'AbortError') {
          return 'cancelled';
        }
        // Autre erreur de partage : on continue vers le téléchargement classique
      }
    }
  } catch {
    // File API indisponible : on continue vers le téléchargement classique
  }

  // 2) Téléchargement classique robuste
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.rel = 'noopener';
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();

  // Libérer l'URL APRÈS un délai pour laisser le temps au téléchargement de démarrer
  setTimeout(() => {
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, 4000);

  return 'downloaded';
}
