/**
 * Configuration de la synchronisation cloud.
 *
 * ⚙️ POUR ACTIVER LE CLOUD (à faire UNE SEULE FOIS par le propriétaire de l'app) :
 *
 * 1. Créez un compte gratuit sur https://supabase.com
 * 2. Créez un nouveau projet (gratuit)
 * 3. Dans "Table Editor", créez une table nommée `backups` avec les colonnes :
 *      - sync_code   : type text   (Primary Key)
 *      - data        : type text
 *      - updated_at  : type timestamptz  (valeur par défaut: now())
 * 4. Créez une table nommée `licenses` (validation des codes d'accès) avec :
 *      - code        : type text   (Primary Key)
 *      - name        : type text
 *      - status      : type text   (valeur par défaut: 'active')  // 'active' | 'revoked'
 *      - created_at  : type timestamptz  (valeur par défaut: now())
 * 5. Dans "Project Settings > API", copiez :
 *      - Project URL       → collez-le dans SUPABASE_URL ci-dessous
 *      - anon public key   → collez-la dans SUPABASE_ANON_KEY ci-dessous
 * 6. (Sécurité) Activez RLS et ajoutez une policy autorisant insert/select/update
 *    sur les tables `backups` et `licenses` pour le rôle `anon`.
 *
 * ⚠️ IMPORTANT : Même si ces identifiants sont publics, VOS DONNÉES RESTENT PRIVÉES
 *    car elles sont chiffrées de bout en bout AVANT l'envoi (voir crypto.ts).
 *    Le serveur ne stocke que du texte chiffré illisible.
 *
 * Tant que ces valeurs restent vides, l'application fonctionne 100% en local
 * (aucune synchronisation), exactement comme avant.
 */

export const SUPABASE_URL = '';
export const SUPABASE_ANON_KEY = '';

export function isCloudConfigured(): boolean {
  return SUPABASE_URL.trim().length > 0 && SUPABASE_ANON_KEY.trim().length > 0;
}
