/**
 * Gestion de l'espace utilisateur : activation (code d'accès) et profil.
 * Tout est stocké localement (localStorage) sur l'appareil de l'utilisateur.
 */

export interface UserActivation {
  activated: boolean;
  name: string;
  code: string;
  activatedAt: number;
}

export interface UserProfile {
  teacherName: string;
  schoolName: string;
  schoolLogo?: string; // image en base64 (data URL)
  phone?: string;
}

const ACTIVATION_KEY = 'msp_activation';
const PROFILE_KEY = 'msp_profile';

/* ------- Activation ------- */

export function getActivation(): UserActivation | null {
  try {
    const raw = localStorage.getItem(ACTIVATION_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return null;
}

export function isActivated(): boolean {
  return getActivation()?.activated === true;
}

export function saveActivation(name: string, code: string): void {
  const data: UserActivation = {
    activated: true,
    name: name.trim(),
    code: code.trim(),
    activatedAt: Date.now(),
  };
  localStorage.setItem(ACTIVATION_KEY, JSON.stringify(data));
}

export function clearActivation(): void {
  localStorage.removeItem(ACTIVATION_KEY);
}

/* ------- Profil (dont logo école) ------- */

export function getProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return { teacherName: '', schoolName: '' };
}

export function saveProfile(profile: UserProfile): void {
  localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
}

export function getSchoolLogo(): string | undefined {
  return getProfile().schoolLogo;
}

/**
 * Lit un fichier image et le redimensionne en data URL (max 400px, JPEG/PNG).
 * Garde une taille raisonnable pour le stockage local et les bulletins.
 */
export function readAndResizeImage(file: File, maxSize = 400): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxSize) {
          height = Math.round((height * maxSize) / width);
          width = maxSize;
        } else if (height > maxSize) {
          width = Math.round((width * maxSize) / height);
          height = maxSize;
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return reject(new Error('Canvas non disponible'));
        ctx.drawImage(img, 0, 0, width, height);
        // PNG pour préserver la transparence des logos
        resolve(canvas.toDataURL('image/png'));
      };
      img.onerror = () => reject(new Error('Image invalide'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Lecture impossible'));
    reader.readAsDataURL(file);
  });
}
