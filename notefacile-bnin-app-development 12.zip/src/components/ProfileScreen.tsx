import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ImageUp, Trash2, Save, School, User, Phone, Check } from 'lucide-react';
import { getProfile, saveProfile, readAndResizeImage, UserProfile } from '../utils/userProfile';

export default function ProfileScreen() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile>(getProfile());
  const [saved, setSaved] = useState(false);
  const [uploading, setUploading] = useState(false);

  async function handleLogoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Veuillez choisir une image (JPG, PNG…).');
      return;
    }
    setUploading(true);
    try {
      const dataUrl = await readAndResizeImage(file, 400);
      setProfile((p) => ({ ...p, schoolLogo: dataUrl }));
    } catch {
      alert("Impossible de lire cette image.");
    } finally {
      setUploading(false);
    }
  }

  function removeLogo() {
    setProfile((p) => ({ ...p, schoolLogo: undefined }));
  }

  function handleSave() {
    saveProfile(profile);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 bg-white/20 rounded-lg">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-lg font-bold">Mon espace</h1>
            <p className="text-emerald-100 text-sm">Profil & logo de l'école</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24 max-w-md mx-auto">
        {/* Logo de l'école */}
        <div className="bg-white rounded-xl shadow p-4 mb-4">
          <h2 className="font-bold text-gray-800 mb-1 flex items-center gap-2">
            <School className="w-5 h-5 text-emerald-600" />
            Logo de l'école
          </h2>
          <p className="text-gray-500 text-sm mb-3">
            Ce logo apparaîtra en haut des bulletins scolaires de vos élèves.
          </p>

          <div className="flex flex-col items-center">
            {profile.schoolLogo ? (
              <div className="text-center">
                <img
                  src={profile.schoolLogo}
                  alt="Logo école"
                  className="w-32 h-32 object-contain border rounded-xl bg-gray-50 mx-auto"
                />
                <button
                  onClick={removeLogo}
                  className="text-red-600 text-sm mt-2 inline-flex items-center gap-1"
                >
                  <Trash2 className="w-4 h-4" />
                  Retirer le logo
                </button>
              </div>
            ) : (
              <label className="w-full border-2 border-dashed border-gray-300 rounded-xl p-6 text-center cursor-pointer hover:bg-gray-50">
                <ImageUp className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-600 text-sm font-medium">
                  {uploading ? 'Chargement...' : 'Télécharger le logo'}
                </p>
                <p className="text-gray-400 text-xs mt-1">JPG, PNG (recommandé : carré)</p>
                <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
              </label>
            )}
            {profile.schoolLogo && (
              <label className="w-full mt-3 bg-gray-100 text-gray-700 py-2.5 rounded-lg text-center cursor-pointer text-sm font-medium">
                Changer le logo
                <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
              </label>
            )}
          </div>
        </div>

        {/* Informations */}
        <div className="bg-white rounded-xl shadow p-4 mb-4 space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nom de l'enseignant</label>
            <div className="relative">
              <User className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={profile.teacherName}
                onChange={(e) => setProfile({ ...profile, teacherName: e.target.value })}
                placeholder="Votre nom"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nom de l'école</label>
            <div className="relative">
              <School className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={profile.schoolName}
                onChange={(e) => setProfile({ ...profile, schoolName: e.target.value })}
                placeholder="Ex: EPP Cotonou Centre"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Téléphone (facultatif)</label>
            <div className="relative">
              <Phone className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="tel"
                value={profile.phone || ''}
                onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                placeholder="Ex: +229 ..."
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
        </div>

        <button
          onClick={handleSave}
          className={`w-full py-3 rounded-xl font-semibold flex items-center justify-center gap-2 ${
            saved ? 'bg-emerald-500 text-white' : 'bg-emerald-600 text-white'
          }`}
        >
          {saved ? <Check className="w-5 h-5" /> : <Save className="w-5 h-5" />}
          {saved ? 'Enregistré !' : 'Enregistrer mon profil'}
        </button>

      </main>
    </div>
  );
}
