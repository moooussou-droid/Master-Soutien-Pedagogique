import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bot, ChevronLeft, Clipboard, ImageUp, KeyRound, Save, Wand2 } from 'lucide-react';
import {
  AIProvider,
  AISettings,
  buildLessonPrompt,
  extractModelText,
  fileToInlineImage,
  generateLessonPlan,
  getAISettings,
  PROMPT_MAGIC_FICHE_PEDAGOGIQUE,
  PROMPT_MAGIC_EXERCICES_ADAPTATIFS,
  saveAISettings,
  GeneratedLessonPlan,
  GenerationKind,
  PedagogicalStandard,
} from '../utils/aiLessonGenerator';

const FICHES_KEY = 'msp_fiches_pedagogiques';

function today() {
  return new Date().toISOString().split('T')[0];
}

function loadFiches(): any[] {
  try {
    return JSON.parse(localStorage.getItem(FICHES_KEY) || '[]');
  } catch {
    return [];
  }
}

function saveGeneratedAsFiche(plan: GeneratedLessonPlan) {
  const fiches = loadFiches();
  const fiche = {
    id: `fiche-ai-${Date.now()}`,
    titre: plan.titre,
    classe: plan.classe,
    matiere: plan.matiere,
    domaine: plan.domaine,
    duree: plan.duree,
    date: today(),
    competence: plan.competence,
    objectif: plan.objectif,
    materiel: plan.materiel,
    deroulement: plan.deroulement,
    evaluation: plan.evaluation,
    statut: 'prete',
    createdAt: Date.now(),
  };
  localStorage.setItem(FICHES_KEY, JSON.stringify([fiche, ...fiches]));
}

export default function AILessonGeneratorScreen() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState<AISettings>(getAISettings());
  const [niveau, setNiveau] = useState('CE1');
  const [matiere, setMatiere] = useState('Mathématiques');
  const [theme, setTheme] = useState('');
  const [duree, setDuree] = useState('45 min');
  const [objectif, setObjectif] = useState('');
  const [consignes, setConsignes] = useState('');
  const [generationKind, setGenerationKind] = useState<GenerationKind>('fiche');
  const [standard, setStandard] = useState<PedagogicalStandard>('APC_BENIN');
  const [image, setImage] = useState<{ mimeType: string; base64: string } | undefined>();
  const [imageName, setImageName] = useState('');
  const [modelFileName, setModelFileName] = useState('');
  const [modelText, setModelText] = useState('');
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<GeneratedLessonPlan | null>(null);

  function updateSettings(patch: Partial<AISettings>) {
    const next = { ...settings, ...patch };
    setSettings(next);
    saveAISettings(next);
  }

  async function handleImage(file?: File) {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Choisissez une image JPG ou PNG.');
      return;
    }
    setImage(await fileToInlineImage(file));
    setImageName(file.name);
  }

  async function handleGenerate() {
    setGenerating(true);
    try {
      const plan = await generateLessonPlan(settings, { niveau, matiere, theme, duree, objectif, consignes, generationKind, standard, modelText, image });
      setResult(plan);
    } catch (e: any) {
      alert(e.message || 'Génération impossible. Essayez le générateur intégré sans clé API.');
    } finally {
      setGenerating(false);
    }
  }

  async function copyPrompt() {
    const prompt = buildLessonPrompt({ niveau, matiere, theme, duree, objectif, consignes, generationKind, standard, modelText, image });
    await navigator.clipboard?.writeText(prompt);
    alert('Prompt copié. Vous pouvez le coller dans Gemini, Claude, ChatGPT, Copilot, Mistral, DeepSeek ou Perplexity.');
  }

  async function copyMagicPrompt() {
    const prompt = generationKind === 'exercices'
      ? PROMPT_MAGIC_EXERCICES_ADAPTATIFS
      : PROMPT_MAGIC_FICHE_PEDAGOGIQUE;
    await navigator.clipboard?.writeText(prompt);
    alert(generationKind === 'exercices' ? 'Prompt Magic 2 copié.' : 'Prompt Magic 1 copié.');
  }

  function saveFiche() {
    if (!result) return;
    saveGeneratedAsFiche(result);
    alert('Fiche enregistrée dans Mes fiches.');
  }

  async function handleModelFile(file?: File) {
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase();
    setModelFileName(file.name);
    try {
      if (file.type.startsWith('image/')) {
        setImage(await fileToInlineImage(file));
        setImageName(file.name);
        setModelText('');
        return;
      }
      if (ext === 'pdf' || ext === 'docx' || ext === 'doc') {
        const text = await extractModelText(file);
        setModelText(text);
        return;
      }
      alert('Format non pris en charge pour le modèle. Utilisez DOC, DOCX, PDF, JPG ou PNG.');
    } catch (e) {
      console.error(e);
      alert('Impossible de lire ce modèle. Essayez de le convertir en PDF ou DOCX.');
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/fiches-pedagogiques')} className="p-2 bg-white/20 rounded-lg">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="font-bold text-lg">Générateur de Fiches APC avec IA</h1>
            <p className="text-emerald-100 text-sm">Sans clé API par défaut, avec options Gemini, Claude, ChatGPT, Copilot...</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24 space-y-4">
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
          <p className="text-amber-800 text-sm">
            Le générateur intégré fonctionne sans clé API. Les clés externes sont facultatives et restent stockées uniquement sur cet appareil.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow p-4">
          <h2 className="font-bold text-gray-800 mb-3 flex items-center gap-2"><KeyRound className="w-5 h-5" /> IA à utiliser</h2>
          <select
            value={settings.provider}
            onChange={e => updateSettings({ provider: e.target.value as AIProvider })}
            className="w-full p-3 border border-gray-300 rounded-lg mb-3"
          >
            <option value="local">Générateur intégré (sans clé API)</option>
            <option value="gemini">Gemini</option>
            <option value="copilot">Microsoft Copilot / Azure OpenAI</option>
            <option value="openai">ChatGPT / OpenAI</option>
            <option value="anthropic">Claude / Anthropic</option>
            <option value="mistral">Mistral AI</option>
            <option value="deepseek">DeepSeek</option>
            <option value="perplexity">Perplexity Sonar</option>
          </select>
          {settings.provider === 'local' && (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
              Génération locale activée : aucune clé API n’est nécessaire. Le résultat est produit à partir de modèles pédagogiques intégrés.
            </div>
          )}
          {settings.provider === 'gemini' && <KeyInput value={settings.geminiKey || ''} onChange={v => updateSettings({ geminiKey: v })} placeholder="Clé API Gemini" />}
          {settings.provider === 'copilot' && (
            <div className="space-y-2">
              <KeyInput value={settings.copilotEndpoint || ''} onChange={v => updateSettings({ copilotEndpoint: v })} placeholder="Endpoint Azure OpenAI / Copilot Studio" />
              <KeyInput value={settings.copilotKey || ''} onChange={v => updateSettings({ copilotKey: v })} placeholder="Clé API Microsoft Copilot / Azure" />
            </div>
          )}
          {settings.provider === 'openai' && <KeyInput value={settings.openaiKey || ''} onChange={v => updateSettings({ openaiKey: v })} placeholder="Clé API OpenAI" />}
          {settings.provider === 'anthropic' && <KeyInput value={settings.anthropicKey || ''} onChange={v => updateSettings({ anthropicKey: v })} placeholder="Clé API Anthropic" />}
          {settings.provider === 'mistral' && <KeyInput value={settings.mistralKey || ''} onChange={v => updateSettings({ mistralKey: v })} placeholder="Clé API Mistral" />}
          {settings.provider === 'deepseek' && <KeyInput value={settings.deepseekKey || ''} onChange={v => updateSettings({ deepseekKey: v })} placeholder="Clé API DeepSeek" />}
          {settings.provider === 'perplexity' && <KeyInput value={settings.perplexityKey || ''} onChange={v => updateSettings({ perplexityKey: v })} placeholder="Clé API Perplexity" />}
        </div>

        <div className="bg-white rounded-xl shadow p-4 space-y-3">
          <h2 className="font-bold text-gray-800 flex items-center gap-2"><Bot className="w-5 h-5 text-emerald-600" /> Informations de la fiche</h2>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Production</label>
              <select value={generationKind} onChange={e => setGenerationKind(e.target.value as GenerationKind)} className="w-full p-3 border border-gray-300 rounded-lg text-sm">
                <option value="fiche">Fiche pédagogique APC</option>
                <option value="exercices">Exercices + corrigés</option>
                <option value="cours_en_ligne">Cours à mettre en ligne</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Norme pédagogique</label>
              <select value={standard} onChange={e => setStandard(e.target.value as PedagogicalStandard)} className="w-full p-3 border border-gray-300 rounded-lg text-sm">
                <option value="APC_BENIN">APC Bénin</option>
                <option value="PPO">PPO</option>
                <option value="COMPETENCE">Approche compétences</option>
                <option value="DIFFERENCIATION">Différenciation</option>
                <option value="BLOOM">Taxonomie de Bloom</option>
                <option value="UNIVERSAL_DESIGN">Inclusion / CUA</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Input label="Niveau" value={niveau} onChange={setNiveau} />
            <Input label="Matière" value={matiere} onChange={setMatiere} />
          </div>
          <Input label="Thème / Leçon" value={theme} onChange={setTheme} placeholder="Ex: Addition avec retenue" />
          <div className="grid grid-cols-2 gap-2">
            <Input label="Durée" value={duree} onChange={setDuree} />
            <Input label="Objectif" value={objectif} onChange={setObjectif} />
          </div>
          <Area label="Consignes complémentaires" value={consignes} onChange={setConsignes} />
          <label className="border-2 border-dashed border-emerald-300 bg-emerald-50 rounded-xl p-4 flex items-center gap-3 cursor-pointer">
            <ImageUp className="w-6 h-6 text-emerald-600" />
            <div className="flex-1">
              <p className="font-medium text-emerald-800 text-sm">Modèle de fiche à analyser</p>
              <p className="text-emerald-700 text-xs">
                {modelFileName || 'Formats acceptés : DOC, DOCX, PDF, JPG, JPEG, PNG'}
              </p>
              {modelText && <p className="text-emerald-600 text-xs mt-1">Texte extrait : {modelText.length} caractères</p>}
            </div>
            <input type="file" accept=".doc,.docx,.pdf,image/*" onChange={e => handleModelFile(e.target.files?.[0])} className="hidden" />
          </label>
          <label className="border-2 border-dashed border-gray-300 rounded-xl p-4 flex items-center gap-3 cursor-pointer">
            <ImageUp className="w-6 h-6 text-gray-400" />
            <div className="flex-1">
              <p className="font-medium text-gray-700 text-sm">Modèle de fiche ou image support (facultatif)</p>
              <p className="text-gray-400 text-xs">{imageName || 'Image du modèle, page de manuel, exercice, schéma...'}</p>
            </div>
            <input type="file" accept="image/*" onChange={e => handleImage(e.target.files?.[0])} className="hidden" />
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button onClick={copyMagicPrompt} className="bg-amber-50 text-amber-700 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 text-sm"><Clipboard className="w-5 h-5" /> {generationKind === 'exercices' ? 'Prompt Magic 2' : 'Prompt Magic 1'}</button>
            <button onClick={copyPrompt} className="bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold flex items-center justify-center gap-2"><Clipboard className="w-5 h-5" /> Copier prompt</button>
            <button onClick={handleGenerate} disabled={generating} className="bg-emerald-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50"><Wand2 className="w-5 h-5" /> {generating ? 'Génération...' : 'Générer'}</button>
          </div>
        </div>

        {result && (
          <div className="bg-white rounded-xl shadow p-4">
            <h2 className="font-bold text-gray-800 mb-3">Fiche générée</h2>
            <Preview label="Titre" value={result.titre} />
            <Preview label="Compétence" value={result.competence} />
            <Preview label="Objectif" value={result.objectif} />
            <Preview label="Matériel" value={result.materiel} />
            <Preview label="Déroulement" value={result.deroulement} />
            <Preview label="Évaluation" value={result.evaluation} />
            <button onClick={saveFiche} className="w-full mt-3 bg-emerald-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2"><Save className="w-5 h-5" /> Enregistrer dans Mes fiches</button>
          </div>
        )}
      </main>
    </div>
  );
}

function KeyInput({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return <input type="password" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="w-full p-3 border border-gray-300 rounded-lg text-sm" />;
}

function Input({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="w-full p-3 border border-gray-300 rounded-lg text-sm" />
    </div>
  );
}

function Area({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <textarea value={value} onChange={e => onChange(e.target.value)} rows={3} className="w-full p-3 border border-gray-300 rounded-lg text-sm resize-none" />
    </div>
  );
}

function Preview({ label, value }: { label: string; value: string }) {
  return (
    <div className="mb-3">
      <p className="text-xs font-semibold text-gray-500 mb-1">{label}</p>
      <p className="text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 rounded-lg p-3">{value || '-'}</p>
    </div>
  );
}
