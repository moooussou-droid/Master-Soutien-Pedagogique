import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookMarked, ChevronLeft, Plus, Search, Shield, X } from 'lucide-react';
import { ADMIN_PASSWORD } from '../utils/adminConfig';
import { getVideoEmbed } from '../utils/courseMarketplace';

interface KidWord {
  word: string;
  definition: string;
  example: string;
  family: string;
  imageUrl?: string;
  videoUrl?: string;
}

const CUSTOM_KEY = 'msp_kids_dictionary_custom_words';

function loadCustomWords(): KidWord[] {
  try { return JSON.parse(localStorage.getItem(CUSTOM_KEY) || '[]'); } catch { return []; }
}
function saveCustomWords(words: KidWord[]) { localStorage.setItem(CUSTOM_KEY, JSON.stringify(words)); }

const WORDS: KidWord[] = [
  ['Addition', 'Une addition sert à mettre ensemble plusieurs nombres pour trouver un total.', '2 + 3 = 5.', 'Mathématiques'],
  ['Soustraction', 'Une soustraction sert à enlever une quantité d’une autre.', '8 - 3 = 5.', 'Mathématiques'],
  ['Multiplication', 'Une multiplication est une addition répétée.', '3 × 4 veut dire 4 + 4 + 4.', 'Mathématiques'],
  ['Division', 'Une division sert à partager en parts égales.', '12 bonbons partagés entre 3 enfants donnent 4 bonbons chacun.', 'Mathématiques'],
  ['Phrase', 'Une phrase est un groupe de mots qui a un sens.', 'Le chat dort.', 'Français'],
  ['Verbe', 'Le verbe indique souvent une action ou un état.', 'courir, manger, être.', 'Français'],
  ['Nom', 'Un nom désigne une personne, un animal, une chose ou un lieu.', 'élève, chien, cahier, école.', 'Français'],
  ['Adjectif', 'Un adjectif donne une information sur un nom.', 'un joli dessin.', 'Français'],
  ['Microbe', 'Un microbe est un être très petit qui peut parfois rendre malade.', 'Se laver les mains aide à éviter les microbes.', 'Santé'],
  ['Vaccin', 'Un vaccin aide le corps à se défendre contre une maladie.', 'Le vaccin protège l’enfant.', 'Santé'],
  ['Hygiène', 'L’hygiène est l’ensemble des gestes pour rester propre et en bonne santé.', 'Se laver les mains avant de manger.', 'Santé'],
  ['Citoyen', 'Un citoyen est une personne qui appartient à un pays et respecte ses règles.', 'Un citoyen respecte les lois.', 'Citoyenneté'],
  ['Respect', 'Le respect consiste à bien se comporter avec les autres.', 'On écoute quand quelqu’un parle.', 'Citoyenneté'],
  ['Drapeau', 'Un drapeau est un symbole qui représente un pays ou un groupe.', 'Le drapeau du Bénin est vert, jaune et rouge.', 'Bénin'],
  ['Carte', 'Une carte est un dessin qui représente un lieu.', 'Une carte montre les villes et les routes.', 'Géographie'],
  ['Fleuve', 'Un fleuve est un grand cours d’eau qui se jette dans la mer.', 'Le fleuve Niger traverse plusieurs pays.', 'Géographie'],
  ['Plante', 'Une plante est un être vivant qui pousse dans la terre ou dans l’eau.', 'Le maïs est une plante.', 'Sciences'],
  ['Animal', 'Un animal est un être vivant qui respire et se nourrit.', 'La chèvre est un animal.', 'Sciences'],
  ['Énergie', 'L’énergie permet de faire fonctionner des objets ou de produire un effort.', 'Le soleil donne de l’énergie.', 'Sciences'],
  ['Internet', 'Internet permet d’échanger des informations avec un téléphone ou un ordinateur.', 'On peut apprendre en ligne.', 'Hightech'],
  ['Ordinateur', 'Un ordinateur est une machine qui aide à écrire, calculer et apprendre.', 'Le maître prépare un document sur ordinateur.', 'Hightech'],
  ['Agriculture', 'L’agriculture consiste à cultiver la terre et élever des animaux.', 'Le cultivateur plante du maïs.', 'Agriculture'],
  ['Épargne', 'L’épargne est l’argent qu’on garde pour plus tard.', 'Je garde une partie de mon argent.', 'Finance'],
  ['Métier', 'Un métier est un travail qu’on apprend pour rendre service et gagner sa vie.', 'Médecin, enseignant, mécanicien.', 'Orientation'],
].map(([word, definition, example, family]) => ({ word, definition, example, family }));

const imageUrl = (item: KidWord) => item.imageUrl || `https://source.unsplash.com/800x450/?${encodeURIComponent(`${item.word} school child education`)}`;
const videoId = (word: string) => {
  const w = word.toLowerCase();
  if (w.includes('addition') || w.includes('multiplication') || w.includes('division')) return '4O8X7xG6dpA';
  if (w.includes('phrase') || w.includes('verbe') || w.includes('nom')) return 'VeSUzYblKio';
  if (w.includes('microbe') || w.includes('vaccin') || w.includes('hygiène')) return 'tZ4lCI6Pyoo';
  return 'KCGamQMZ7Nk';
};

export default function KidsDictionaryScreen() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [family, setFamily] = useState('Toutes');
  const [selected, setSelected] = useState<KidWord | null>(null);
  const [customWords, setCustomWords] = useState<KidWord[]>(loadCustomWords());
  const [adminUnlocked, setAdminUnlocked] = useState(localStorage.getItem('msp_kids_dict_admin') === 'true');
  const [newWord, setNewWord] = useState<KidWord>({ word: '', definition: '', example: '', family: 'Général', imageUrl: '', videoUrl: '' });
  const allWords = useMemo(() => {
    const base = [...WORDS];
    for (const custom of customWords) {
      const idx = base.findIndex(w => w.word.toLowerCase() === custom.word.toLowerCase());
      if (idx >= 0) base[idx] = custom;
      else base.push(custom);
    }
    return base;
  }, [customWords]);
  const families = ['Toutes', ...Array.from(new Set(allWords.map(w => w.family)))];
  const filtered = useMemo(() => allWords.filter(w => (family === 'Toutes' || w.family === family) && `${w.word} ${w.definition} ${w.example}`.toLowerCase().includes(query.toLowerCase())), [query, family, allWords]);

  function unlockAdmin() {
    const password = prompt('Mot de passe administrateur :');
    if (password === ADMIN_PASSWORD) { localStorage.setItem('msp_kids_dict_admin', 'true'); setAdminUnlocked(true); }
    else if (password !== null) alert('Mot de passe incorrect.');
  }

  function saveWord() {
    if (!newWord.word.trim()) return alert('Ajoutez un mot.');
    const next = [...customWords.filter(w => w.word.toLowerCase() !== newWord.word.toLowerCase()), newWord];
    setCustomWords(next); saveCustomWords(next);
    setNewWord({ word: '', definition: '', example: '', family: 'Général', imageUrl: '', videoUrl: '' });
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow"><div className="flex items-center gap-3"><button onClick={() => navigate('/')} className="p-2 bg-white/20 rounded-lg"><ChevronLeft className="w-6 h-6" /></button><div><h1 className="font-bold text-lg">Dictionnaire des petits écoliers</h1><p className="text-emerald-100 text-sm">Mots faciles, images et vidéos</p></div></div></header>
      <main className="p-4 pb-24 max-w-5xl mx-auto">
        <section className="bg-white rounded-2xl shadow p-4 mb-4"><h2 className="font-black text-gray-900">Comprendre les mots simplement</h2><p className="text-gray-500 text-sm">Chaque mot est expliqué avec une définition facile, un exemple, une image et une vidéo.</p><div className="relative mt-4"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Chercher un mot..." className="w-full pl-10 pr-4 py-3 border rounded-lg" /></div></section>
        <section className="bg-white rounded-2xl shadow p-4 mb-4"><div className="flex items-center justify-between"><h2 className="font-bold text-gray-900">Administration du dictionnaire</h2>{!adminUnlocked && <button onClick={unlockAdmin} className="bg-gray-800 text-white px-3 py-2 rounded-lg text-sm font-semibold flex items-center gap-1"><Shield className="w-4 h-4" /> Admin</button>}</div>{adminUnlocked && <div className="mt-3 grid gap-2"><input value={newWord.word} onChange={e => setNewWord({ ...newWord, word: e.target.value })} placeholder="Mot" className="p-3 border rounded-lg" /><input value={newWord.family} onChange={e => setNewWord({ ...newWord, family: e.target.value })} placeholder="Famille" className="p-3 border rounded-lg" /><input value={newWord.definition} onChange={e => setNewWord({ ...newWord, definition: e.target.value })} placeholder="Définition facile" className="p-3 border rounded-lg" /><input value={newWord.example} onChange={e => setNewWord({ ...newWord, example: e.target.value })} placeholder="Exemple" className="p-3 border rounded-lg" /><input value={newWord.imageUrl} onChange={e => setNewWord({ ...newWord, imageUrl: e.target.value })} placeholder="Lien image" className="p-3 border rounded-lg" /><input value={newWord.videoUrl} onChange={e => setNewWord({ ...newWord, videoUrl: e.target.value })} placeholder="Lien vidéo YouTube/Facebook/TikTok" className="p-3 border rounded-lg" /><button onClick={saveWord} className="bg-emerald-600 text-white py-3 rounded-lg font-semibold"><Plus className="w-4 h-4 inline mr-1" /> Ajouter / modifier</button></div>}</section>
        <div className="flex gap-2 overflow-x-auto pb-2 mb-4">{families.map(f => <button key={f} onClick={() => setFamily(f)} className={`whitespace-nowrap px-4 py-2 rounded-lg font-bold text-sm ${family === f ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 border'}`}>{f}</button>)}</div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">{filtered.map(item => <button key={item.word} onClick={() => setSelected(item)} className="bg-white rounded-2xl shadow text-left overflow-hidden"><img src={imageUrl(item)} alt={item.word} className="w-full h-28 object-cover bg-gray-100" onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} /><div className="p-4"><div className="flex items-center gap-2"><BookMarked className="w-5 h-5 text-emerald-600" /><h2 className="font-black text-gray-900">{item.word}</h2></div><p className="text-xs text-emerald-700 mt-1">{item.family}</p><p className="text-gray-700 text-sm mt-2 line-clamp-3">{item.definition}</p></div></button>)}</div>
      </main>
      {selected && <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"><div className="bg-white rounded-2xl max-w-xl w-full overflow-hidden"><div className="relative"><img src={imageUrl(selected)} alt={selected.word} className="w-full h-48 object-cover bg-gray-100" /><button onClick={() => setSelected(null)} className="absolute top-3 right-3 bg-white/90 p-2 rounded-lg"><X className="w-6 h-6" /></button></div><div className="p-5"><p className="text-emerald-700 font-bold text-sm">{selected.family}</p><h2 className="text-3xl font-black text-gray-900">{selected.word}</h2><p className="text-lg text-gray-700 mt-3">{selected.definition}</p><p className="text-emerald-700 font-semibold mt-3">Exemple : {selected.example}</p>{(() => { const embed = selected.videoUrl ? getVideoEmbed(selected.videoUrl) : `https://www.youtube-nocookie.com/embed/${videoId(selected.word)}?rel=0&modestbranding=1&playsinline=1`; return embed ? <div className="mt-5 aspect-video bg-black rounded-xl overflow-hidden"><iframe src={embed} title={selected.word} className="w-full h-full" allowFullScreen /></div> : null; })()}<button onClick={() => setSelected(null)} className="mt-4 w-full bg-emerald-600 text-white py-3 rounded-xl font-bold">J’ai compris</button></div></div></div>}
    </div>
  );
}
