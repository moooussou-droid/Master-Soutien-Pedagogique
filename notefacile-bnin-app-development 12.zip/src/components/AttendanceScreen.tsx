import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, FileText, UserCheck } from 'lucide-react';
import { ClassData, getClass, sortStudents } from '../utils/database';

type AttendanceStatus = 'present' | 'absent_injustifiee' | 'absent_justifiee' | 'retard';

interface AttendanceEntry {
  studentId: string;
  status: AttendanceStatus;
  motif?: string;
}

interface AttendanceDay {
  id: string;
  classId: string;
  date: string;
  entries: AttendanceEntry[];
}

const STORAGE_KEY = 'msp_attendance_records';

function loadRecords(): AttendanceDay[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  } catch {
    return [];
  }
}

function saveRecords(records: AttendanceDay[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function today() {
  return new Date().toISOString().split('T')[0];
}

const STATUS_LABELS: Record<AttendanceStatus, string> = {
  present: 'Présent',
  absent_injustifiee: 'Abs. injustifiée',
  absent_justifiee: 'Abs. justifiée',
  retard: 'Retard',
};

export default function AttendanceScreen() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [classData, setClassData] = useState<ClassData | null>(null);
  const [date, setDate] = useState(today());
  const [records, setRecords] = useState<AttendanceDay[]>(loadRecords());

  useEffect(() => {
    if (id) getClass(id).then(c => setClassData(c || null));
  }, [id]);

  const students = useMemo(() => sortStudents(classData?.students || []), [classData]);
  const current = records.find(r => r.classId === id && r.date === date);

  function getStatus(studentId: string): AttendanceStatus {
    return current?.entries.find(e => e.studentId === studentId)?.status || 'present';
  }

  function getMotif(studentId: string): string {
    return current?.entries.find(e => e.studentId === studentId)?.motif || '';
  }

  function updateEntry(studentId: string, status: AttendanceStatus, motif = getMotif(studentId)) {
    if (!id) return;
    let next = [...records];
    let record = next.find(r => r.classId === id && r.date === date);
    if (!record) {
      record = { id: `att-${Date.now()}`, classId: id, date, entries: [] };
      next.unshift(record);
    }
    const idx = record.entries.findIndex(e => e.studentId === studentId);
    const entry = { studentId, status, motif };
    if (idx >= 0) record.entries[idx] = entry;
    else record.entries.push(entry);
    setRecords(next);
    saveRecords(next);
  }

  function markAllPresent() {
    students.forEach(s => updateEntry(s.id, 'present', ''));
  }

  const monthRecords = records.filter(r => r.classId === id && r.date.startsWith(date.slice(0, 7)));
  const totalPossible = monthRecords.length * students.length;
  const totalPresent = monthRecords.reduce((sum, r) => sum + students.filter(s => {
    const entry = r.entries.find(e => e.studentId === s.id);
    return !entry || entry.status === 'present' || entry.status === 'retard';
  }).length, 0);
  const globalRate = totalPossible ? Math.round((totalPresent / totalPossible) * 100) : 0;

  if (!classData) return <div className="p-4 text-center">Chargement...</div>;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 bg-white/20 rounded-lg"><ChevronLeft className="w-6 h-6" /></button>
          <div>
            <h1 className="font-bold text-lg">Registre de Présence</h1>
            <p className="text-emerald-100 text-sm">{classData.name} • Appel quotidien</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24">
        <div className="bg-white rounded-xl shadow p-4 mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">Date de l'appel</label>
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full p-3 border border-gray-300 rounded-lg" />
          <button onClick={markAllPresent} className="w-full mt-3 bg-emerald-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
            <UserCheck className="w-5 h-5" /> Tout le monde présent
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-white rounded-xl shadow p-4 text-center">
            <p className="text-2xl font-bold text-emerald-600">{globalRate}%</p>
            <p className="text-gray-500 text-xs">Taux mensuel global</p>
          </div>
          <div className="bg-white rounded-xl shadow p-4 text-center">
            <p className="text-2xl font-bold text-blue-600">{monthRecords.length}</p>
            <p className="text-gray-500 text-xs">Jours enregistrés</p>
          </div>
        </div>

        <div className="space-y-2">
          {students.map(student => {
            const status = getStatus(student.id);
            const photo = student.photoUrl;
            return (
              <div key={student.id} className="bg-white rounded-xl shadow p-3">
                <div className="flex items-center gap-3 mb-3">
                  {photo ? <img src={photo} alt="" className="w-11 h-11 rounded-full object-cover" /> : <div className="w-11 h-11 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">{student.nom[0]}{student.prenoms?.[0] || ''}</div>}
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-800 truncate">{student.nom.toUpperCase()} {student.prenoms}</p>
                    <p className="text-gray-400 text-xs">{STATUS_LABELS[status]}</p>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-1 mb-2">
                  {(['present', 'absent_injustifiee', 'absent_justifiee', 'retard'] as AttendanceStatus[]).map(s => (
                    <button key={s} onClick={() => updateEntry(student.id, s)} className={`text-[11px] py-2 rounded-lg ${status === s ? 'bg-emerald-600 text-white' : 'bg-gray-100 text-gray-600'}`}>{STATUS_LABELS[s]}</button>
                  ))}
                </div>
                {status !== 'present' && (
                  <input value={getMotif(student.id)} onChange={e => updateEntry(student.id, status, e.target.value)} placeholder="Motif (facultatif)" className="w-full p-2 border border-gray-300 rounded-lg text-sm" />
                )}
              </div>
            );
          })}
        </div>

        <MonthlyReport classData={classData} records={monthRecords} />
      </main>
    </div>
  );
}

function MonthlyReport({ classData, records }: { classData: ClassData; records: AttendanceDay[] }) {
  const students = sortStudents(classData.students);
  function studentRate(studentId: string) {
    if (!records.length) return 0;
    const present = records.filter(r => {
      const e = r.entries.find(x => x.studentId === studentId);
      return !e || e.status === 'present' || e.status === 'retard';
    }).length;
    return Math.round((present / records.length) * 100);
  }
  function printReport() {
    window.print();
  }
  return (
    <div className="bg-white rounded-xl shadow p-4 mt-6">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-bold text-gray-800 flex items-center gap-2"><FileText className="w-5 h-5" /> PV mensuel</h2>
        <button onClick={printReport} className="bg-blue-50 text-blue-700 px-3 py-2 rounded-lg text-sm">Imprimer</button>
      </div>
      <p className="text-gray-500 text-sm mb-3">Document prêt pour circonscription scolaire, EducMaster et inspection.</p>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead><tr className="bg-gray-100"><th className="p-2 text-left">Élève</th><th className="p-2">Taux</th><th className="p-2">Jours suivis</th></tr></thead>
          <tbody>{students.map(s => <tr key={s.id} className="border-t"><td className="p-2">{s.nom} {s.prenoms}</td><td className="p-2 text-center font-semibold">{studentRate(s.id)}%</td><td className="p-2 text-center">{records.length}</td></tr>)}</tbody>
        </table>
      </div>
    </div>
  );
}