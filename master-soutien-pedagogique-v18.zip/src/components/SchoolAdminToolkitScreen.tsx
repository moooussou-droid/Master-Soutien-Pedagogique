import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle, ChevronLeft, ClipboardCheck, Copy, FileText,
  Printer, Save, School, Target, Trash2,
} from 'lucide-react';
import { getAllClasses } from '../utils/database';
import { computeBulletins, computeClassStats } from '../utils/bulletin';
import { getProfile } from '../utils/userProfile';
import { copyText } from '../utils/clipboard';
import { buildSchoolSummary, localDateKey, buildStudentsToSupport } from '../utils/schoolStats';
import { AdminTask, loadTasks, saveTasks, taskProgress, taskProgressByCategory } from '../utils/schoolChecklists';
import { printSchoolReport } from '../utils/schoolReport';
import { schoolYearLabel } from '../utils/orientation';

type AdminTab = 'pilotage' | 'documents' | 'checklists' | 'priorites';

type DocumentType =
  | 'rapport_mensuel'
  | 'pv_conseil'
  | 'pv_ape'
  | 'note_service'
  | 'demande_fournitures'
  | 'rapport_inspection'
  | 'plan_remediation';

interface AdminDocument {
  id: string;
  type: DocumentType;
  title: string;
  school: string;
  circonscription: string;
  date: string;
  author: string;
  content: string;
  createdAt: number;
}

const DOC_KEY = 'msp_admin_documents';

const DOC_LABELS: Record<DocumentType, string> = {
  rapport_mensuel: 'Rapport mensuel à la circonscription',
  pv_conseil: 'PV du conseil des maîtres / conseil de classe',
  pv_ape: 'PV réunion APE',
  note_service: 'Note de service',
  demande_fournitures: 'Demande de fournitures / matériel',
  rapport_inspection: 'Rapport de préparation à l’inspection',
  plan_remediation: 'Plan de remédiation pédagogique',
};

function loadDocs(): AdminDocument[] {
  try { return JSON.parse(localStorage.getItem(DOC_KEY) || '[]'); } catch { return []; }
}

function saveDocs(docs: AdminDocument[]) {
  localStorage.setItem(DOC_KEY, JSON.stringify(docs));
}

function buildTemplate(type: DocumentType, context: { school: string; circonscription: string; author: string; date: string }) {
  const header = `RÉPUBLIQUE DU BÉNIN\n${context.circonscription || 'Circonscription scolaire : __________'}\n${context.school || 'École : __________'}\nDate : ${context.date}\nRédigé par : ${context.author || '__________'}\n\n`;
  switch (type) {
    case 'rapport_mensuel':
      return `${header}RAPPORT MENSUEL\n\n1. Effectifs et fréquentation scolaire :\n- Effectif total :\n- Taux de présence :\n- Absences répétées signalées :\n\n2. Activités pédagogiques réalisées :\n\n3. Difficultés rencontrées :\n\n4. Actions de remédiation engagées :\n\n5. Besoins et recommandations :\n`;
    case 'pv_conseil':
      return `${header}PROCÈS-VERBAL DU CONSEIL\n\nOrdre du jour :\n1. Analyse des résultats scolaires\n2. Identification des élèves à accompagner\n3. Décisions pédagogiques\n4. Recommandations\n\nDécisions :\n\nSignatures :\n`;
    case 'pv_ape':
      return `${header}PROCÈS-VERBAL DE RÉUNION APE\n\nParticipants :\n\nOrdre du jour :\n\nPoints discutés :\n\nDécisions prises :\n\nResponsables et échéances :\n`;
    case 'note_service':
      return `${header}NOTE DE SERVICE\n\nObjet :\n\nIl est porté à la connaissance des enseignants et acteurs concernés que :\n\nConsignes :\n\nFait pour servir et valoir ce que de droit.\n`;
    case 'demande_fournitures':
      return `${header}DEMANDE DE FOURNITURES / MATÉRIEL\n\nObjet : Demande d’appui en matériel pédagogique\n\nBesoins identifiés :\n- Cahiers :\n- Craies / marqueurs :\n- Manuels :\n- Matériel sportif :\n- Autres :\n\nJustification pédagogique :\n`;
    case 'rapport_inspection':
      return `${header}RAPPORT DE PRÉPARATION À L’INSPECTION\n\nDocuments disponibles :\n- Cahier journal :\n- Progressions :\n- Fiches pédagogiques :\n- Registre d’appel :\n- Évaluations :\n\nPoints forts :\n\nPoints à améliorer :\n\nActions engagées :\n`;
    case 'plan_remediation':
      return `${header}PLAN DE REMÉDIATION PÉDAGOGIQUE\n\nÉlèves concernés :\n\nDifficultés observées :\n\nObjectifs de remédiation :\n\nActivités prévues :\n\nCalendrier :\n\nIndicateurs de réussite :\n`;
  }
}

export default function SchoolAdminToolkitScreen() {
  const navigate = useNavigate();
  const profile = getProfile();
  const [tab, setTab] = useState<AdminTab>('pilotage');
  const [classes, setClasses] = useState<any[]>([]);
  const [docs, setDocs] = useState<AdminDocument[]>([]);
  const [tasks, setTasks] = useState<AdminTask[]>([]);

  const [docType, setDocType] = useState<DocumentType>('rapport_mensuel');
  const [school, setSchool] = useState(profile.schoolName || '');
  const [circonscription, setCirconscription] = useState('');
  const [author, setAuthor] = useState(profile.teacherName || '');
  const [date, setDate] = useState(localDateKey());
  const [newTask, setNewTask] = useState('');
  const [newTaskCategory, setNewTaskCategory] = useState('Personnalisé');
  const [content, setContent] = useState('');

  useEffect(() => {
    getAllClasses().then(setClasses);
    setDocs(loadDocs());
    setTasks(loadTasks());
  }, []);

  useEffect(() => {
    setContent(buildTemplate(docType, { school, circonscription, author, date }));
  }, [docType]);

  const classSummaries = useMemo(() => classes.map(classData => {
    const bulletins = computeBulletins(classData);
    const stats = computeClassStats(bulletins);
    const completion = classData.students.length * classData.subjects.length
      ? Math.round((classData.notes.filter((n: any) => n.noteObtenue !== null || n.notePerfectionnement !== null || n.absent).length / (classData.students.length * classData.subjects.length)) * 100)
      : 0;
    return {
      name: classData.name,
      level: classData.level,
      effectif: classData.students.length,
      moyenne: stats.moyenneClasse,
      taux: stats.tauxReussite,
      completion,
      alert: completion < 100 || (stats.tauxReussite < 50 && stats.count > 0),
    };
  }), [classes]);

  function persistDocs(next: AdminDocument[]) {
    setDocs(next);
    saveDocs(next);
  }

  function persistTasks(next: AdminTask[]) {
    setTasks(next);
    saveTasks(next);
  }

  const summary = useMemo(() => buildSchoolSummary(classSummaries as any), [classSummaries]);
  const progress = taskProgress(tasks);
  const progressByCategory = taskProgressByCategory(tasks);
  const studentsToSupport = useMemo(() => classes.map(cd => ({ className: cd.name, items: buildStudentsToSupport(cd) })), [classes]);
  const supportTotal = studentsToSupport.reduce((a, g) => a + g.items.length, 0);

  function addTask() {
    if (!newTask.trim()) return;
    const item: AdminTask = { id: `task-${Date.now()}`, label: newTask.trim(), category: newTaskCategory.trim() || 'Personnalisé', done: false, custom: true };
    persistTasks([...tasks, item]);
    setNewTask('');
  }

  function regenerateTemplate() {
    setContent(buildTemplate(docType, { school, circonscription, author, date }));
  }

  function saveDocument() {
    const doc: AdminDocument = {
      id: `adm-doc-${Date.now()}`,
      type: docType,
      title: DOC_LABELS[docType],
      school,
      circonscription,
      date,
      author,
      content,
      createdAt: Date.now(),
    };
    persistDocs([doc, ...docs]);
    alert('Document administratif enregistré.');
  }

  async function copyDocument() {
    const okCopy = await copyText(content);
    alert(okCopy ? 'Document copié.' : 'Impossible de copier automatiquement : sélectionnez le texte manuellement.');
  }

  function printDocument() {
    printDocContent(docType, content);
  }

  function printDocContent(title: string, text: string) {
    const win = window.open('', '_blank');
    if (!win) return;
    win.document.write(`<!doctype html><html><head><title>${title}</title><style>body{font-family:Arial;padding:30px;white-space:pre-wrap;line-height:1.5}h1{color:#047857}</style></head><body><h1>${title}</h1>${text.replace(/</g, '&lt;')}<script>window.print()</script></body></html>`);
    win.document.close();
  }

  /** Rouvre un document archivé dans l'éditeur pour le modifier. */
  function openDoc(doc: AdminDocument) {
    setDocType(doc.type);
    setSchool(doc.school);
    setCirconscription(doc.circonscription);
    setAuthor(doc.author);
    setDate(doc.date);
    setContent(doc.content);
    setTab('documents');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function printPilotage() {
    const okPrint = printSchoolReport({
      school,
      circonscription,
      author,
      yearLabel: schoolYearLabel(),
      date: localDateKey(),
      summary,
      classes: classSummaries,
      studentsToSupport,
    });
    if (!okPrint) alert('Votre navigateur a bloqué l’ouverture de la fenêtre d’impression.');
  }

  const tabs: { id: AdminTab; label: string; icon: typeof School }[] = [
    { id: 'pilotage', label: 'Pilotage', icon: Target },
    { id: 'documents', label: 'Documents', icon: FileText },
    { id: 'checklists', label: 'Checklists', icon: ClipboardCheck },
    { id: 'priorites', label: 'Priorités', icon: AlertTriangle },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-emerald-600 text-white p-4 sticky top-0 z-10 shadow">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 bg-white/20 rounded-lg"><ChevronLeft className="w-6 h-6" /></button>
          <div>
            <h1 className="font-bold text-lg">Administration scolaire</h1>
            <p className="text-emerald-100 text-sm">Pilotage, documents, inspection et EducMaster</p>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24">
        <div className="grid grid-cols-4 gap-2 mb-4">
          {tabs.map(item => {
            const Icon = item.icon;
            return (
              <button key={item.id} onClick={() => setTab(item.id)} className={`rounded-xl p-3 text-xs font-semibold flex flex-col items-center gap-1 ${tab === item.id ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600 border'}`}>
                <Icon className="w-5 h-5" />
                {item.label}
              </button>
            );
          })}
        </div>

        {tab === 'pilotage' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="bg-emerald-600 text-white rounded-xl shadow p-3 text-center">
                <p className="text-2xl font-black">{summary.totalStudents}</p>
                <p className="text-xs text-emerald-100">Élèves ({summary.count} classe{summary.count > 1 ? 's' : ''})</p>
              </div>
              <div className="bg-white rounded-xl shadow p-3 text-center">
                <p className="text-2xl font-black text-gray-900">{summary.moyenneEcole === null ? '-' : summary.moyenneEcole.toFixed(2)}</p>
                <p className="text-xs text-gray-500">Moyenne de l’école /20</p>
              </div>
              <div className="bg-white rounded-xl shadow p-3 text-center">
                <p className="text-2xl font-black text-gray-900">{Math.round(summary.tauxGlobal)}%</p>
                <p className="text-xs text-gray-500">Réussite globale</p>
              </div>
              <div className="bg-white rounded-xl shadow p-3 text-center">
                <p className="text-2xl font-black text-gray-900">{Math.round(summary.completionMoyenne)}%</p>
                <p className="text-xs text-gray-500">Saisie moyenne</p>
              </div>
            </div>
            <button onClick={printPilotage} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-semibold inline-flex items-center justify-center gap-2">
              <Printer className="w-5 h-5" /> Imprimer le rapport de pilotage
            </button>
            <div className="bg-white rounded-xl shadow p-4">
              <div className="flex items-center justify-between gap-2 mb-3">
                <h2 className="font-bold text-gray-800">Élèves à accompagner (moyenne &lt; 10/20)</h2>
                <span className={`rounded px-2 py-1 text-xs font-bold ${supportTotal > 0 ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>{supportTotal}</span>
              </div>
              {supportTotal === 0 ? (
                <p className="text-emerald-700 bg-emerald-50 rounded-lg p-3 text-sm">Aucun élève sous la moyenne. Continuez le suivi régulier.</p>
              ) : (
                <div className="space-y-2">
                  {studentsToSupport.filter(g => g.items.length > 0).map(group => (
                    <div key={group.className} className="rounded-lg border p-3">
                      <p className="font-bold text-gray-800 text-sm mb-1">{group.className}</p>
                      {group.items.map(item => (
                        <div key={item.studentId} className="flex items-center justify-between gap-2 py-1 border-t border-gray-50 text-sm">
                          <p className="text-gray-700">{item.name}</p>
                          <p className="text-gray-500 text-xs shrink-0">{item.moyenne?.toFixed(2)}/20 · {item.weakCount} matière{item.weakCount > 1 ? 's' : ''} &lt; 10</p>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="bg-white rounded-xl shadow p-4">
              <h2 className="font-bold text-gray-800 mb-3">Vue de pilotage des classes</h2>
              <div className="space-y-2">
                {classSummaries.length === 0 ? <p className="text-gray-500 text-sm">Aucune classe créée.</p> : classSummaries.map(item => (
                  <div key={item.name} className="rounded-lg border p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <p className="font-bold text-gray-800">{item.name} <span className="text-xs text-gray-400">{item.level}</span></p>
                        <p className="text-xs text-gray-500">Effectif : {item.effectif} • Saisie : {item.completion}%</p>
                      </div>
                      {item.alert ? <span className="bg-amber-100 text-amber-700 text-xs px-2 py-1 rounded">À suivre</span> : <span className="bg-emerald-100 text-emerald-700 text-xs px-2 py-1 rounded">OK</span>}
                    </div>
                    <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                      <p>Moyenne : <strong>{item.moyenne === null ? '-' : item.moyenne.toFixed(2)}/20</strong></p>
                      <p>Réussite : <strong>{Math.round(item.taux)}%</strong></p>
                    </div>
                    <div className="mt-2 flex items-center gap-2">
                      <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${item.completion >= 100 ? 'bg-emerald-500' : 'bg-amber-400'}`} style={{ width: `${item.completion}%` }} />
                      </div>
                      <p className="text-xs text-gray-500 w-24 text-right shrink-0">Saisie {item.completion}%</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === 'documents' && (
          <div className="space-y-4">
            <div className="bg-white rounded-xl shadow p-4 space-y-3">
              <h2 className="font-bold text-gray-800">Générateur de documents administratifs</h2>
              <select value={docType} onChange={e => setDocType(e.target.value as DocumentType)} className="w-full p-3 border rounded-lg">
                {Object.entries(DOC_LABELS).map(([key, label]) => <option key={key} value={key}>{label}</option>)}
              </select>
              <div className="grid grid-cols-2 gap-2">
                <input value={school} onChange={e => setSchool(e.target.value)} placeholder="École" className="p-3 border rounded-lg text-sm" />
                <input value={circonscription} onChange={e => setCirconscription(e.target.value)} placeholder="Circonscription" className="p-3 border rounded-lg text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input value={author} onChange={e => setAuthor(e.target.value)} placeholder="Rédacteur" className="p-3 border rounded-lg text-sm" />
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="p-3 border rounded-lg text-sm" />
              </div>
              <textarea value={content} onChange={e => setContent(e.target.value)} rows={12} className="w-full p-3 border rounded-lg text-sm resize-none font-mono" />
              <button onClick={regenerateTemplate} className="w-full bg-gray-50 border border-dashed border-gray-300 py-2 rounded-lg text-sm text-gray-600 font-medium">↻ Régénérer le modèle (en-tête actuel)</button>
              <div className="grid grid-cols-3 gap-2">
                <button onClick={copyDocument} className="bg-blue-50 text-blue-700 py-3 rounded-lg font-semibold flex items-center justify-center gap-1"><Copy className="w-4 h-4" /> Copier</button>
                <button onClick={printDocument} className="bg-gray-100 text-gray-700 py-3 rounded-lg font-semibold flex items-center justify-center gap-1"><Printer className="w-4 h-4" /> Imprimer</button>
                <button onClick={saveDocument} className="bg-emerald-600 text-white py-3 rounded-lg font-semibold flex items-center justify-center gap-1"><Save className="w-4 h-4" /> Sauver</button>
              </div>
            </div>
            <div className="space-y-2">
              {docs.length === 0 && <p className="text-gray-500 text-sm">Aucun document enregistré.</p>}
              {docs.map(doc => (
                <div key={doc.id} className="bg-white rounded-xl shadow p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold text-gray-800 truncate">{doc.title}</p>
                      <p className="text-gray-500 text-xs">{doc.date} • {doc.school}</p>
                    </div>
                    <button onClick={() => persistDocs(docs.filter(d => d.id !== doc.id))} className="text-red-500 p-2 shrink-0" title="Supprimer"><Trash2 className="w-5 h-5" /></button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <button onClick={() => openDoc(doc)} className="bg-blue-50 text-blue-700 py-2 rounded-lg text-sm font-semibold inline-flex items-center justify-center gap-1"><FileText className="w-4 h-4" /> Rouvrir</button>
                    <button onClick={() => printDocContent(doc.title, doc.content)} className="bg-gray-100 text-gray-700 py-2 rounded-lg text-sm font-semibold inline-flex items-center justify-center gap-1"><Printer className="w-4 h-4" /> Imprimer</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'checklists' && (
          <div className="space-y-4">
            <div className="bg-white rounded-xl shadow p-4">
              <div className="flex items-center justify-between gap-3 mb-2">
                <h2 className="font-bold text-gray-800">Checklists EducMaster & Inspection</h2>
                <button
                  onClick={() => {
                    if (window.confirm('Réinitialiser toutes les tâches (les personnalisées sont conservées) ?')) {
                      persistTasks(tasks.map(t => ({ ...t, done: false })));
                    }
                  }}
                  className="text-gray-400 text-xs font-semibold"
                >Réinitialiser</button>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${progress.percent >= 100 ? 'bg-emerald-500' : 'bg-emerald-600'}`} style={{ width: `${progress.percent}%` }} />
                </div>
                <p className="text-sm font-bold text-gray-700 shrink-0">{progress.done}/{progress.total}</p>
              </div>
              {progressByCategory.length > 1 && (
                <div className="mt-3 space-y-2">
                  {progressByCategory.map(cat => (
                    <div key={cat.category} className="flex items-center gap-2 text-xs">
                      <p className="w-28 text-gray-600 font-semibold shrink-0">{cat.category}</p>
                      <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${cat.percent >= 100 ? 'bg-emerald-500' : 'bg-emerald-600'}`} style={{ width: `${cat.percent}%` }} />
                      </div>
                      <p className="text-gray-500 w-16 text-right shrink-0">{cat.done}/{cat.total}</p>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-4 grid grid-cols-1 md:grid-cols-[1fr_140px_auto] gap-2">
                <input value={newTask} onChange={e => setNewTask(e.target.value)} placeholder="Ajouter une tâche personnalisée…" className="p-3 border rounded-lg text-sm" />
                <input value={newTaskCategory} onChange={e => setNewTaskCategory(e.target.value)} placeholder="Catégorie" className="p-3 border rounded-lg text-sm" />
                <button onClick={addTask} className="bg-emerald-600 text-white px-4 rounded-lg font-semibold text-sm">Ajouter</button>
              </div>
              <div className="space-y-2 mt-2">
                {tasks.map(task => (
                  <label key={task.id} className="flex items-start gap-3 rounded-lg border p-3">
                    <input type="checkbox" checked={task.done} onChange={() => persistTasks(tasks.map(t => t.id === task.id ? { ...t, done: !t.done } : t))} className="mt-1 w-5 h-5" />
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium ${task.done ? 'line-through text-gray-400' : 'text-gray-800'}`}>{task.label}</p>
                      <p className="text-xs text-gray-500">{task.category}</p>
                    </div>
                    {task.custom && (
                      <button onClick={() => persistTasks(tasks.filter(t => t.id !== task.id))} className="text-red-400 p-1.5 shrink-0" title="Supprimer la tâche">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </label>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === 'priorites' && (
          <div className="bg-white rounded-xl shadow p-4">
            <h2 className="font-bold text-gray-800 mb-3">Priorités pédagogiques</h2>
            <div className="space-y-2">
              {classSummaries.filter(c => c.alert).length === 0 ? (
                <p className="text-emerald-700 bg-emerald-50 rounded-lg p-3 text-sm">Aucune alerte majeure. Continuez le suivi régulier.</p>
              ) : classSummaries.filter(c => c.alert).map(item => (
                <div key={item.name} className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <p className="font-bold text-amber-800">{item.name}</p>
                  <p className="text-amber-700 text-sm">Saisie : {item.completion}%. Réussite : {Math.round(item.taux)}%. Prévoir remédiation et vérification des notes.</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}